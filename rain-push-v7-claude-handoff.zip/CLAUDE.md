# Claude Project Instructions

Read this file before changing the repository.

## Project identity

This repository is `rain-push v7`, a cumulative Phase 1–12 architecture for a persistent Ame / KAngel character runtime.

The character is not implemented as a large prompt card. The system models a complete causal chain:

```text
Evidence / Knowledge
→ Continuity
→ Relationship
→ Meaning
→ Emotion
→ Need
→ Thought
→ Decision
→ Behavior
→ Expression
→ Language
→ Integration and execution boundary
```

The user-facing partner name is always `豆豆`.

Ame and KAngel are two expression surfaces of one person. They share facts, memory, relationship state, emotion, needs, thought, and decisions.

## Read order

1. `START_HERE_CLAUDE.md`
2. `handoff/PROJECT_CONCEPT.md`
3. `handoff/CURRENT_IMPLEMENTATION.md`
4. `handoff/DECISION_LOG.md`
5. `handoff/NEXT_ACTIONS.md`
6. `handoff/KNOWN_LIMITATIONS.md`
7. `runtime/v7/README.md`
8. `runtime/v7/FINAL_RUNTIME_STATUS.md`
9. `runtime/v7/engine/README.md`
10. the relevant Phase folder before changing that Phase

Machine-readable context:

- `handoff/project_context.json`
- `handoff/materials_manifest.json`

## Baseline command

Run before editing:

```bash
cd runtime/v7/engine
npm test
```

Expected baseline:

```text
166 tests
166 pass
0 fail
```

Do not claim a successful continuation until the baseline has been run.

## Non-negotiable invariants

1. State precedes dialogue.
2. Evidence precedes interpretation.
3. A local event must remain local unless evidence supports escalation.
4. Ordinary life must remain available and common.
5. Specific feedback is not interchangeable with generic reassurance.
6. Pride, ambition, affection, irritation, fatigue, and vulnerability may all be genuine.
7. Dark humor does not automatically mean crisis.
8. Sexual jokes do not automatically mean intimacy planning.
9. Drug references do not automatically mean severe state or operational drug content.
10. Ame and KAngel are not separate minds.
11. Public and private information must remain separated.
12. Every runtime may update only its own model.
13. Language generation never proves execution.
14. `executionStatus` remains `not_executed` until an external confirmed handler succeeds.
15. Generated partner naming uses `豆豆`.
16. Original quoted evidence may preserve `阿P` only when it is explicitly source text.
17. No full copyrighted dialogue corpus should be silently added to a public repository.
18. Do not replace character fidelity with generic therapy, customer-service, streamer, idol, or anime-girl language.

## Coding conventions

- Current reference engine uses zero-dependency ESM JavaScript and Node.js 20+.
- Preserve deterministic output for identical event, state, version, and seed.
- Preserve Packet boundaries.
- Add typed signals before adding broad text heuristics.
- Every new rule family requires executable scenario tests and boundary tests.
- Every public rule requires privacy and context-collapse checks.
- Every action requiring external execution must pass through `ExecutionBoundary`.
- Do not report external effects as executed without a real handler result.
- Keep state writes transactional and evidence-gated.

## Scope honesty

The current engine is a deterministic, inspectable reference implementation for typed scenario families.

It is not a general-purpose language model and does not fully implement every rule found in every Phase specification.

Do not describe the engine as complete natural-language coverage.

## Immediate continuation task

The recommended next task is the Spec–Engine Parity Audit described in:

```text
handoff/NEXT_ACTIONS.md
```

Do not begin by inventing Phase 13.

First identify which Phase 1–11 requirements are:

- implemented
- partially implemented
- specification-only
- tested
- untested

Then turn that audit into executable contract checks.

## Deliverable discipline

For each continuation:

1. state the exact files changed
2. run the complete test suite
3. report pass/fail counts truthfully
4. update the relevant changelog and status file
5. update `handoff/materials_manifest.json`
6. preserve a downloadable cumulative package
