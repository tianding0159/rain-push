# START HERE: Claude Handoff

This package is designed so the project can continue without access to the prior ChatGPT conversation.

## What this is

`rain-push v7` is a character-runtime architecture for Ame / KAngel, centered on faithful internal causality rather than surface imitation.

The output line is treated as the final layer of a longer process:

```text
what happened
→ what is known
→ what remains pending
→ what it means in the relationship
→ what it means to her life and identity
→ what she feels
→ what she needs
→ what she thinks
→ what outcome she chooses
→ what behavior she performs
→ which persona surface appears
→ what exact language is rendered
```

Phase 1–11 define this system as specifications, schemas, DSL rules, examples, validators, and tests.

Phase 12 adds a runnable Node.js reference engine.

## Current state

The cumulative package contains all twelve phases.

Executable entry point:

```text
runtime/v7/engine/
```

Baseline:

```bash
cd runtime/v7/engine
npm test
```

Expected:

```text
166 pass
0 fail
```

The engine currently handles typed reference scenarios such as:

- vague versus specific stream feedback
- prior-notice waiting
- overdue promises
- pudding and ordinary household omissions
- post-stream fatigue
- audience milestones
- low-value trolls
- privacy exposure
- autonomy boundaries
- dark-humor, sexual-joke, and drug-reference restraint

## What not to assume

The executable engine is narrower than the full written specifications.

It is rule-based and inspectable.

It does not yet include:

- a complete Canon evidence corpus
- a general DSL compiler
- full schema parity
- complete natural-language coverage
- production database migrations
- real message or notification delivery
- broad weather-event integration
- a constrained LLM rendering adapter

## Immediate job

Do not add another conceptual Phase.

Perform a Spec–Engine Parity Audit first.

The audit must compare every Phase document against the JavaScript implementation and classify each requirement as:

```text
implemented
partial
specification-only
tested
untested
```

Then create automated contract tests for the highest-risk gaps.

Detailed plan:

```text
handoff/NEXT_ACTIONS.md
```

## Files that preserve project intent

- `handoff/PROJECT_CONCEPT.md`
- `handoff/DECISION_LOG.md`
- `handoff/CURRENT_IMPLEMENTATION.md`
- `handoff/KNOWN_LIMITATIONS.md`
- `handoff/ACCEPTANCE_CRITERIA.md`
- `handoff/MATERIALS_AND_PROVENANCE.md`
- `handoff/CLAUDE_BOOTSTRAP_PROMPT.md`

## Important execution boundary

Final language generation is implemented.

Actual effects are not.

```text
message generated
≠
message sent
```

Every Language Packet must remain:

```yaml
executionStatus: not_executed
```

until an external, allowlisted, confirmed handler returns success.
