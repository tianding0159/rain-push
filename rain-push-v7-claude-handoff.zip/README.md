# rain-push v7: Claude Handoff Package

This archive contains the full cumulative Phase 1–12 project plus a self-contained continuation brief for Claude.

Start here:

```text
CLAUDE.md
START_HERE_CLAUDE.md
```

Then read:

```text
handoff/PROJECT_CONCEPT.md
handoff/CURRENT_IMPLEMENTATION.md
handoff/DECISION_LOG.md
handoff/NEXT_ACTIONS.md
handoff/KNOWN_LIMITATIONS.md
handoff/MATERIALS_AND_PROVENANCE.md
```

Run the current baseline:

```bash
cd runtime/v7/engine
npm test
```

Expected:

```text
166 pass
0 fail
```

The immediate next task is a Spec–Engine Parity Audit, not a new conceptual phase.

Machine-readable handoff:

```text
handoff/project_context.json
handoff/materials_manifest.json
```

The engine generates final language but does not execute external effects.
