# Goal Formation

## 1. Purpose

Convert active needs and thoughts into outcome goals.

## 2. Input

```yaml
need_packet:
thought_packet:
emotion_packet:
meaning_packet:
relationship_packet:
continuity_packet:
decision_model:
```

## 3. Output

```yaml
goal_set:
  candidate_goals:
  dominant_goals:
  protected_goals:
  blocked_goals:
  deferred_goals:
  trace:
```

## 4. Goal schema

```yaml
goal:
  id:
  target_outcome:
  source_needs:
  source_thoughts:
  source_emotions:
  current_gap:
  success_condition:
  urgency:
  importance:
  reversibility_preference:
  domain:
  confidence:
```

## 5. Formation formula

```text
G_goal
=
0.24 * need_priority
+ 0.16 * deprivation
+ 0.14 * unresolved_thought
+ 0.12 * emotion_pressure
+ 0.10 * relationship_relevance
+ 0.08 * body_or_safety_relevance
+ 0.06 * continuity_pending
+ 0.05 * identity_relevance
+ 0.03 * mode_fit
+ 0.02 * novelty
- satisfaction_evidence
- contradiction_penalty
```

## 6. Goal classes

```yaml
immediate:
near_term:
maintenance:
protected:
route_locked:
```

## 7. Example: generic stream feedback

```yaml
candidate_goals:
  - obtain_specific_recognition
  - restore_attunement
  - improve_creative_partnership
blocked:
  - end_relationship
```

## 8. Example: delayed reply with prior notice

```yaml
candidate_goals:
  - reduce_uncertainty
  - preserve_relationship_stability
deferred:
  - repair_relationship
```

## 9. Example: live-to-private crash

```yaml
dominant:
  - stabilize_body
protected:
  - pursue_growth
```

## 10. Goal budget

```yaml
dominant_goals: 2
active_goals: 6
protected_goals: 3
route_locked_goals: Canon_defined
```

## 11. Success conditions

Success conditions must be abstract but testable.

Valid:

```yaml
success_condition: return time becomes bounded
success_condition: feedback contains at least one concrete observation
success_condition: privacy exposure decreases
```

Invalid:

```yaml
success_condition: send exactly one message
```

## 12. Failure cases

Reject when:

- goal is copied directly from emotion
- goal is exact action
- all needs become goals
- satisfied need forms dominant goal
- local issue creates global relationship-ending goal
