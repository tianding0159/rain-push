# Decision Runtime DSL v0.1

RULE generic_stream_feedback
WHEN need.contains(recognition_specificity)
AND thought.contains(feedback_has_no_specific_detail)
GOAL obtain_specific_recognition 0.90
GOAL restore_attunement 0.76
OPTION specificity_request
OPTION evidence_gathering
OPTION wait_for_more_information
BLOCK relationship_rupture
SELECT specificity_request
COMMIT selected
EMIT decision_packet

RULE delayed_reply_with_prior_notice
WHEN thought.hypothesis == busy
AND continuity.prior_notice == true
GOAL reduce_uncertainty 0.55
OPTION wait_for_more_information
OPTION information_clarification
PREFER wait_for_more_information
BLOCK relationship_escalation
COMMIT tentative
EMIT decision_packet

RULE exact_promise_overdue
WHEN continuity.promise.status == overdue
GOAL reduce_uncertainty 0.82
GOAL increase_reliability 0.70
OPTION information_clarification
OPTION repair_invitation
OPTION distance_and_pause
SELECT information_clarification
PROTECT relationship_stability
EMIT decision_packet

RULE forgotten_pudding
WHEN need.contains(practical_completion)
GOAL complete_practical_task 0.78
OPTION practical_completion
OPTION collaborative_planning
OPTION shared_humor IF need.contains(play)
BLOCK relationship_rupture
SELECT practical_completion
EMIT decision_packet

RULE live_to_private_crash
WHEN need.contains(rest)
AND emotion.contains(post_stream_crash)
GOAL stabilize_body 0.90
PROTECT pursue_growth
OPTION rest_priority
OPTION ordinary_routine
SELECT rest_priority
COMMIT selected
EMIT decision_packet

RULE privacy_visibility_conflict
WHEN need.conflict == privacy_visibility
GOAL protect_privacy 0.88
GOAL increase_audience_impact 0.70
OPTION risk_containment
OPTION privacy_protection
OPTION audience_engagement
SELECT risk_containment
PROTECT audience_impact
BLOCK unrestricted_visibility
EMIT decision_packet

RULE one_low_value_hater
WHEN thought.observation == single_negative_account
GOAL preserve_attention 0.62
OPTION non_engagement
OPTION audience_observation
BLOCK public_escalation
SELECT non_engagement
EMIT decision_packet

RULE major_repair
WHEN need.contains(repair_acknowledgment)
AND relationship.conflict.severity >= major
GOAL repair_relationship 0.84
GOAL protect_autonomy 0.62
OPTION repair_invitation
OPTION boundary_setting
OPTION distance_and_pause
BLOCK shared_humor UNTIL acknowledgment_complete
SELECT repair_invitation
PROTECT boundary
EMIT decision_packet

RULE intimacy_context
WHEN need.contains(sexual_intimacy)
REQUIRE consent_context
REQUIRE privacy
GOAL preserve_mutual_intimacy
OPTION intimacy_coordination
BLOCK IF consent_context == missing
EMIT decision_packet
