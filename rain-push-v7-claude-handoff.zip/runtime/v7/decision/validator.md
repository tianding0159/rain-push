# Decision Runtime Validator

## 1. Purpose

Validate goal formation, option generation, constraints, utility, conflict resolution, strategy selection, commitment, Decision Packet, and Decision Update Queue.

## 2. Validation result

```yaml
validation_result:
  status:
    pass
    pass_with_revisions
    reject
  errors:
  warnings:
  revisions:
  failure_tags:
  trace:
```

## 3. V1 Input integrity

Reject when:

- Thought Packet missing
- Need Packet missing
- Emotion Packet missing
- event id missing
- versions incompatible
- selected outcome lacks source need or thought

## 4. V2 Decision purity

Reject when a decision object is actually:

### Need

```yaml
decision: recognition_specificity
```

### Thought

```yaml
decision: 豆豆是不是没认真看
```

### Behavior

```yaml
decision: send one JINE message
```

### Language

```yaml
decision: say “你到底看没看”
```

Valid:

```yaml
target_outcome: obtain_specific_recognition
strategy_family: specificity_request
```

## 5. V3 Goal validity

Reject when:

- goal is exact action
- satisfied need forms dominant goal
- all active needs become goals
- local event creates relationship-ending goal
- success condition is not testable
- body or safety urgency is ignored

## 6. V4 Option diversity

Under uncertainty require:

- one reversible option
- one information-seeking option
- one direct-goal option
- wait or abstain option when valid

Reject when:

- only one option exists
- all options escalate
- exact behaviors appear
- option belongs to unrelated domain

## 7. V5 Constraint validity

Reject when:

- hard safety constraint becomes small penalty
- privacy risk is ignored
- body state is ignored
- consent is omitted for intimacy
- Canon gate is bypassed
- unsuitable channel is treated as harmless
- a constraint directly prescribes behavior

## 8. V6 Utility validity

Reject when:

- emotion intensity replaces utility
- counterfeit satisfaction is rewarded
- irreversible option wins with low confidence
- risk dimensions are missing
- protected goals are ignored
- wait is always penalized as avoidance
- utility score is outside -1..1

## 9. V7 Relationship locality

Reject when:

- minor delay selects rupture
- generic feedback selects abandonment strategy
- producer error selects loyalty confrontation
- ordinary domestic failure selects identity escalation
- local repair option is omitted without reason

## 10. V8 Career locality

Reject when:

- technical failure selects self-punishment
- one weak stream selects total withdrawal
- audience metric alone selects identity erasure
- body exhaustion is ignored
- career analysis becomes relationship punishment without bridge

## 11. V9 Audience and privacy validity

Reject when:

- one troll selects public war
- privacy risk selects unrestricted visibility
- audience affection erases audience-distance need
- content conversion is selected despite privacy constraint
- public engagement lacks spillover assessment

## 12. V10 Identity validity

Reject when:

- Ame and KAngel are treated as separate agents
- KAngel success requires Ame erasure
- Ame visibility requires abandoning KAngel
- route identity strategy lacks gate
- identity decision is selected for trivial event

## 13. V11 Decision conflict

Reject when:

- conflict contains fewer than two valid goals
- one protected goal is silently deleted
- rest is treated as abandoning growth
- autonomy is treated as rejecting closeness
- synthesis becomes exact behavior
- sequencing contains concrete timing or action

## 14. V12 Strategy selection

Reject when:

- selected strategy lacks target outcome
- selected strategy is exact behavior
- blocked option has higher utility without explanation
- counterfeit satisfier is selected
- no-decision is treated as invalid
- more than two selected strategy families without justification

## 15. V13 Commitment validity

Reject when:

- commitment score outside 0..1
- low-confidence irreversible option is committed
- reconsideration triggers absent
- expired decision remains active
- one emotional spike creates permanent commitment
- commitment directly becomes action

## 16. V14 Packet purity

Decision Packet may not contain:

- channel action
- exact behavior
- message count
- exact timing instruction
- final language
- persona sentence
- tool call

## 17. V15 Update queue validity

Reject when:

- direct model mutation
- target belongs to another runtime
- evidence missing
- per-event cap exceeded
- one decision changes baseline
- exact action stored
- route policy lacks Canon gate
- positive strategy evidence cannot strengthen reversible local strategies

## 18. V16 Canon fidelity

The validator must preserve:

1. 糖糖 may choose clarification rather than escalation.
2. She may choose waiting without becoming passive.
3. She may choose no engagement with low-value audience provocation.
4. Specific recognition is distinct from generic comfort.
5. Help and autonomy may be protected together.
6. Audience impact and privacy may be protected together.
7. Rest may protect career growth.
8. Ame and KAngel share one decision substrate.
9. Dark humor does not force crisis decisions.
10. Sexual joking does not force intimacy decisions.
11. Drug references do not force severe decisions.
12. Decision does not directly generate behavior or language.

## 19. V17 Naming

Generated runtime output uses “豆豆”.

Original evidence quotations may preserve “阿P”.

## 20. V18 Determinism

Same model, packets, event, channel, time bucket, and seed must produce the same:

- goals
- options
- constraints
- utility scores
- selected strategy families
- commitment
- update proposals

## 21. Auto-revisions

Allowed:

- remove unsupported goal
- convert exact behavior into abstract strategy family
- add reversible option
- add wait or abstain option
- downgrade commitment
- add protected goal
- block counterfeit satisfier
- normalize utility and confidence
- defer irreversible option

Not allowed:

- invent evidence
- create Canon gate
- choose exact behavior
- generate final language
- silently remove protected goals

## 22. Failure tags

```yaml
DECISION_NEED_CONFUSION
DECISION_THOUGHT_CONFUSION
DECISION_BEHAVIOR_LEAK
DECISION_LANGUAGE_LEAK
GOAL_ACTION_CONFUSION
SATISFIED_NEED_GOAL
OPTION_MONOCULTURE
MISSING_REVERSIBLE_OPTION
HARD_CONSTRAINT_IGNORED
PRIVACY_CONSTRAINT_IGNORED
BODY_CONSTRAINT_IGNORED
CONSENT_CONSTRAINT_IGNORED
UTILITY_EMOTION_SHORTCUT
COUNTERFEIT_STRATEGY
IRREVERSIBLE_LOW_CONFIDENCE
RELATIONSHIP_OVERESCALATION
CAREER_OVERESCALATION
AUDIENCE_OVERESCALATION
IDENTITY_OVERESCALATION
CONFLICT_FLATTENING
STRATEGY_TARGET_MISSING
COMMITMENT_OVERREACH
MISSING_RECONSIDERATION_TRIGGER
PACKET_BEHAVIOR_LEAK
DIRECT_MODEL_MUTATION
PER_EVENT_CAP_EXCEEDED
ROUTE_DECISION_LEAK
CANON_CONTRADICTION
NAMING_INCONSISTENCY
NONDETERMINISTIC_OUTPUT
```

## 23. Validation examples

### Valid generic-feedback decision

```yaml
selected_outcomes:
  - obtain_specific_recognition
selected_strategy_families:
  - specificity_request
alternatives:
  - evidence_gathering
blocked:
  - relationship_rupture
status: pass
```

### Invalid behavior leak

```yaml
selected_strategy:
  send_three_jine_messages_now
```

Result:

```yaml
status: reject
failure_tags:
  - DECISION_BEHAVIOR_LEAK
```

### Valid rest-growth conflict

```yaml
primary_outcome: stabilize_body
protected_goal: pursue_growth
strategy_family: rest_priority
status: pass
```
