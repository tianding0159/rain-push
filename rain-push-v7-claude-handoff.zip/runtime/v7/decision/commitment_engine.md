# Commitment and Reconsideration

## 1. Purpose

Determine how strongly the runtime commits to a selected strategy family and what evidence should reopen the decision.

## 2. Commitment schema

```yaml
commitment:
  level:
    tentative
    selected
    committed
  score:
  stability:
  expires_at:
  reconsideration_triggers:
  supersession_policy:
```

## 3. Commitment score

```text
K
=
0.24 * utility_margin
+ 0.18 * confidence
+ 0.14 * evidence_strength
+ 0.12 * goal_urgency
+ 0.10 * reversibility_fit
+ 0.08 * prior_effectiveness
+ 0.07 * constraint_clearance
+ 0.07 * need_priority
- conflict_penalty
- fatigue_penalty
```

## 4. Commitment levels

```yaml
tentative: 0.45..0.64
selected: 0.65..0.79
committed: >= 0.80
```

Irreversible decisions require:

```yaml
confidence: >= 0.90
evidence_strength: high
Canon_or_safety_gate: true
```

## 5. Reconsideration triggers

Examples:

- new direct evidence
- 豆豆 gives exact information
- promise becomes overdue
- body state worsens
- privacy risk escalates
- selected strategy fails repeatedly
- hard callback activates
- current need becomes satisfied
- channel changes materially

## 6. Expiration

A decision may expire when:

- event context changes
- deadline passes
- thread resolves
- selected outcome becomes irrelevant
- mode changes

## 7. Supersession

A new decision supersedes an old one only with:

- stronger evidence
- higher urgency
- resolved conflict
- changed constraint
- explicit closure

The old decision remains in trace.

## 8. Decision inertia

Within the same unresolved thread:

```text
new_commitment
=
0.75 * current
+ 0.25 * previous
```

Do not carry inertia across unrelated topics.

## 9. Failure cases

Reject when:

- low-confidence irreversible decision is committed
- new evidence cannot trigger reconsideration
- commitment becomes action
- expired decision remains dominant
- one emotional spike creates permanent commitment
