# Decision Conflict Engine

## 1. Purpose

Resolve conflict among goals and strategy families without flattening protected needs.

## 2. Conflict schema

```yaml
decision_conflict:
  id:
  goal_a:
  goal_b:
  option_a:
  option_b:
  conflict_type:
  evidence_balance:
  urgency_balance:
  protected_goals:
  synthesis_options:
  status:
```

## 3. Conflict types

```yaml
goal_competition:
strategy_incompatibility:
timing_conflict:
privacy_visibility:
closeness_autonomy:
repair_consequence:
rest_growth:
truth_comfort:
play_seriousness:
public_private:
```

## 4. Canonical conflicts

### D01 Closeness vs autonomy

Possible synthesis:

```yaml
strategy_family: collaborative_planning
protected:
  - autonomy
  - closeness
```

### D02 Repair vs consequence

Possible synthesis:

```yaml
strategy_family: repair_invitation
protected_constraint: consequence_remains_visible
```

### D03 Rest vs growth

Possible synthesis:

```yaml
primary_goal: stabilize_body
protected_goal: pursue_growth
```

### D04 Privacy vs audience impact

Possible synthesis:

```yaml
strategy_family: risk_containment
protected_goal: audience_impact
```

### D05 Truth vs comfort

Possible synthesis:

```yaml
strategy_family: honest_evaluation
protected_constraint: relationship_safety
```

### D06 Play vs seriousness

Minor conflict may allow shared humor.

Major conflict requires acknowledgment before humor.

## 5. Conflict score

```text
C
=
min(priority_a, priority_b)
* incompatibility
* simultaneity
* resource_overlap
```

## 6. Resolution methods

```yaml
prioritize_one_protect_one:
sequence:
synthesize:
defer:
abstain:
context_split:
```

## 7. Sequencing

Sequencing is still abstract.

Valid:

```yaml
first_outcome: stabilize_body
later_outcome: career_analysis
```

Invalid:

```yaml
first_action: sleep for 30 minutes
second_action: send message
```

## 8. Failure cases

Reject when:

- conflict has fewer than two valid goals
- one goal is silently deleted
- rest is treated as abandoning career
- autonomy is treated as rejecting closeness
- synthesis becomes exact behavior
