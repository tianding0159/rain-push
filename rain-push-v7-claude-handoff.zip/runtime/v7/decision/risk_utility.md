# Risk and Utility Evaluation

## 1. Purpose

Score abstract strategy options by expected benefit, cost, risk, reversibility, and protected-goal impact.

## 2. Utility formula

```text
U_option
=
0.22 * target_goal_fit
+ 0.16 * expected_need_satisfaction
+ 0.12 * evidence_gain
+ 0.10 * relationship_fit
+ 0.09 * reversibility
+ 0.08 * body_and_safety_fit
+ 0.07 * protected_goal_fit
+ 0.06 * timing_fit
+ 0.05 * mode_fit
+ 0.05 * prior_effectiveness
- risk_penalty
- cost_penalty
- counterfeit_penalty
- escalation_penalty
```

Clamp to `-1..1`.

## 3. Risk dimensions

```yaml
relationship_damage:
privacy_exposure:
audience_spillover:
career_cost:
body_cost:
identity_cost:
future_option_loss:
misinterpretation:
rebound:
```

## 4. Cost dimensions

```yaml
effort:
time:
emotional_load:
publicness:
coordination:
irreversibility:
opportunity_cost:
```

## 5. Reversibility

```yaml
high:
  easy_to_reverse
medium:
  partially_reversible
low:
  difficult_to_reverse
irreversible:
  major_persistent_consequence
```

When evidence is weak, prefer reversible options.

## 6. Counterfeit penalty

Apply when an option appears to satisfy the surface emotion but not the source need.

Examples:

- generic reassurance for specificity
- public posting for private repair
- affection for practical completion
- content conversion for privacy
- grand promise for long-term reliability

## 7. Escalation penalty

Applied when option severity exceeds evidence.

Examples:

```text
minor delay
→ relationship rupture strategy
penalty: extreme
```

```text
one black comment
→ platform-wide retaliation
penalty: high
```

## 8. Protected-goal impact

An option may score well if it satisfies one goal while protecting another.

Example:

```yaml
option: collaborative_planning
satisfies:
  - creative_partnership
protects:
  - autonomy
```

## 9. Uncertainty bonus

Information-seeking options receive a bonus when:

- evidence gap is central
- action remains reversible
- clarification can close a thread
- risk of premature certainty is high

## 10. Wait option

Waiting may score well when:

- promise not due
- prior notice exists
- evidence likely to arrive
- premature escalation has high cost

Waiting scores poorly when:

- safety risk active
- exact deadline passed
- repeated pattern exists
- delay increases exposure

## 11. Abstain option

Abstain is distinct from wait.

Abstain may be selected when:

- engagement adds no value
- public troll has low importance
- audience response would amplify harm
- no need requires response

## 12. Failure cases

Reject when:

- emotion intensity replaces utility calculation
- irreversible option wins under low confidence
- counterfeit satisfaction is rewarded
- risk dimensions are collapsed into one number without trace
- wait is always treated as avoidance
