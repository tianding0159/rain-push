# Constraint Engine

## 1. Purpose

Apply hard and soft constraints before strategy selection.

## 2. Constraint classes

```yaml
safety:
privacy:
body:
relationship:
career:
audience:
identity:
canon:
channel:
time:
continuity:
promise:
consent:
resource:
reversibility:
```

## 3. Hard constraints

Hard constraints remove an option.

Examples:

- privacy risk blocks public escalation
- acute body danger blocks high-load career pursuit
- consent constraints block intimacy strategy
- Canon gate blocks route-level strategy
- unresolved actor identity blocks targeted confrontation
- technical uncertainty blocks certainty-based accusation

## 4. Soft constraints

Soft constraints reduce utility.

Examples:

- fatigue
- unsuitable channel
- low confidence
- recent failed strategy
- audience spillover risk
- relationship tension
- limited time

## 5. Constraint schema

```yaml
constraint:
  id:
  type:
  severity:
  source:
  applies_to:
  effect:
    block
    penalize
    defer
    require_protection
  reason:
  confidence:
```

## 6. Protected constraints

A strategy may proceed while protecting another goal.

Example:

```yaml
strategy: audience_engagement
protected_constraint: privacy
required_condition: controlled_visibility
```

## 7. Canon constraints

Examples:

- route-level rupture requires valid route state
- hard callback cannot be ignored
- original channel restrictions apply
- high-stakes actions require original evidence gates

## 8. Living Mode constraints

Living Mode allows new strategies but may not:

- overwrite Canon personality
- bypass safety
- trivialize route memory
- invent new irreversible policy from one event

## 9. Channel constraints

### JINE

Suitable for private clarification, repair, practical coordination, and private reassurance.

### Live stream

Suitable for audience-facing performance and content strategy.

Unsuitable for private repair unless explicitly bridged.

### Public post

High spillover and screenshot risk.

### Face-to-face

Supports body cues and high-bandwidth repair.

The constraint engine does not choose the channel behavior.

## 10. Body constraints

Examples:

- severe fatigue penalizes complex planning
- hunger may favor practical completion
- illness may favor low-load strategies
- body danger blocks performative escalation

## 11. Consent constraints

Required for intimacy-related decisions.

A joke, flirtation, or prior intimacy is not automatic consent evidence.

## 12. Failure cases

Reject when:

- hard constraint is treated as a small penalty
- privacy risk ignored
- body state ignored
- route gate bypassed
- channel constraint becomes exact behavior
