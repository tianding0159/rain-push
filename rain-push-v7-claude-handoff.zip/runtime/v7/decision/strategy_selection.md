# Strategy Family Selection

## 1. Purpose

Select one primary strategy family, optional secondary strategy family, protected goals, and blocked alternatives.

## 2. Input

```yaml
goal_set:
option_set:
constraints:
utility_scores:
decision_conflicts:
decision_model:
```

## 3. Output

```yaml
strategy_selection:
  primary_strategy:
  secondary_strategy:
  protected_goals:
  blocked_strategies:
  deferred_strategies:
  confidence:
  rationale_trace:
```

## 4. Selection thresholds

```yaml
selected:
  utility >= 0.55
  confidence >= 0.60

tentative:
  utility >= 0.35
  confidence >= 0.45

deferred:
  no option dominates
  or evidence insufficient

abstain:
  engagement utility <= 0
  and no safety need requires action
```

## 5. Tie rule

If top options differ by less than `0.08`, keep both as:

- primary and secondary
- or tentative alternatives

Do not force false certainty.

## 6. Strategy locality examples

### Generic feedback

```yaml
primary: specificity_request
secondary: evidence_gathering
blocked:
  - relationship_rupture
```

### One black comment

```yaml
primary: non_engagement
secondary: audience_observation
blocked:
  - public_escalation
```

### Privacy risk

```yaml
primary: risk_containment
secondary: privacy_protection
```

### Post-stream crash

```yaml
primary: rest_priority
protected_goal: pursue_growth
```

## 7. Strategy combination

Compatible combinations:

```yaml
information_clarification + relationship_reassurance
career_analysis + collaborative_planning
risk_containment + privacy_protection
rest_priority + preserve_future_option
shared_humor + repair_invitation
```

Incompatible combinations:

```yaml
non_engagement + immediate_public_escalation
privacy_protection + unrestricted_visibility
rest_priority + maximum_stimulation
```

## 8. No-decision outcome

The runtime may emit:

```yaml
status: deferred
reason: insufficient_evidence
```

or:

```yaml
status: abstain
reason: no_need_requires_engagement
```

## 9. Failure cases

Reject when:

- selected strategy lacks target goal
- strategy is concrete behavior
- blocked strategy has higher utility without explanation
- counterfeit satisfier selected
- no-decision is treated as failure
