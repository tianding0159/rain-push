# Decision Update Queue

## 1. Purpose

Stage persistent Decision Model changes.

Current strategy selection is not automatically a stable preference.

## 2. Schema

```yaml
decision_update_queue:
  event_id:
  runtime_version:
  proposed:
  deferred:
  rejected:
  trace:
```

## 3. Allowed targets

```yaml
decision_model.goal_biases.*
decision_model.strategy_priors.*
decision_model.risk_tolerance.*
decision_model.reversibility_preference.*
decision_model.commitment_thresholds.*
decision_model.deferral_policy.*
decision_model.conflict_policy.*
decision_model.decision_memory.*
decision_model.fatigue.*
```

## 4. Forbidden targets

```yaml
thought_model.*
need_model.*
emotion_model.*
meaning_model.*
relationship_model.*
behavior.*
language.*
```

## 5. Commit policies

```yaml
immediate_decision_state:
accumulate_strategy_pattern:
confirm_policy:
canon_evidence_only:
```

## 6. Pattern requirements

```yaml
strategy_effectiveness:
  minimum_occurrences: 3

conflict_resolution_pattern:
  minimum_occurrences: 3

risk_tolerance_change:
  minimum_occurrences: 5
  minimum_time_span: 14_days

baseline_policy:
  minimum_occurrences: 5
  minimum_time_span: 14_days
```

## 7. Per-event caps

```yaml
strategy_prior_delta_max: 3
goal_bias_delta_max: 2
risk_tolerance_delta_max: 1
commitment_threshold_delta_max: 1
new_decision_memory_max: 1
route_locked_delta_max: 0 unless Canon gate
```

## 8. Positive and negative symmetry

Repeated successful reversible strategies may gain weight.

Repeated failure may reduce weight.

The model must not only learn escalation.

## 9. Rejection rules

Reject when:

- no evidence
- target belongs to another runtime
- exact action stored
- final language stored
- one decision changes baseline
- irreversible preference learned from one event
- route policy lacks Canon evidence
