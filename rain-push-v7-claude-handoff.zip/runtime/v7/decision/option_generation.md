# Option Generation

## 1. Purpose

Generate abstract strategy-family options for each candidate goal.

Options are not concrete behaviors.

## 2. Input

```yaml
goal_set:
thought_packet:
need_packet:
emotion_packet:
relationship_packet:
decision_model:
channel:
mode:
```

## 3. Output

```yaml
option_set:
  goal_id:
  options:
  blocked_options:
  deferred_options:
  trace:
```

## 4. Option schema

```yaml
option:
  id:
  strategy_family:
  target_goal:
  expected_need_satisfaction:
  expected_emotion_effect:
  information_required:
  constraints:
  reversibility:
  publicness:
  cost:
  risk:
  confidence:
```

## 5. Option families by goal

### reduce_uncertainty

```yaml
information_clarification:
wait_for_more_information:
evidence_gathering:
```

### obtain_specific_recognition

```yaml
specificity_request:
structured_evaluation:
evidence_gathering:
```

### restore_attunement

```yaml
repair_invitation:
specificity_request:
relationship_reassurance:
```

### complete_practical_task

```yaml
practical_completion:
collaborative_planning:
ordinary_routine:
```

### protect_privacy

```yaml
privacy_protection:
risk_containment:
non_engagement:
```

### improve_career_outcome

```yaml
career_analysis:
collaborative_planning:
evidence_gathering:
rest_priority:
```

### maintain_closeness

```yaml
relationship_reassurance:
shared_humor:
future_planning:
```

### preserve_autonomy

```yaml
boundary_setting:
collaborative_planning:
distance_and_pause:
```

## 6. Option diversity

For uncertain situations generate at least:

- one low-risk reversible option
- one information-seeking option
- one direct-goal option
- one wait or abstain option when valid

## 7. Option locality

Options must remain local to the goal.

Invalid:

```text
Goal: obtain specific feedback
Option: end relationship
```

Valid:

```text
Goal: obtain specific feedback
Option: specificity_request
```

## 8. Option count

```yaml
minimum: 2
default: 4
maximum: 7
```

## 9. Blocked options

Block when:

- violates safety
- violates privacy
- exceeds current evidence
- requires unsupported intimacy
- conflicts with Canon gate
- substitutes counterfeit satisfaction
- belongs to a later runtime as exact behavior

## 10. Deferred options

Defer when:

- missing information
- channel unsuitable
- body state impaired
- promise not yet due
- irreversible option has low confidence

## 11. Failure cases

Reject when:

- only one option exists under uncertainty
- all options are high escalation
- exact messages appear
- option ignores need satisfaction
- option belongs to unrelated domain
