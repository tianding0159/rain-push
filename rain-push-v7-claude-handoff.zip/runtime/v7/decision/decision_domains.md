# Decision Domains

## 1. Relationship

```yaml
clarify_relationship_state:
restore_attunement:
repair_local_conflict:
increase_reliability:
maintain_closeness:
protect_autonomy:
set_boundary:
pause_relationship_engagement:
```

## 2. Career

```yaml
analyze_cause:
improve_execution:
obtain_specific_feedback:
protect_energy:
pursue_growth:
preserve_option_value:
coordinate_with_producer:
```

## 3. Audience

```yaml
engage_audience:
preserve_distance:
contain_hate:
protect_privacy:
increase_impact:
observe_audience:
```

## 4. Identity

```yaml
preserve_ame_visibility:
maintain_kangel_performance:
integrate_identity:
protect_private_self:
preserve_future_self:
```

## 5. Ordinary life

```yaml
complete_task:
restore_routine:
obtain_food:
rest:
reduce_stimulation:
increase_stimulation:
share_play:
```

## 6. Body and safety

```yaml
protect_body:
stabilize_body:
reduce_load:
contain_public_risk:
protect_privacy:
seek_trusted_presence:
```

## 7. Internet

```yaml
convert_to_content:
observe_platform:
contain_virality:
use_humor:
avoid_public_spillover:
```

## 8. Domain boundaries

### Need vs decision

```text
Need:
recognition_specificity

Decision:
obtain_specific_recognition
```

### Decision vs strategy family

```text
Decision outcome:
reduce_uncertainty

Strategy family:
information_clarification
```

### Strategy family vs behavior

```text
Strategy family:
information_clarification

Behavior:
ask one question in JINE
```

### Behavior vs language

```text
Behavior:
ask one question

Language:
“几点回来？”
```

## 9. Multi-domain decision

Example:

```yaml
primary_outcome: protect_privacy
secondary_outcome: preserve_audience_impact
selected_strategy: risk_containment
protected_constraint: controlled_visibility
```

## 10. Invalid overreach

Do not turn:

```yaml
outcome: restore_attunement
```

into:

```yaml
behavior: send five messages
```

Phase 8 stops before behavior selection.
