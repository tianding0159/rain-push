# Phase 8: Decision Runtime

## Status

- Version: `7.0-phase8`
- Runtime name: `Decision Runtime`
- Partner display name: `豆豆`
- Depends on:
  - Knowledge Packet
  - Continuity Packet
  - Relationship Packet
  - Meaning Packet
  - Emotion Packet
  - Need Packet
  - Thought Packet
- Produces:
  - Decision Packet
  - Decision Update Queue
- Does not produce:
  - concrete behavior
  - channel action
  - message count
  - exact timing instruction
  - final language
  - persona rendering
  - tool call

## Single responsibility

Decision Runtime answers:

> 在当前事实、关系、意义、情绪、需求和思考之上，糖糖此刻准备优先追求什么结果，采用哪一类抽象策略，放弃哪些策略，以及她对这个选择有多大承诺？

Decision Runtime does not decide:

- 是否发 JINE
- 是否直播
- 是否发推
- 是否沉默多久
- 发几条消息
- 具体说什么
- 使用什么标点或口癖

Those belong to Phase 9–11.

## Core distinction

```text
Need:
需要降低不确定性。

Thought:
豆豆的回归时间仍不明确。

Decision:
优先取得可验证的时间边界。
Selected strategy family:
information_clarification

Behavior:
通过私聊提出一个直接问题。

Language:
“几点回来？”
```

Only the Decision layer belongs to Phase 8.

## Pipeline

```text
Knowledge Packet
+ Continuity Packet
+ Relationship Packet
+ Meaning Packet
+ Emotion Packet
+ Need Packet
+ Thought Packet
        |
        v
Goal Formation
        |
        v
Decision Domain Activation
        |
        v
Option Generation
        |
        v
Constraint Engine
        |
        v
Risk / Utility Evaluation
        |
        v
Decision Conflict Resolution
        |
        v
Strategy Family Selection
        |
        v
Commitment / Deferral
        |
        v
Decision Packet
        |
        +--> Decision Update Queue
        |
        v
Validator
```

## Architectural invariants

1. Decision is distinct from need.
2. Decision is distinct from thought.
3. Decision is distinct from behavior.
4. A decision chooses an outcome and strategy family, not an exact action.
5. Abstaining, waiting, or deferring may be valid decisions.
6. More intense emotion does not automatically win.
7. Body and safety constraints may override career or relationship goals.
8. Multiple goals may coexist, but the active decision budget is limited.
9. Every selected strategy must identify its intended need satisfaction.
10. Counterfeit satisfaction must not be selected as optimal.
11. Canon and Living Mode gates remain explicit.
12. Same inputs and seed produce the same Decision Packet.
