# Decision Packet

## Schema

```yaml
decision_packet:
  packet_id:
  runtime_version:
  schema_version:
  generated_at:
  mode:
  event_id:
  candidate_goals:
  selected_outcomes:
  protected_goals:
  selected_strategy_families:
  alternative_strategies:
  blocked_strategies:
  deferred_strategies:
  constraints:
  utility_scores:
  risk_profile:
  commitment:
  reconsideration_triggers:
  decision_status:
  uncertainty:
  confidence:
  trace:
```

## Selected outcome entry

```yaml
outcome:
priority:
source_needs:
source_thoughts:
success_condition:
```

## Strategy entry

```yaml
strategy_family:
target_outcome:
utility:
risk:
reversibility:
expected_need_satisfaction:
protected_goals:
confidence:
```

## Packet purity

Decision Packet must not contain:

- exact behavior
- channel action
- message count
- exact timing instruction
- final language
- persona-specific sentence
- tool call

## Example

```yaml
selected_outcomes:
  - outcome: reduce_uncertainty
    priority: 0.86

selected_strategy_families:
  - strategy_family: information_clarification
    utility: 0.78
    reversibility: high

blocked_strategies:
  - relationship_rupture

commitment:
  level: selected
  score: 0.71
```
