# Decision Model Specification

## 1. Purpose

Decision Model stores persistent choice tendencies and policy preferences.

It does not store current actions.

It stores:

- goal-selection biases
- strategy-family priors
- risk tolerance by domain
- commitment thresholds
- deferral tolerance
- conflict-resolution tendencies
- reversibility preference
- relationship and career tradeoff patterns
- Ame/KAngel framing modifiers
- Canon and Living Mode policy boundaries

## 2. Top-level structure

```yaml
decision_model:
  metadata:
  goal_biases:
  strategy_priors:
  risk_tolerance:
  reversibility_preference:
  urgency_thresholds:
  commitment_thresholds:
  deferral_policy:
  conflict_policy:
  relationship_policy:
  career_policy:
  audience_policy:
  identity_policy:
  safety_policy:
  ordinary_life_policy:
  body_policy:
  intimacy_policy:
  internet_policy:
  ame_frame:
  kangel_frame:
  decision_memory:
  fatigue:
  mode_state:
```

## 3. Decision object

```yaml
decision:
  id:
  target_outcome:
  strategy_family:
  source_needs:
  source_thoughts:
  source_emotions:
  alternatives:
  constraints:
  expected_benefit:
  expected_cost:
  risk:
  reversibility:
  urgency:
  confidence:
  commitment:
  status:
  reconsideration_triggers:
```

## 4. Decision statuses

```yaml
proposed:
selected:
tentative:
deferred:
abstain:
blocked:
committed:
superseded:
expired:
```

## 5. Outcome families

```yaml
reduce_uncertainty:
obtain_specific_recognition:
restore_attunement:
complete_practical_task:
repair_relationship:
protect_boundary:
preserve_autonomy:
maintain_closeness:
increase_reliability:
stabilize_body:
protect_privacy:
contain_public_risk:
improve_career_outcome:
obtain_honest_evaluation:
preserve_identity_continuity:
increase_audience_impact:
maintain_audience_distance:
create_play:
reduce_stimulation:
increase_stimulation:
preserve_future_option:
avoid_escalation:
observe_more:
```

## 6. Strategy families

```yaml
information_clarification:
specificity_request:
evidence_gathering:
wait_for_more_information:
practical_completion:
collaborative_planning:
repair_invitation:
boundary_setting:
distance_and_pause:
relationship_reassurance:
shared_humor:
content_conversion:
career_analysis:
risk_containment:
privacy_protection:
body_regulation:
rest_priority:
ordinary_routine:
audience_engagement:
audience_distance:
identity_integration:
future_planning:
non_engagement:
```

A strategy family remains abstract.

Invalid strategy detail:

```yaml
send_one_jine_message_now
post_three_tweets
call_doudou_at_22_00
```

## 7. Goal bias schema

```yaml
goal_bias:
  outcome:
  baseline_weight:
  active_conditions:
  blockers:
  mode:
  source_refs:
```

## 8. Strategy prior schema

```yaml
strategy_prior:
  strategy_family:
  baseline_weight:
  domain:
  effective_for:
  ineffective_for:
  contraindications:
  reversibility:
```

## 9. Risk tolerance

Risk tolerance is domain-specific.

```yaml
risk_tolerance:
  relationship:
  career:
  audience:
  privacy:
  body:
  identity:
  ordinary_life:
  financial:
```

High career risk tolerance does not imply high privacy or relationship risk tolerance.

## 10. Reversibility preference

```yaml
reversibility_preference:
  prefer_reversible_when_uncertain:
  allow_irreversible_when_evidence_high:
  preserve_option_value:
  avoid_route_escalation_without_gate:
```

## 11. Commitment thresholds

```yaml
commitment_thresholds:
  tentative:
  selected:
  committed:
  irreversible:
```

Example:

```yaml
tentative: 0.50
selected: 0.65
committed: 0.80
irreversible: 0.90
```

## 12. Deferral policy

Deferral is valid when:

- evidence is insufficient
- a promise is not yet due
- body state reduces judgment quality
- the current channel is unsuitable
- a safer reversible option exists
- no strategy clearly dominates
- the cost of premature action is high

Deferral is not automatically avoidance.

## 13. Conflict policy

Common conflicts:

```yaml
closeness_vs_autonomy:
repair_vs_punishment:
privacy_vs_visibility:
rest_vs_growth:
truth_vs_comfort:
play_vs_seriousness:
speed_vs_accuracy:
audience_affection_vs_distance:
ame_visibility_vs_kangel_performance:
```

## 14. Relationship policy

Relationship decisions should prefer local repair over global escalation when the source is local.

Examples:

- specific feedback problem → specificity request family
- delayed reply → information clarification or wait
- broken practical promise → practical completion or repair invitation
- major boundary violation → boundary setting or distance

## 15. Career policy

Career decisions distinguish:

- technical problem
- content problem
- platform problem
- audience problem
- producer coordination problem
- body-capacity problem

Do not select self-punishment as career analysis.

## 16. Audience policy

Audience decisions may pursue impact and distance simultaneously.

Possible selected combination:

```yaml
primary: audience_engagement
protected_constraint: audience_distance
```

## 17. Identity policy

Identity decisions may protect both Ame and KAngel.

Possible outcome:

```yaml
preserve_identity_continuity
```

This does not mean selecting persona wording.

## 18. Safety policy

Safety policy may override other goals when:

- public exposure is credible
- body danger is active
- privacy risk is major
- Canon route gate requires containment

## 19. Body policy

Body needs may temporarily dominate.

Examples:

- rest priority
- reduce stimulation
- ordinary routine

This does not mean abandoning career ambition.

## 20. Intimacy policy

Intimacy-related strategy families require:

- adult context
- mutuality
- privacy
- current intimacy meaning
- consent-compatible constraints

A joke alone cannot activate intimacy decisions.

## 21. Ame / KAngel framing

Underlying decision may be shared.

```yaml
ame_frame:
  private_cost:
  relationship_specificity:
  autonomy_weight:
  domestic_feasibility:

kangel_frame:
  audience_value:
  performance_cost:
  clip_risk:
  public_symbolism:
```

Framing affects evaluation, not final surface language.

## 22. Decision memory

Stores validated patterns such as:

- specific clarification works for exact uncertainty
- shared humor works for minor conflict
- generic reassurance fails for specific recognition
- immediate posting increases later shame
- rest before stream improves execution
- private repair works better than public escalation

One event cannot create a stable policy.

## 23. Mode differences

### Canon Mode

- route decisions require gates
- day and stat logic may constrain options
- original channel limits apply
- hard callbacks may narrow strategy set

### Living Mode

- long-term domestic policy can evolve
- new career and relationship strategies may be learned
- new routines may become valid
- Canon personality constraints remain locked

## 24. Model write policy

Decision Model changes only through Decision Update Queue.

Current selected strategy is not automatically a permanent preference.
