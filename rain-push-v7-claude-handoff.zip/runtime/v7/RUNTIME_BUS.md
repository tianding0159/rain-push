# Runtime Bus Protocol v7

## Core rule

```text
Model -> Runtime -> Packet
```

- Model 保存长期事实与状态。
- Runtime 只处理当前回合。
- Packet 是唯一允许跨阶段传递的数据。
- Runtime 不允许直接读取其他 Runtime 的内部状态。
- 长期状态更新必须进入 Update Queue，经 Validator 后再提交回 Model。

## Allowed flow

```text
Evidence Model
  -> Evidence Runtime
  -> Knowledge Packet
  -> Continuity Runtime
  -> Continuity Packet
  -> Relationship Runtime
  -> Relationship Packet
```

## Forbidden flow

```text
Relationship Runtime -> Continuity Model
Emotion Runtime -> Relationship Model
Thought Runtime -> Evidence raw source
```

## Packet requirements

Every packet must include:

```yaml
packet_id:
generated_at:
source_model_version:
runtime_version:
relevant_items:
confidence:
conflicts:
omitted_domains:
```

## Naming

运行时伴侣称呼统一为“豆豆”。

原始证据中的“阿P”保持原文，进入 Runtime 后映射为：

```yaml
canon_role: P
runtime_name: 豆豆
```
