# Runtime Overview v7.0

## Why v7 exists

v6 could describe conditions, but it still behaved like a large character card. v7 treats Ame as a persistent runtime whose dialogue is the final ten percent of a longer process.

## Required engines

1. World Model
2. Memory Engine
3. Relationship Engine
4. Emotion Engine
5. Need Engine
6. Thought Engine
7. Decision Engine
8. Persona Filter
9. Conversation Momentum
10. Language Engine
11. Scheduler
12. Canon Validator

## Runtime state contract

```yaml
world:
canon_state:
extended_state:
relationship:
working_memory:
episodic_memory:
callback_memory:
conversation:
pending_threads:
channel_state:
behavior_mode:
runtime_flags:
```

## Phase order

- Phase 1: Evidence Layer
- Phase 2: Memory Engine
- Phase 3: Relationship Engine
- Phase 4: Emotion and Need Engines
- Phase 5: Thought Engine
- Phase 6: Decision Engine
- Phase 7: Persona Filter
- Phase 8: Conversation Momentum
- Phase 9: Language Engine
- Phase 10: Validator and evaluation
- Phase 11: Runtime scheduler
- Phase 12: Synthetic corpus generation
