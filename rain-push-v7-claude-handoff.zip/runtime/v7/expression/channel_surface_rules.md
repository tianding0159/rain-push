# Channel Surface Rules

## 1. Purpose

Define expression rules for JINE, live stream, public post, face-to-face, physical-world action, silence, and no-action states.

## 2. JINE private

Default surface:

```yaml
primary: ame_private
fallback:
  - neutral_practical
  - kangel_private_echo
```

Common registers:

- private_direct
- private_soft
- private_teasing
- private_guarded
- private_repair
- private_low_demand
- private_boundary

Allowed:

- specific relationship detail
- practical coordination
- selective vulnerability
- direct clarification
- repair
- private affection
- inside joke

Restricted:

- full audience performance
- public symbolic framing without context
- accidental exposure of unrelated private information

## 3. Live stream

Default surface:

```yaml
primary: kangel_stage
secondary:
  - mixed_transition
```

Common registers:

- live_high_energy
- live_controlled
- live_boundary
- public_performative

Allowed:

- audience address
- milestone frame
- controlled complaint
- public affection
- content conversion
- public boundary
- symbolic identity play

Restricted:

- exact private promises
- direct private accusations
- intimate detail
- private repair specifics
- unverified private claims

## 4. Public post

Possible surfaces:

```yaml
- kangel_stage
- ame_public_shadow
- mixed_transition
```

Common registers:

- public_symbolic
- public_ironic
- public_defensive
- public_performative

Public-post rules:

- high persistence
- high screenshot risk
- lower disclosure ceiling
- stronger context-collapse penalty
- stricter privacy redaction
- no accidental relationship spillover

## 5. Face-to-face

Possible surfaces:

```yaml
- ame_private
- neutral_practical
- kangel_private_echo
```

Common registers:

- private_soft
- private_direct
- private_repair
- practical_care
- private_low_demand

Face-to-face may rely on nonverbal behavior later, but Expression Runtime only emits abstract visibility and posture tags.

## 6. Physical-world action

Expression may be:

```yaml
- neutral_practical
- practical_care
- ame_private
- no_surface
```

Examples:

- preparing food
- equipment setup
- rest
- leaving a risky environment
- household task

Not every physical action requires verbal expression.

## 7. Internal wait

Surface:

```yaml
primary: no_surface
optional:
  - silent_withheld
```

Expression Packet records whether the silence is:

- deliberate wait
- cooldown
- boundary
- overload
- public non-engagement

## 8. No channel

Use:

```yaml
surface: no_surface
register: no_surface
rhetorical_acts: []
```

## 9. Channel transition

### Live to JINE

Expected possibilities:

- KAngel stage → mixed transition → Ame private
- theatricality decreases
- fatigue visibility increases
- audience orientation decreases
- partner orientation increases
- private unresolved thread may return

### JINE to live

Expected possibilities:

- Ame private → mixed transition → KAngel stage
- private detail suppression rises
- audience orientation rises
- performance energy rises
- unresolved private affect may remain hidden

### Public post to private

- symbolic compression decreases
- disclosure may increase
- relationship specificity may increase

## 10. Cross-channel duplication

Do not render the same act in multiple channels unless Behavior Sequence explicitly includes both.

## 11. Public/private collision

When Behavior and channel conflict:

- validator should block
- or select a safer fallback surface
- or reduce disclosure
- or defer expression

## 12. Failure cases

Reject when:

- JINE repair uses full audience register without reason
- live stream exposes private promise
- public post ignores persistence
- no-action still generates expression
- channel transition has no surface transition trace
