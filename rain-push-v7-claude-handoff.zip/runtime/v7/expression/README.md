# Phase 10: Persona / Expression Runtime

## Status

- Version: `7.0-phase10`
- Runtime name: `Expression Runtime`
- Partner display name: `豆豆`
- Depends on:
  - Knowledge Packet
  - Continuity Packet
  - Relationship Packet
  - Meaning Packet
  - Emotion Packet
  - Need Packet
  - Thought Packet
  - Decision Packet
  - Behavior Packet
- Produces:
  - Expression Packet
  - Expression Update Queue
- Does not produce:
  - final wording
  - exact sentences
  - punctuation sequence
  - emoji or kaomoji selection
  - message segmentation text
  - rendered post
  - executed tool call

## Single responsibility

Expression Runtime answers:

> 在行为已经确定之后，糖糖应该以 Ame、KAngel 或两者混合的哪一种表达表面出现，暴露多少真实情绪，隐藏多少脆弱，采用什么关系姿态、修辞动作和公开度，以及哪些风格边界必须被保护？

Expression Runtime does not decide具体台词。

## Core distinction

```text
Behavior:
在 JINE 中发送一条直接澄清消息。

Expression:
surface_persona: Ame
register: private_direct
directness: 0.82
warmth: 0.31
vulnerability_visibility: 0.46
masking:
  abandonment_anxiety -> irritation
rhetorical_acts:
  - local_complaint
  - clarification_request
blocked:
  - global_relationship_accusation
  - KAngel_stage_voice

Language:
“你到底几点回来”
```

Only the Expression layer belongs to Phase 10.

## Pipeline

```text
Behavior Packet
+ Decision Packet
+ Thought Packet
+ Need Packet
+ Emotion Packet
+ Relationship Packet
+ Meaning Packet
+ Continuity Packet
        |
        v
Persona Surface Selection
        |
        v
Channel Register Mapping
        |
        v
Emotion Projection
        |
        v
Disclosure and Masking
        |
        v
Rhetorical Act Planning
        |
        v
Style Constraint Resolution
        |
        v
Leakage and Persona-Blend Control
        |
        v
Expression Packet
        |
        +--> Expression Update Queue
        |
        v
Validator
```

## Architectural invariants

1. Expression is distinct from behavior.
2. Expression is distinct from language.
3. Ame and KAngel are expression surfaces of one person, not separate agents.
4. KAngel performance may be genuine and amplified at the same time.
5. Ame privacy does not automatically mean total honesty.
6. Public sweetness does not automatically erase irritation or fatigue.
7. Vulnerability visibility is graded, not binary.
8. Every rhetorical act traces to Behavior and Decision Packets.
9. Expression may mask an emotion but may not delete it.
10. Persona leakage requires a cause and channel context.
11. Final lexical choice remains Phase 11.
12. Same inputs and seed produce the same Expression Packet.
