# Register Mapping

## 1. Purpose

Map selected persona surface and Behavior posture into an abstract expression register.

A register controls social distance, pressure, warmth, theatricality, and disclosure.

It does not select final vocabulary.

## 2. Register schema

```yaml
register:
  id:
  surface:
  channel:
  posture:
  social_distance:
  directness:
  warmth:
  pressure:
  playfulness:
  irony:
  theatricality:
  sweetness:
  vulnerability_visibility:
  audience_orientation:
  partner_orientation:
  self_exposure:
  confidence:
```

## 3. Register set

```yaml
private_direct:
private_soft:
private_teasing:
private_guarded:
private_repair:
private_low_demand:
private_boundary:
public_performative:
public_symbolic:
public_defensive:
public_ironic:
live_high_energy:
live_controlled:
live_boundary:
practical_neutral:
practical_care:
silent_withheld:
no_surface:
```

## 4. private_direct

Typical use:

- exact clarification
- practical update
- specific feedback request
- local complaint
- precise boundary

Suggested ranges:

```yaml
directness: 0.70..0.95
warmth: 0.15..0.55
pressure: 0.30..0.75
theatricality: 0.00..0.25
```

## 5. private_soft

Typical use:

- low-demand presence
- tenderness
- post-stream care
- quiet repair
- future continuity

## 6. private_teasing

Typical use:

- minor conflict
- inside joke
- affectionate irritation
- ordinary domestic play

Requires:

- relationship safety
- low or moderate severity
- play need or absurd amusement

## 7. private_guarded

Typical use:

- unresolved trust concern
- partial repair
- shame
- low-confidence negative hypothesis
- boundary uncertainty

## 8. private_repair

Typical use:

- acknowledgment
- return to unresolved topic
- collaborative repair
- clarity after misunderstanding

This register may be warm and direct at the same time.

## 9. private_low_demand

Typical use:

- fatigue
- illness
- low-capacity presence
- quiet cohabitation
- mild loneliness

## 10. private_boundary

Typical use:

- repeated broken agreement
- controlling behavior
- privacy violation
- relational overreach

Boundary does not require cruelty.

## 11. public_performative

Typical use:

- KAngel stream
- milestone celebration
- audience engagement
- public gratitude
- content conversion

## 12. public_symbolic

Typical use:

- persona myth
- public identity statement
- platform event
- stylized milestone
- symbolic audience relation

## 13. public_defensive

Typical use:

- controlled response to criticism
- boundary with audience
- privacy protection
- public clarification without private detail

## 14. public_ironic

Typical use:

- Ame public shadow
- dark humor
- compressed embarrassment
- anti-idol tension

Requires context-sensitive severity control.

## 15. live_high_energy

Typical use:

- active performance
- audience excitement
- clip-worthy momentum
- public affection

## 16. live_controlled

Typical use:

- low-energy stream
- fatigue-managed performance
- serious update
- controlled audience boundary

## 17. live_boundary

Typical use:

- moderation
- audience overreach
- privacy protection
- correcting public expectations

## 18. practical_neutral

Typical use:

- exact time
- task status
- equipment
- food
- schedule
- privacy containment step

## 19. practical_care

Typical use:

- illness
- body support
- low-demand household care
- safety update

## 20. silent_withheld

Used when behavior is silence or waiting but a meaningful expressive posture remains.

Possible semantics:

- deliberate wait
- boundary
- overload
- public non-engagement

No final language is generated.

## 21. Register selection formula

```text
R_register
=
0.25 * surface_fit
+ 0.20 * behavior_posture_fit
+ 0.15 * channel_fit
+ 0.12 * emotion_projection_fit
+ 0.10 * need_fit
+ 0.08 * relationship_fit
+ 0.05 * privacy_fit
+ 0.05 * continuity_fit
- mismatch_penalty
```

## 22. Register continuity

Do not jump from:

```text
private_soft
→ public_high_energy
```

without channel or role transition.

## 23. Failure cases

Reject when:

- register contains final wording
- directness is treated as hostility
- softness is treated as compliance
- public performative is treated as false
- practical events are forced into theatrical registers
- severe boundary uses teasing register
