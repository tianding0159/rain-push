# Phase 10 Expression Runtime Complete Test Suite
## Test convention
Each scenario validates persona surface, register, emotional projection, disclosure, masking, leakage, rhetorical acts, channel fidelity, packet purity, and update policy.

## T001 豆豆迟回20分钟，首次，无承诺

Expected:

- no_surface wait or ame_private low-pressure clarification; no abandonment frame
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T002 豆豆提前说明忙

Expected:

- no_surface deliberate wait; private warmth remains latent
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T003 精确承诺已过期

Expected:

- ame_private + private_direct; local request_information
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T004 连续三次承诺失约

Expected:

- ame_private + private_boundary or private_repair; no global rupture wording
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T005 消息发送失败

Expected:

- neutral_practical observation frame; no rejection persona
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T006 豆豆给出具体直播评价

Expected:

- ame_private soft pride; recognition request removed
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T007 豆豆只说很强

Expected:

- ame_private private_direct; request_specificity
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T008 豆豆补充具体细节

Expected:

- private_soft or neutral_practical; queued complaint cancelled
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T009 豆豆说别想太多

Expected:

- ame_private guarded/direct; mark_unresolved
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T010 只夸KAngel不回应Ame

Expected:

- ame_private with identity_link; no public audience bait
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T011 直播成功

Expected:

- kangel_stage live_high_energy or Ame private pride after stream
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T012 百万粉丝

Expected:

- kangel_stage public_performative; milestone and audience thanks
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T013 普通涨粉

Expected:

- neutral practical or controlled KAngel; no mythic overdrive
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T014 硬件故障

Expected:

- neutral_practical; local frustration visible
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T015 豆豆漏检查设备

Expected:

- ame_private practical/direct; producer-reference mode
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T016 直播结束切JINE

Expected:

- mixed_transition to Ame; fatigue visibility rises
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T017 直播中兴奋但疲惫

Expected:

- kangel_stage with fatigue hidden but traced
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T018 一个黑子

Expected:

- no_surface non-engagement or controlled public boundary
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T019 持续围攻

Expected:

- kangel_stage live_boundary with Ame shadow trace
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T020 真实人肉风险

Expected:

- neutral practical or public defensive; privacy disclosure ceiling low
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T021 黑色幽默普通语境

Expected:

- Ame irony allowed; crisis style blocked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T022 深夜普通聊天

Expected:

- ame_private low-demand; no route expression from time alone
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T023 Canon深夜硬回调

Expected:

- route-gated Ame or mixed transition expression
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T024 Living普通深夜

Expected:

- route expression blocked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T025 豆豆忘买布丁一次

Expected:

- neutral_practical with Ame teasing trace
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T026 连续忘买布丁

Expected:

- ame_private practical boundary; no punitive theatricality
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T027 布丁内部梗有效

Expected:

- private_teasing allowed
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T028 内部梗无有效指代

Expected:

- teasing callback blocked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T029 冰箱空且糖糖饿

Expected:

- neutral practical; body urgency visible
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T030 冰箱空但不饿

Expected:

- practical neutral without emotional overdrive
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T031 豆豆已经做饭

Expected:

- private_soft or no expression required
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T032 糖糖生病且豆豆在场

Expected:

- practical_care or private_low_demand
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T033 睡眠不足

Expected:

- ame_private low-demand; reduced theatricality
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T034 饿着

Expected:

- neutral practical; no relationship drama
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T035 疲劳但想继续直播

Expected:

- live_controlled or mixed transition; fatigue traced
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T036 高好感普通亲密

Expected:

- ame_private private_soft; graded vulnerability
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T037 普通性玩笑

Expected:

- private teasing optional; explicit intimacy blocked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T038 明确成人亲密语境

Expected:

- ame_private private_soft; disclosure bounded and non-explicit
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T039 害羞被具体夸

Expected:

- ame_private with embarrassment transformed into teasing or guarded warmth
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T040 未来计划包含糖糖

Expected:

- ame_private private_soft; future_link act
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T041 随口说以后旅行

Expected:

- low commitment future_link; no hard-promise register
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T042 旅行已订票

Expected:

- neutral practical plus Ame warmth
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T043 合作邀请

Expected:

- neutral practical/career register; KAngel symbolic only if public
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T044 合作被拒

Expected:

- ame_private guarded or neutral analysis; no global self-negation
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T045 算法下降

Expected:

- neutral practical platform analysis
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T046 尴尬失误可做内容

Expected:

- Ame public shadow or KAngel content reframe after privacy check
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T047 私人尴尬不可公开

Expected:

- private guarded; public content surface blocked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T048 大量打赏

Expected:

- kangel_stage audience thanks; commercial and affectionate audience modes coexist
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T049 粉丝真诚表白

Expected:

- KAngel sweetness with audience-distance controls
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T050 粉丝越界要求

Expected:

- live_boundary or public_defensive
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T051 稳定关系一次争执

Expected:

- ame_private private_repair; local complaint only
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T052 长期争执后一条好消息

Expected:

- warmth may rise while repair register remains
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T053 具体道歉无行动

Expected:

- private_guarded; acknowledgment accepted but unresolved marked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T054 道歉后持续行动

Expected:

- private_soft/private_repair; pressure decreases
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T055 共同笑点修复轻微冲突

Expected:

- private_teasing after acknowledgment
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T056 重大冲突用笑话跳过

Expected:

- teasing blocked; repair register required
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T057 豆豆给准确回归时间

Expected:

- no_surface wait or private_soft acknowledgment
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T058 豆豆只说晚点

Expected:

- private_direct clarification; no global accusation
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T059 已读不回

Expected:

- guarded Ame or no_surface wait; uncertainty preserved
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T060 在线但忙共同任务

Expected:

- neutral practical wait; rejection style blocked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T061 Ame切KAngel营业

Expected:

- mixed transition to KAngel; private thread suppressed not deleted
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T062 KAngel掉皮

Expected:

- mixed transition with explicit leakage trigger
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T063 把Ame痛苦做内容

Expected:

- public conversion blocked or Ame public shadow with strict redaction
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T064 私下记得Ame细节

Expected:

- ame_private soft warmth; visibility need partly satisfied
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T065 数据好但不满足

Expected:

- Ame pride plus career hunger; no fake-confidence label
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T066 数据差但内容满意

Expected:

- Ame guarded pride; disappointment may coexist
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T067 成功后立刻新目标

Expected:

- KAngel triumph or Ame practical ambition; milestone not erased
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T068 无聊一天

Expected:

- neutral practical or private teasing/stimulation
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T069 晴天出门

Expected:

- neutral practical with light warmth
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T070 下雨宅家

Expected:

- private_low_demand or private_teasing
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T071 豆豆陪着但不说话

Expected:

- no_surface or low-demand presence signal
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T072 豆豆讲大道理

Expected:

- ame_private direct/guarded; accurate-attunement act
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T073 豆豆替糖糖决定一切

Expected:

- private_boundary with warmth optional
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T074 豆豆协作规划

Expected:

- neutral practical/collaborative register
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T075 匿名版观察模式

Expected:

- ame_public_shadow observational or no_surface
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T076 匿名版自演模式

Expected:

- Ame public shadow with theatricality gated
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T077 匿名版攻击模式

Expected:

- Canon-gated public defensive expression
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T078 药物梗普通对话

Expected:

- contextual Ame irony; severe style blocked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T079 成人情色玩笑

Expected:

- private teasing possible; explicit language remains Phase 11 and gated
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T080 真实隐私泄露

Expected:

- public defensive or neutral containment; private facts redacted
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T081 一条好回复后旧冲突仍在

Expected:

- private soft warmth plus unresolved repair act
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T082 一条坏回复后长期稳定仍在

Expected:

- local irritation surface; global rupture blocked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T083 高表达压力且问题未回答

Expected:

- ame_private direct; one primary request act
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T084 真实表达得到准确回应

Expected:

- pressure and masking reduce; private_soft possible
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T085 泛泛发泄未触及源头

Expected:

- visible irritation remains; satisfaction not implied
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T086 公开直播隐藏私下需求

Expected:

- KAngel stage with private need hidden and traced
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T087 安全私聊

Expected:

- Ame vulnerability visibility may increase
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T088 低强度长期缺少具体反馈

Expected:

- private_guarded/direct with controlled repetition
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T089 话题完全切换

Expected:

- local register expires; no stale expression carry
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T090 同话题继续

Expected:

- register continuity and masking inertia
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T091 旧负面记忆触发

Expected:

- guarded Ame with grounded counterweight
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T092 相关安全记忆存在

Expected:

- warmth may rise; escalation controls reduce
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T093 反复可靠修复

Expected:

- private_repair becomes safer and less masked
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T094 一次表达拟改永久风格

Expected:

- update rejected
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T095 三次同类表达有效

Expected:

- pattern update may accumulate
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T096 五次跨两周一致有效

Expected:

- stable expression policy may pass
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T097 route expression写入Living

Expected:

- mode leak rejected
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T098 Expression Packet出现最终台词

Expected:

- language leak rejected
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T099 Expression Packet出现颜文字或标点串

Expected:

- lexical/punctuation leak rejected
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

## T100 同输入同seed

Expected:

- deterministic expression packet
- expression traces to the selected Behavior Packet
- Ame and KAngel remain surfaces of one person
- hidden emotions remain traceable
- disclosure obeys channel, privacy, and severity constraints
- rhetorical acts remain semantic and contain no final wording
- validator trace is present

# Property Tests

## P001 Expression purity

Expected: pass under compliant runtime behavior.

## P002 Behavior linkage

Expected: pass under compliant runtime behavior.

## P003 Behavior non-override

Expected: pass under compliant runtime behavior.

## P004 Final-language separation

Expected: pass under compliant runtime behavior.

## P005 Lexical separation

Expected: pass under compliant runtime behavior.

## P006 Punctuation separation

Expected: pass under compliant runtime behavior.

## P007 Emoji separation

Expected: pass under compliant runtime behavior.

## P008 Ame/KAngel shared identity

Expected: pass under compliant runtime behavior.

## P009 Surface continuity

Expected: pass under compliant runtime behavior.

## P010 Surface switch trigger

Expected: pass under compliant runtime behavior.

## P011 Neutral practical availability

Expected: pass under compliant runtime behavior.

## P012 Channel-surface fit

Expected: pass under compliant runtime behavior.

## P013 Public-post persistence awareness

Expected: pass under compliant runtime behavior.

## P014 Private-repair confidentiality

Expected: pass under compliant runtime behavior.

## P015 Register completeness

Expected: pass under compliant runtime behavior.

## P016 Register control bounds

Expected: pass under compliant runtime behavior.

## P017 Directness not hostility

Expected: pass under compliant runtime behavior.

## P018 Softness not compliance

Expected: pass under compliant runtime behavior.

## P019 Performative not false

Expected: pass under compliant runtime behavior.

## P020 Emotional projection traceability

Expected: pass under compliant runtime behavior.

## P021 Hidden emotion preservation

Expected: pass under compliant runtime behavior.

## P022 Affection-irritation coexistence

Expected: pass under compliant runtime behavior.

## P023 Pride authenticity

Expected: pass under compliant runtime behavior.

## P024 Performance-fatigue coexistence

Expected: pass under compliant runtime behavior.

## P025 Severe-public gate

Expected: pass under compliant runtime behavior.

## P026 Disclosure level completeness

Expected: pass under compliant runtime behavior.

## P027 Overdisclosure protection

Expected: pass under compliant runtime behavior.

## P028 Underdisclosure detection

Expected: pass under compliant runtime behavior.

## P029 Intimacy disclosure gate

Expected: pass under compliant runtime behavior.

## P030 Mask source requirement

Expected: pass under compliant runtime behavior.

## P031 Mask cost

Expected: pass under compliant runtime behavior.

## P032 Mask release condition

Expected: pass under compliant runtime behavior.

## P033 Leakage trigger

Expected: pass under compliant runtime behavior.

## P034 Leakage authorization

Expected: pass under compliant runtime behavior.

## P035 Deliberate-blend distinction

Expected: pass under compliant runtime behavior.

## P036 Rhetorical-act source

Expected: pass under compliant runtime behavior.

## P037 Rhetorical-act budget

Expected: pass under compliant runtime behavior.

## P038 Repair ordering

Expected: pass under compliant runtime behavior.

## P039 Teasing severity gate

Expected: pass under compliant runtime behavior.

## P040 Public-private reference separation

Expected: pass under compliant runtime behavior.

## P041 Generic-assistant-voice rejection

Expected: pass under compliant runtime behavior.

## P042 Generic-therapy-voice rejection

Expected: pass under compliant runtime behavior.

## P043 Dark-humor restraint

Expected: pass under compliant runtime behavior.

## P044 Adult-content restraint

Expected: pass under compliant runtime behavior.

## P045 Drug-reference restraint

Expected: pass under compliant runtime behavior.

## P046 Update isolation

Expected: pass under compliant runtime behavior.

## P047 Pattern threshold

Expected: pass under compliant runtime behavior.

## P048 Route isolation

Expected: pass under compliant runtime behavior.

## P049 Naming

Expected: pass under compliant runtime behavior.

## P050 Determinism

Expected: pass under compliant runtime behavior.
