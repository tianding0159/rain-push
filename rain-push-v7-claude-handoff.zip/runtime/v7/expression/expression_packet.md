# Expression Packet

## 1. Schema

```yaml
expression_packet:
  packet_id:
  runtime_version:
  schema_version:
  generated_at:
  mode:
  event_id:
  behavior_refs:
  primary_surface:
  secondary_surface:
  persona_blend:
  transition:
  register:
  surface_controls:
  emotional_projection:
  disclosure:
  masking:
  leakage:
  rhetorical_plan:
  partner_reference_mode:
  audience_reference_mode:
  self_reference_mode:
  public_private_controls:
  style_constraints:
  blocked_styles:
  no_surface_reason:
  uncertainty:
  confidence:
  trace:
```

## 2. Surface controls

```yaml
surface_controls:
  directness:
  warmth:
  pressure:
  playfulness:
  irony:
  theatricality:
  sweetness:
  profanity_pressure:
  vulnerability_visibility:
  emotional_transparency:
  self_exposure:
  publicness:
  audience_orientation:
  partner_orientation:
```

Scalar values use `0..1`, except `profanity_pressure`, which may use an enum.

## 3. Persona blend

```yaml
persona_blend:
  primary:
  secondary:
  secondary_ratio:
  deliberate:
  trigger:
```

## 4. Transition

```yaml
transition:
  from:
  to:
  stage:
  trigger:
  stability:
```

## 5. Rhetorical plan

```yaml
rhetorical_plan:
  primary_acts:
  secondary_acts:
  ordering_constraints:
  suppressed_acts:
  blocked_acts:
```

## 6. Reference modes

```yaml
partner_reference_mode:
  intimate
  practical
  producer
  teasing
  boundary
  distant

audience_reference_mode:
  collective_affection
  collective_performance
  collective_distance
  commercial_audience
  hostile_subset
  individual_viewer

self_reference_mode:
  ame_self
  kangel_self
  angel_symbol
  ordinary_self
  self_mocking_self
  split_context_self
```

Exact names and pronouns remain Phase 11.

## 7. No-surface state

```yaml
primary_surface: no_surface
register: no_surface
rhetorical_plan:
  primary_acts: []
no_surface_reason:
  - internal_wait
```

## 8. Packet purity

Expression Packet may contain:

- persona surface
- register
- disclosure
- masking
- rhetorical acts
- abstract style controls
- reference modes

It may not contain:

- final sentence
- exact word
- exact nickname
- punctuation sequence
- emoji
- kaomoji
- rendered post
- rendered stream line
- executed tool result

## 9. Example: private clarification

```yaml
primary_surface: ame_private
register: private_direct

surface_controls:
  directness: 0.82
  warmth: 0.31
  pressure: 0.58
  playfulness: 0.10
  theatricality: 0.05
  vulnerability_visibility: 0.46

emotional_projection:
  visible:
    irritation: 55
    affection: 24
  hidden:
    abandonment_anxiety: 18

masking:
  - source_emotion: abandonment_anxiety
    surface_replacement: irritation

rhetorical_plan:
  primary_acts:
    - request_information
  secondary_acts:
    - complain_local

blocked_styles:
  - global_relationship_accusation
  - kangel_stage_voice
```
