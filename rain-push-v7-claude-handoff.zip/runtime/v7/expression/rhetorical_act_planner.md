# Rhetorical Act Planner

## 1. Purpose

Map Behavior actions into abstract communicative functions.

A rhetorical act describes what an expression is doing socially or cognitively.

It does not contain final wording.

## 2. Input

```yaml
behavior_packet:
decision_packet:
thought_packet:
need_packet:
emotion_packet:
persona_selection:
register:
disclosure:
```

## 3. Output

```yaml
rhetorical_plan:
  primary_acts:
  secondary_acts:
  suppressed_acts:
  blocked_acts:
  ordering_constraints:
  confidence:
  trace:
```

## 4. Act set

```yaml
acknowledge:
clarify:
request_information:
request_specificity:
complain_local:
repair_opening:
accept_repair:
mark_unresolved:
set_boundary:
reduce_pressure:
care_signal:
affection_signal:
tease:
self_mock:
audience_address:
audience_thanks:
milestone_frame:
content_reframe:
public_update:
practical_update:
task_coordination:
topic_return:
topic_shift:
distance_signal:
presence_signal:
silence_frame:
identity_link:
future_link:
```

## 5. Act schema

```yaml
act:
  id:
  function:
  target:
  source_behavior:
  source_goal:
  source_need:
  emphasis:
  disclosure_requirement:
  surface_fit:
  ordering:
  confidence:
```

## 6. Clarification behavior

Behavior:

```yaml
action_type: ask_question
strategy_family: information_clarification
```

Possible acts:

```yaml
primary:
  - request_information
secondary:
  - mark_unresolved
  - complain_local
```

Blocked:

```yaml
- global_accusation
- relationship_rupture
```

## 7. Specific feedback request

Possible acts:

```yaml
primary:
  - request_specificity
secondary:
  - mark_unresolved
  - career_evaluation_frame
```

## 8. Repair behavior

Possible order:

```text
acknowledge
→ mark_unresolved
→ repair_opening
→ care_signal
```

Shared humor may appear only after acknowledgment when conflict is minor or already recognized.

## 9. Boundary behavior

Possible acts:

```yaml
primary:
  - set_boundary
secondary:
  - explain_local_reason
  - distance_signal
```

A boundary need not include humiliation.

## 10. Waiting and silence

Possible acts:

```yaml
silent_wait:
  - silence_frame

public_non_engagement:
  - distance_signal
  - attention_conservation

topic_closed:
  - no_act
```

No language is generated unless Behavior includes communication.

## 11. Audience engagement

Possible acts:

```yaml
- audience_address
- audience_thanks
- milestone_frame
- content_reframe
- public_update
```

## 12. Practical behavior

Possible acts:

```yaml
- practical_update
- task_coordination
- request_information
```

Neutral practical expression should not be overdecorated.

## 13. Care behavior

Possible acts:

```yaml
- care_signal
- presence_signal
- reduce_pressure
- practical_update
```

## 14. Teasing

Teasing may function as:

- affectionate friction
- embarrassment conversion
- minor repair
- play
- domestic callback

Teasing cannot function as:

- major harm denial
- safety dismissal
- coercion
- public humiliation

## 15. Self-mockery

Self-mockery may:

- reduce embarrassment
- create audience distance
- preserve control
- convert failure into content

It may not become constant self-devaluation.

## 16. Identity link

Used when:

- Ame and KAngel continuity matters
- public success and private effort connect
- persona transition is deliberate
- audience only sees one surface

## 17. Ordering constraints

Examples:

```yaml
major_repair:
  before:
    - acknowledge
  after:
    - repair_opening
  blocked_before_acknowledgment:
    - tease
    - topic_shift

specificity_request:
  primary_first:
    - request_specificity
  optional_after:
    - complain_local

public_boundary:
  first:
    - set_boundary
  then:
    - public_update
```

## 18. Act budget

Default:

```yaml
primary_acts: 2
secondary_acts: 3
maximum_total: 5
```

Behavior message count may further reduce the budget.

## 19. Failure cases

Reject when:

- rhetorical act is final text
- act has no source Behavior
- too many acts are packed into one behavior
- teasing precedes acknowledgment in major conflict
- public act exposes private repair
- act ordering is contradictory
