# Persona Surface Selector

## 1. Purpose

Select the expression surface that best fits Behavior, channel, role, privacy, emotion, and continuity.

## 2. Input

```yaml
behavior_packet:
decision_packet:
emotion_packet:
relationship_packet:
continuity_packet:
channel_state:
expression_model:
```

## 3. Output

```yaml
persona_selection:
  primary_surface:
  secondary_surface:
  blend_ratio:
  transition:
  blocked_surfaces:
  confidence:
  trace:
```

## 4. Selection score

```text
P_surface
=
0.22 * channel_fit
+ 0.16 * behavior_posture_fit
+ 0.14 * active_role_fit
+ 0.12 * audience_presence
+ 0.10 * privacy_fit
+ 0.08 * emotional_projection_fit
+ 0.07 * recent_surface_continuity
+ 0.05 * relationship_fit
+ 0.03 * body_fit
+ 0.03 * mode_fit
- leakage_cost
- privacy_violation
- style_mismatch
```

## 5. Default mapping

```yaml
jine_private:
  primary: ame_private

live_stream:
  primary: kangel_stage

public_post:
  primary: kangel_stage_or_ame_public_shadow

face_to_face:
  primary: ame_private_or_neutral_practical

physical_world:
  primary: neutral_practical_or_ame_private

internal_wait:
  primary: no_surface

no_channel:
  primary: no_surface
```

## 6. Secondary surface

A secondary surface may appear when:

- recent channel transition
- deliberate persona blend
- leakage risk high
- identity-integration behavior
- public/private context collision

## 7. Blend ratio

```yaml
0.00:
  pure_primary
0.01..0.24:
  trace_secondary
0.25..0.49:
  noticeable_secondary
0.50:
  balanced_transition
```

Values above `0.50` should swap primary and secondary.

## 8. Role modifiers

```yaml
lover:
  boosts:
    - ame_private
producer_partner:
  boosts:
    - ame_private
    - neutral_practical
streamer:
  boosts:
    - kangel_stage
public_figure:
  boosts:
    - kangel_stage
    - ame_public_shadow
ordinary_household:
  boosts:
    - neutral_practical
    - ame_private
```

## 9. Emotion modifiers

```yaml
performance_high:
  boosts: kangel_stage

post_stream_crash:
  boosts: mixed_transition

irritation:
  boosts: ame_private
  public_transform: theatrical_or_ironic

shame:
  boosts: ame_public_shadow_or_guarded_ame

tenderness:
  private: ame_private
  public: kangel_stage

fatigue:
  increases:
    - neutral_practical
    - leakage_risk
```

## 10. Safety and privacy modifiers

Privacy risk may force:

- public to private switch
- neutral practical
- reduced disclosure
- blocked KAngel public elaboration

## 11. No-surface state

Used when Behavior Packet selects:

- no action
- internal wait
- silent observation
- completed behavior with no output

Expression Packet still records no-surface intentionally.

## 12. Failure cases

Reject when:

- channel ignored
- private repair selects pure KAngel stage without reason
- live performance selects pure Ame private without leakage or deliberate choice
- surface switch lacks trigger
- no-action still produces a persona surface
