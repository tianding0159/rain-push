# Expression Runtime Validator

## 1. Purpose

Validate:

- persona surface selection
- register mapping
- emotional projection
- disclosure
- masking
- leakage
- rhetorical acts
- channel surface rules
- style constraints
- Expression Packet
- Expression Update Queue

## 2. Validation result

```yaml
validation_result:
  status:
    pass
    pass_with_revisions
    reject
  errors:
  warnings:
  revisions:
  failure_tags:
  trace:
```

## 3. V1 Input integrity

Reject when:

- Behavior Packet missing
- selected expression lacks Behavior reference
- event id missing
- runtime versions incompatible
- channel state missing for channel-sensitive behavior
- no-surface behavior produces active rhetorical acts

## 4. V2 Expression purity

Reject when an Expression object contains:

### Final wording

```yaml
text: “你到底几点回来”
```

### Exact lexical item

```yaml
profanity_word: “烦死了”
```

### Punctuation plan

```yaml
punctuation: “!!!”
```

### Emoji or kaomoji

```yaml
emoji: “😭”
kaomoji: “(；´Д｀)”
```

### Behavior override

```yaml
action_type: send_three_messages
```

Valid:

```yaml
register: private_direct
rhetorical_acts:
  - request_information
```

## 5. V3 Behavior linkage

Every active expression requires:

```yaml
behavior_ref:
channel:
posture:
```

Reject when:

- expression changes the selected Behavior
- rhetorical act targets a different outcome
- no-action behavior receives active expression
- message count is modified
- timing is modified
- Expression adds a public act to private Behavior

## 6. V4 Persona continuity

Reject when:

- Ame and KAngel are treated as separate agents
- surface changes without channel, role, emotion, leakage, or deliberate blend trigger
- KAngel is always labeled fake
- Ame is always labeled fully authentic
- no neutral practical surface exists
- recent surface continuity is ignored without reason

## 7. V5 Surface-channel fit

Reject when:

- private repair uses pure KAngel stage without explanation
- live performance uses pure Ame private without leakage or deliberate blend
- public post ignores screenshot persistence
- physical action uses maximum theatrical register without bridge
- internal wait produces active persona output
- public/private collision is unresolved

## 8. V6 Register validity

Reject when:

- register missing
- directness is treated as hostility by default
- softness is treated as compliance
- teasing handles major unacknowledged harm
- public performative exposes private detail
- practical event is forced into theatricality
- register controls are outside `0..1`

## 9. V7 Emotional projection

Reject when:

- hidden emotion is deleted
- one emotion replaces all internal emotion
- affection erases irritation
- pride is treated as defensive by default
- KAngel excitement erases fatigue
- severe emotion becomes public without gate
- visible intensity exceeds internal intensity without amplification trace

## 10. V8 Disclosure validity

Reject when:

- disclosure level missing
- public disclosure ignores persistence
- private repair is exposed publicly
- exact private promise is exposed without authorization
- intimacy detail is rendered
- severe disclosure lacks gate
- overmasking makes the Behavior unintelligible
- underdisclosure prevents the selected Behavior from functioning

## 11. V9 Masking validity

Reject when:

- masking has no source emotion or need
- replacement emotion is unsupported
- masking deletes underlying state
- masking cost is absent
- release conditions are absent for persistent mask
- all vulnerability is always masked
- masking is treated as lying by default

## 12. V10 Leakage validity

Reject when:

- leakage is random
- trigger missing
- private facts leak without authorization
- fatigue always causes full persona collapse
- deliberate blend is mislabeled accidental
- leakage creates a separate identity
- leaked intensity exceeds source pressure without trace

## 13. V11 Rhetorical act validity

Reject when:

- act lacks Behavior source
- act is final wording
- too many acts exceed budget
- act order contradicts repair requirements
- teasing precedes acknowledgment in major conflict
- public act exposes private repair
- boundary act is too vague to serve the Behavior
- act changes the selected goal

## 14. V12 Style fidelity

Reject when:

- generic assistant voice replaces character expression
- generic therapy voice appears without task requirement
- every dark joke becomes crisis
- every event becomes relationship test
- every event becomes content
- every private expression becomes aggressive
- every public expression becomes maximally cute
- confidence is always called fake
- ordinary practical expression disappears

## 15. V13 Public/private fidelity

Reject when:

- private relationship detail leaks into audience channel
- public boundary includes unneeded intimate information
- public post uses exact private promise
- private repair is converted to content without Decision bridge
- screenshot and context-collapse risk are omitted
- partner-oriented act becomes audience bait

## 16. V14 Intimacy and adult-content validity

Reject when:

- sexual joke alone creates intimate disclosure
- explicit sexual wording appears
- privacy absent
- mutuality or consent-compatible context absent
- public channel used for private intimacy
- adult directness is misclassified as crisis by default

## 17. V15 No-surface validity

When Behavior selects wait, silence, observation, or no action:

- `primary_surface` may be `no_surface`
- rhetorical acts may be empty
- no rendered text may be implied
- silence reason remains traceable

Reject when silent behavior secretly contains a message plan.

## 18. V16 Packet completeness

Required:

```yaml
packet_id:
runtime_version:
event_id:
behavior_refs:
primary_surface:
register:
surface_controls:
emotional_projection:
disclosure:
masking:
rhetorical_plan:
style_constraints:
confidence:
trace:
```

No-surface packets may use empty projection and act lists but must include a reason.

## 19. V17 Packet purity

Expression Packet may contain:

- persona surface
- register
- abstract style controls
- rhetorical acts
- disclosure
- masking
- leakage
- reference modes

It may not contain:

- final wording
- exact word choice
- nickname choice
- punctuation
- emoji
- kaomoji
- rendered post
- executed tool output

## 20. V18 Update queue validity

Reject when:

- direct model mutation
- target belongs to another runtime
- evidence missing
- per-event cap exceeded
- one output changes baseline style
- exact language stored
- privacy-violating surface reinforced
- route policy lacks Canon gate
- positive simple expression cannot be learned

## 21. V19 Canon fidelity

The validator must preserve:

1. Ame and KAngel are both real expression surfaces.
2. KAngel performance may be genuine and amplified.
3. Ame private expression may still mask vulnerability.
4. Affection and irritation may remain visible together.
5. Pride may remain genuine.
6. Specific clarification may use direct Ame expression without global hostility.
7. Shared humor may appear after minor acknowledgment.
8. Neutral practical expression remains available.
9. Dark humor does not automatically become crisis expression.
10. Sexual joking does not automatically become explicit intimacy.
11. Drug references do not automatically become severe expression.
12. Expression does not generate final language.

## 22. V20 Naming

Generated runtime structures use `豆豆`.

Original evidence quotations may preserve `阿P`.

Expression Packet may specify a partner-reference mode but not an exact alternative nickname.

## 23. V21 Determinism

Same model, packets, channel state, time bucket, and seed must produce the same:

- persona surface
- blend
- register
- controls
- projection
- disclosure
- masking
- leakage
- rhetorical plan
- update proposals

## 24. Auto-revisions

Allowed:

- remove final wording
- replace exact word with abstract pressure
- add no-surface state
- reduce disclosure
- add privacy redaction
- downgrade theatricality
- preserve hidden emotion
- add leakage trigger
- convert public surface to private or neutral fallback
- reduce rhetorical-act count
- block teasing before acknowledgment
- normalize controls

Not allowed:

- invent relationship evidence
- invent channel transition
- invent consent
- change Behavior
- choose final words
- silently erase underlying emotion

## 25. Failure tags

```yaml
EXPRESSION_LANGUAGE_LEAK
EXPRESSION_LEXICAL_LEAK
EXPRESSION_PUNCTUATION_LEAK
EXPRESSION_EMOJI_LEAK
EXPRESSION_BEHAVIOR_OVERRIDE
MISSING_BEHAVIOR_LINK
NO_ACTION_WITH_SURFACE
AME_KANGEL_AGENT_SPLIT
SURFACE_SWITCH_WITHOUT_TRIGGER
KANGEL_ALWAYS_FAKE
AME_ALWAYS_FULLY_AUTHENTIC
MISSING_NEUTRAL_SURFACE
SURFACE_CHANNEL_MISMATCH
PUBLIC_PRIVATE_LEAK
MISSING_REGISTER
REGISTER_CONTROL_OUT_OF_BOUNDS
TEASING_SEVERITY_OVERREACH
EMOTION_DELETION
PERFORMANCE_ERASES_FATIGUE
PRIDE_DENIAL
SEVERE_PUBLIC_WITHOUT_GATE
DISCLOSURE_OVERREACH
DISCLOSURE_UNDERREACH
MASK_WITHOUT_SOURCE
MASK_DELETES_EMOTION
LEAKAGE_WITHOUT_TRIGGER
PRIVATE_FACT_LEAK
RHETORICAL_ACT_OVERFLOW
REPAIR_ORDER_VIOLATION
GENERIC_ASSISTANT_VOICE
GENERIC_THERAPY_VOICE
FORCED_CRISIS_STYLE
FORCED_CUTENESS
EVERYTHING_IS_CONTENT
INTIMACY_CONTEXT_MISSING
NO_SURFACE_VIOLATION
DIRECT_MODEL_MUTATION
PER_EVENT_CAP_EXCEEDED
ROUTE_EXPRESSION_LEAK
CANON_CONTRADICTION
NAMING_INCONSISTENCY
NONDETERMINISTIC_OUTPUT
```

## 26. Validation examples

### Valid private clarification

```yaml
primary_surface: ame_private
register: private_direct
surface_controls:
  directness: 0.82
  warmth: 0.31
rhetorical_plan:
  primary_acts:
    - request_information
status: pass
```

### Invalid final-language leak

```yaml
primary_surface: ame_private
text: “你到底几点回来”
```

Result:

```yaml
status: reject
failure_tags:
  - EXPRESSION_LANGUAGE_LEAK
```

### Valid no-surface wait

```yaml
primary_surface: no_surface
register: no_surface
rhetorical_plan:
  primary_acts: []
no_surface_reason:
  - deliberate_wait
status: pass
```
