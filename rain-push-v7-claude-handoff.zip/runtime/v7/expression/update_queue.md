# Expression Update Queue

## 1. Purpose

Stage persistent Expression Model changes.

A current surface choice does not automatically become a permanent style habit.

## 2. Schema

```yaml
expression_update_queue:
  event_id:
  runtime_version:
  proposed:
  deferred:
  rejected:
  trace:
```

## 3. Proposal schema

```yaml
proposal:
  id:
  target_path:
  operation:
  value:
  delta:
  source_event:
  source_expression:
  source_behavior:
  source_emotions:
  evidence_refs:
  outcome:
  confidence:
  time_scale:
  commit_policy:
  repetition_requirement:
  expires_at:
```

## 4. Allowed targets

```yaml
expression_model.persona_surfaces.*
expression_model.persona_selector.*
expression_model.channel_registers.*
expression_model.emotional_projection.*
expression_model.disclosure_policy.*
expression_model.masking_policy.*
expression_model.leakage_policy.*
expression_model.rhetorical_act_priors.*
expression_model.directness_policy.*
expression_model.warmth_policy.*
expression_model.teasing_policy.*
expression_model.irony_policy.*
expression_model.theatricality_policy.*
expression_model.sweetness_policy.*
expression_model.profanity_policy.*
expression_model.self_reference_policy.*
expression_model.partner_reference_policy.*
expression_model.audience_reference_policy.*
expression_model.public_private_policy.*
expression_model.style_constraints.*
expression_model.expression_memory.*
expression_model.fatigue.*
```

## 5. Forbidden targets

```yaml
behavior_model.*
decision_model.*
thought_model.*
need_model.*
emotion_model.*
meaning_model.*
relationship_model.*
language_model.*
execution.*
```

## 6. Commit policies

```yaml
immediate_surface_state:
accumulate_expression_pattern:
confirm_style_policy:
canon_evidence_only:
```

## 7. Pattern requirements

```yaml
channel_register_effectiveness:
  minimum_occurrences: 3

masking_pattern:
  minimum_occurrences: 3

leakage_pattern:
  minimum_occurrences: 3

stable_style_policy:
  minimum_occurrences: 5
  minimum_time_span: 14_days
```

## 8. Per-event caps

```yaml
surface_prior_delta_max: 3
register_prior_delta_max: 3
projection_delta_max: 3
disclosure_policy_delta_max: 1
masking_policy_delta_max: 2
leakage_policy_delta_max: 1
style_constraint_delta_max: 1
new_expression_memory_max: 1
route_locked_delta_max: 0 unless Canon gate
```

## 9. Outcome evidence

An expression pattern may be learned as effective only when:

- the Behavior outcome improved
- the source need was satisfied or reduced
- the surface did not create hidden privacy or relationship cost
- the expression remained intelligible
- the success was not merely coincidental
- final language quality did not independently explain the result

## 10. Positive and negative symmetry

The model may learn:

- direct private register works for exact clarification
- private teasing works after minor acknowledgment
- KAngel high-energy register works during genuine audience euphoria
- neutral practical register prevents overdramatization
- public irony worsens private misunderstanding
- fatigue increases leakage risk
- specific reassurance increases Ame vulnerability visibility safely

The model must not only learn masking, aggression, or theatricality.

## 11. Rejection rules

Reject when:

- no evidence
- target belongs to another runtime
- exact wording is stored
- punctuation or emoji pattern is stored
- one event changes baseline style
- a privacy-violating surface is reinforced
- KAngel is learned as a separate identity
- route expression lacks Canon evidence
