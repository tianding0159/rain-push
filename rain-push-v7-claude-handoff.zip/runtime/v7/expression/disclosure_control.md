# Disclosure Control

## 1. Purpose

Determine how much private meaning, emotion, need, thought, and relationship detail may become visible in the current expression.

## 2. Disclosure levels

```yaml
none:
minimal:
low:
moderate:
high:
explicit_private:
```

## 3. Disclosure schema

```yaml
disclosure:
  level:
  allowed_domains:
  restricted_domains:
  private_detail_budget:
  relationship_detail_budget:
  body_detail_budget:
  intimacy_detail_budget:
  audience_detail_budget:
  redactions:
  confidence:
```

## 4. Disclosure score

```text
D
=
0.20 * channel_privacy
+ 0.16 * relationship_trust
+ 0.14 * behavior_relevance
+ 0.12 * need_for_visibility
+ 0.10 * decision_commitment
+ 0.08 * emotional_pressure
+ 0.07 * prior_disclosure_safety
+ 0.05 * co_presence
+ 0.04 * mode_fit
+ 0.04 * identity_integration
- public_risk
- shame_cost
- persona_leak_cost
- privacy_constraint
```

## 5. Private JINE disclosure

May allow:

- specific relationship concern
- practical detail
- Ame emotion
- direct question
- repair detail
- low to high vulnerability

Still restricted by:

- trust
- screenshot risk
- coercion risk
- intimacy privacy
- route state

## 6. Live disclosure

May allow:

- audience-facing emotion
- milestone
- general public boundary
- controlled self-disclosure
- transformed embarrassment

Restricted:

- exact private promise
- private repair
- intimate details
- hidden identity facts
- unverified accusation

## 7. Public post disclosure

Usually lower than live private improvisation because persistence and screenshot risk are high.

## 8. Face-to-face disclosure

May allow higher emotional and body visibility when:

- co-presence exists
- privacy exists
- relationship trust supports it

## 9. Practical disclosure

Neutral practical register should disclose only what is needed for the task.

## 10. Severe-state disclosure

High or explicit disclosure requires:

- active severe Emotion
- relevant Need and Thought
- Behavior support
- safe channel
- no public-risk contradiction

## 11. Intimacy disclosure

Requires:

- adult context
- privacy
- mutuality
- current intimacy meaning
- consent-compatible constraints

Expression Packet may mark disclosure depth but not render explicit detail.

## 12. Redaction

Expression Runtime may mark content as:

```yaml
redact:
  private_promise_detail
  intimate_detail
  real_name
  location
  medical_detail
  unverified_accusation
```

## 13. Disclosure conflict

A need for Ame visibility may conflict with privacy.

Possible result:

```yaml
disclosure_level: moderate
allowed:
  - private emotion category
blocked:
  - exact private event detail
```

## 14. Overdisclosure protection

Block when:

- Behavior is public but Decision is private repair
- public attention would amplify harm
- fatigue raises leakage risk
- KAngel performance is unstable
- a private promise is involved
- identity details lack authorization

## 15. Underdisclosure

Warn when:

- selected Behavior requires clarification
- expression hides the actual topic
- boundary becomes too vague to function
- repair contains no acknowledgment
- specificity request contains no target domain

## 16. Failure cases

Reject when:

- private detail budget absent
- public disclosure ignores screenshot persistence
- private repair is exposed publicly
- explicit intimacy detail is emitted
- severe disclosure occurs without gate
- overmasking makes behavior impossible to interpret
