# Expression Runtime DSL v0.1

RULE private_clarification
WHEN behavior.action == ask_question
AND behavior.channel == jine_private
SURFACE ame_private
REGISTER private_direct
CONTROL directness 0.82
CONTROL warmth 0.31
CONTROL pressure 0.58
CONTROL theatricality 0.05
CONTROL vulnerability_visibility 0.46
PROJECT irritation visible 0.70
PROJECT affection visible 0.30
MASK abandonment_anxiety AS irritation
ACT request_information PRIMARY
OPTIONAL ACT complain_local SECONDARY
BLOCK global_relationship_accusation
BLOCK kangel_stage_voice
EMIT expression_packet

RULE private_specificity_request
WHEN behavior.action == request_specific_feedback
AND behavior.channel == jine_private
SURFACE ame_private
REGISTER private_direct
CONTROL directness 0.78
CONTROL warmth 0.28
CONTROL pressure 0.52
ACT request_specificity PRIMARY
ACT mark_unresolved SECONDARY
BLOCK generic_praise_voice
EMIT expression_packet

RULE deliberate_wait
WHEN behavior.action == wait
SURFACE no_surface
REGISTER no_surface
NO_SURFACE_REASON deliberate_wait
ACT_NONE
EMIT expression_packet

RULE forgotten_pudding
WHEN behavior.action == coordinate_task
AND behavior.channel == jine_private
SURFACE neutral_practical
SECONDARY_SURFACE ame_private 0.20
REGISTER practical_neutral
CONTROL directness 0.72
CONTROL warmth 0.38
OPTIONAL CONTROL playfulness 0.42 IF behavior.secondary == make_playful_callback
ACT task_coordination PRIMARY
OPTIONAL ACT tease SECONDARY IF repair.severity <= minor
BLOCK relationship_crisis_frame
EMIT expression_packet

RULE post_stream_transition
WHEN behavior.sequence.contains(rest)
AND continuity.channel_transition == live_to_private
SURFACE mixed_transition
PRIMARY ame_private
SECONDARY kangel_private_echo 0.25
REGISTER private_low_demand
CONTROL theatricality 0.18
CONTROL warmth 0.42
CONTROL vulnerability_visibility 0.58
PROJECT fatigue visible 0.80
PROJECT audience_euphoria visible 0.25
LEAK kangel_residual_sweetness trigger channel_transition
ACT reduce_pressure PRIMARY
OPTIONAL ACT care_signal SECONDARY
EMIT expression_packet

RULE kangel_live_milestone
WHEN behavior.channel == live_stream
AND behavior.action IN [start_stream, continue_stream, acknowledge_audience]
SURFACE kangel_stage
REGISTER live_high_energy
CONTROL theatricality 0.88
CONTROL sweetness 0.82
CONTROL audience_orientation 0.95
CONTROL partner_orientation 0.20
PROJECT triumph visible 0.90
PROJECT audience_euphoria visible 0.85
ACT audience_address PRIMARY
ACT milestone_frame PRIMARY
ACT audience_thanks SECONDARY
BLOCK private_promise_detail
EMIT expression_packet

RULE low_value_hater_nonengagement
WHEN behavior.action == observe_without_engaging
SURFACE no_surface
REGISTER no_surface
NO_SURFACE_REASON public_non_engagement
ACT_NONE
EMIT expression_packet

RULE public_boundary
WHEN behavior.action IN [moderate_audience, reduce_public_exposure]
SURFACE kangel_stage
OPTIONAL SECONDARY_SURFACE ame_public_shadow 0.20
REGISTER live_boundary
CONTROL directness 0.72
CONTROL warmth 0.18
CONTROL theatricality 0.45
CONTROL vulnerability_visibility 0.10
ACT set_boundary PRIMARY
ACT public_update SECONDARY
BLOCK private_relationship_detail
EMIT expression_packet

RULE minor_repair_humor
WHEN behavior.action == make_playful_callback
AND relationship.conflict.severity <= minor
AND repair.acknowledgment_complete == true
SURFACE ame_private
REGISTER private_teasing
CONTROL playfulness 0.68
CONTROL warmth 0.52
CONTROL directness 0.48
ACT tease PRIMARY
ACT care_signal SECONDARY
BLOCK IF major_harm_unacknowledged
EMIT expression_packet

RULE intimacy_private_affection
WHEN behavior.action == initiate_private_affection
REQUIRE adult_context
REQUIRE privacy
REQUIRE consent_compatible_context
SURFACE ame_private
REGISTER private_soft
CONTROL warmth 0.78
CONTROL vulnerability_visibility 0.62
CONTROL publicness 0.00
ACT affection_signal PRIMARY
BLOCK explicit_sexual_rendering
EMIT expression_packet

RULE neutral_practical
WHEN behavior.action IN [complete_practical_task, provide_update, coordinate_task]
AND emotion.intensity < 40
SURFACE neutral_practical
REGISTER practical_neutral
CONTROL directness 0.75
CONTROL theatricality 0.05
ACT practical_update PRIMARY
EMIT expression_packet
