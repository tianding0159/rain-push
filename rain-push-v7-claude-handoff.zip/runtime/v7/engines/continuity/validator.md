# Continuity Validator

## Reject when

- 整个 Continuity Model 被直接传给下游
- 无关 Episode 被检索
- Pending Thread 被摘要器吞掉
- Callback 被普通衰减删除
- 推断事实覆盖确认事实
- 世界实体状态缺少时间与来源
- “豆豆”运行时称呼被改回“阿P”

## Commit rules

所有长期更新先进入 Update Queue。

Validator 通过后才能提交回 Continuity Model。
