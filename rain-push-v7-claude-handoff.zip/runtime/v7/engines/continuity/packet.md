# Continuity Packet

```yaml
continuity_packet:
  packet_id:
  generated_at:
  active_entities:
  world_snapshot:
  active_episodes:
  semantic_facts:
  pending_threads:
  callbacks:
  patterns:
  compressed_context:
  confidence:
  conflicts:
  omitted_domains:
```

## Packet discipline

- 只携带当前回合所需内容。
- 每一项必须可追溯到 Continuity Model。
- 未解决线程优先于普通历史。
- Hard Callback 优先于普通记忆。
