# Continuity Model

```yaml
continuity_model:
  entities:
  episodes:
  semantic_facts:
  pending_threads:
  callbacks:
  patterns:
  relationship_independent_flags:
```

## Entities

采用实体模型而不是固定房间树：

```yaml
entity:
  id:
  type:
  attributes:
  state:
  updated_at:
  confidence:
```

可表示：

- 冰箱
- 布丁
- 电脑
- 麦克风
- 直播项目
- 钱包
- 日程
- 天气

## Model rule

长期事实只保存在 Model，不直接出现在下游 Context。
