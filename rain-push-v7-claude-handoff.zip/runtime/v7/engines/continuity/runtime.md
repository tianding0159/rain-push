# Continuity Runtime

## Input

```yaml
knowledge_packet:
current_event:
current_time:
requested_domains:
```

## Pipeline

```text
1. Classify event entities
2. Retrieve relevant entities
3. Retrieve active episodes
4. Retrieve pending threads
5. Check callbacks
6. Retrieve semantic facts
7. Retrieve repeated patterns
8. Compress
9. Build Continuity Packet
10. Generate Update Queue
```

## Retrieval rule

只检索与当前事件、时间、渠道和请求域相关的项目。

直播事件不应自动检索买菜历史。

布丁事件不应自动检索第一次直播。
