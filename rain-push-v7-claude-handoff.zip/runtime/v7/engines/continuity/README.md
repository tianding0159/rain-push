# Phase 2: Continuity Runtime

Continuity Runtime 负责从长期连续性模型中提取当前回合真正相关的世界、记忆、未完成事项、回调和模式。

## Architecture

```text
Continuity Model
  -> Continuity Runtime
  -> Continuity Packet
  -> Update Queue
  -> Validator
  -> Model Commit
```

## Core rule

Continuity Model 保存长期状态。

Continuity Runtime 不把整个 Model 向下传，只生成当前回合的 Continuity Packet。
