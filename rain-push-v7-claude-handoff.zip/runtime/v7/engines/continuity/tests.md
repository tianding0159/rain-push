# Continuity Runtime Tests

## T01 Pudding event

Input:
- current event: pudding missing
- entity: pudding count = 0
- pending thread: 豆豆曾答应买布丁

Expect:
- retrieve pudding entity
- retrieve relevant promise
- do not retrieve first-stream episode
- packet contains shared-life context only

## T02 Stream event

Input:
- current event: microphone failure

Expect:
- retrieve microphone entity
- retrieve recent stream setup episodes
- retrieve active stream project
- omit grocery and pudding domains

## T03 File13 callback

Input:
- ending: Utopian Parody
- callback: file13 wish hard callback

Expect:
- callback included regardless of recency
- callback not consumed before resolution

## T04 Pending thread protection

Input:
- unanswered question from current session

Expect:
- included before ordinary episodic memory
- not removed by compression
