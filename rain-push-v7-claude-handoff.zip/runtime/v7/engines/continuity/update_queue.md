# Continuity Update Queue

```yaml
continuity_update_queue:
  creates:
  updates:
  resolves:
  archives:
  invalidates:
```

## Examples

```yaml
updates:
  - target: entity.pudding.count
    before: 1
    after: 0
    confidence: confirmed
```

```yaml
resolves:
  - target: pending.buy_pudding
    evidence: purchase_confirmed
```
