# Evidence Runtime Pipeline

## Step 1: Extract

输入：

```yaml
source:
  type:
  reference:
  location:
  raw_content:
```

输出 `evidence_object`。

## Step 2: Normalize

统一：

- 人物名称
- 时间
- 渠道
- 数值阈值
- 事件名称
- 不确定措辞

原始证据中的“阿P”不改写；Runtime 映射阶段才转成“豆豆”。

## Step 3: Build Fact

Evidence Object 不能直接供后续 Runtime 使用，必须转换为 Fact。

## Step 4: Validate

检查：

- 是否超出来源支持范围
- 是否存在冲突
- 是否把攻略推测写成确定事实
- 是否缺少来源位置

## Step 5: Store

通过验证的 Fact 写入 Knowledge Model。

## Step 6: Retrieve

根据当前请求，只输出相关 Fact 和 Rule，形成 Knowledge Packet。
