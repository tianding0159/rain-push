# Phase 1: Evidence Runtime

Evidence Runtime 是整个 v7 的事实入口。

它不直接把攻略、对白、Wiki、截图或采访送入后续 Engine，而是先把来源转换成可审计的 Evidence Object，再构造成 Fact，最后进入 Knowledge Model。

## Pipeline

```text
External Source
  -> Evidence Extractor
  -> Evidence Object
  -> Fact Builder
  -> Canon Validator
  -> Knowledge Model
  -> Knowledge Runtime
  -> Knowledge Packet
```

## Responsibilities

- 保存证据来源与位置
- 区分原作事实、攻略记录、社区推断与模拟器扩展
- 构建可引用 Fact
- 处理冲突与置信度
- 只向后续 Runtime 输出当前相关的 Knowledge Packet

## Non-goals

- 不生成角色对白
- 不直接更新关系状态
- 不把攻略最优选项解释成人物永恒心理
- 不向公开仓库提交完整版权对白
