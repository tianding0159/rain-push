# Knowledge Runtime

Knowledge Runtime 在当前回合检索相关知识。

## Input

```yaml
current_event:
requested_domains:
channel:
canon_state:
time_context:
```

## Retrieval order

1. 硬性 Canon Rule
2. 当前事件 Rule
3. 当前渠道 Rule
4. 数值阈值 Rule
5. 回调 Rule
6. 行为与语言 Rule
7. 模拟器扩展 Rule

## Output

只输出最小必要 Knowledge Packet。
