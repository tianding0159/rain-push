# Knowledge Model

Knowledge Model 保存经过验证的长期知识。

## Structure

```yaml
knowledge_model:
  facts:
  canon_rules:
  event_rules:
  channel_rules:
  behavior_rules:
  language_rules:
  callback_rules:
  simulator_rules:
  conflicts:
```

## Rules

- 只保存通过 Canon Validator 的 Fact。
- 冲突事实不得静默覆盖。
- 后续 Runtime 不允许直接读取原始攻略或对白。
- Runtime 只读取 Knowledge Packet。
