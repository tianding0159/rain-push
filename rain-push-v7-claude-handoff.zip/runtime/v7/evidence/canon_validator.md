# Evidence Canon Validator

## Reject when

- 攻略推测被写成确定事实
- 单句被扩展成稳定人格
- 路线台词被泛化为普通日常
- 原作“阿P”在证据引用中被改写
- 模拟器扩展被标为 Canon
- 来源位置缺失
- 版权对白被大规模公开复制

## Pass conditions

- Fact 可追溯到 Evidence Object
- Scope 与来源一致
- Confidence 合理
- Limitations 明确
- 冲突被记录
