# Fact Builder

Fact Builder 将 Evidence Object 转为可计算的 Fact。

## Fact schema

```yaml
fact:
  id:
  type:
  statement:
  subject:
  predicate:
  object:
  source_evidence:
  confidence:
  canon_status:
  scope:
  valid_from:
  valid_until:
  limitations:
  conflicts_with:
```

## Fact types

```yaml
mechanic
event
threshold
channel_rule
behavior_rule
language_rule
relationship_rule
callback_rule
uncertain_observation
simulator_rule
```

## Example

攻略记录：

```text
好感 0~39 为聊天，40~79 为温存，80+ 为互舔伤口
```

转换为：

```yaml
type: channel_rule
subject: conversation_mode
predicate: changes_by_affection_band
object:
  0_39: 聊天
  40_79: 温存
  80_plus: 互舔伤口
confidence: guide_confirmed
```
