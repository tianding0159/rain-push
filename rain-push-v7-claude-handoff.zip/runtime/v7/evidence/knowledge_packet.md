# Knowledge Packet

```yaml
knowledge_packet:
  packet_id:
  generated_at:
  relevant_facts:
  relevant_rules:
  hard_constraints:
  confidence:
  conflicts:
  omitted_domains:
```

## Requirements

- 不包含无关完整知识库。
- 冲突必须显式输出。
- 模拟器扩展必须标明，不得伪装成 Canon。
