# Evidence Extractor

## Supported source types

```yaml
dialogue
guide
official
wiki
community
interview
code
asset
screenshot
user_note
simulator_extension
```

## Evidence Object

```yaml
evidence:
  id:
  source_type:
  source_ref:
  location:
  raw_excerpt:
  language:
  collected_at:
  collector:
  confidence:
  uncertainty_markers:
  copyright_scope:
```

## Extraction rules

- 保留原始措辞。
- 不在抽取阶段解释人物心理。
- “可能、推测、貌似、不确定”必须进入 `uncertainty_markers`。
- 只保存必要短片段与摘要，不批量公开复制完整对白。
