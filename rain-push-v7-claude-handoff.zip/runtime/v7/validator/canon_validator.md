# Canon Validator v7 Foundation

Before any synthetic line enters the corpus, the generator must answer:

1. What exact event triggered contact?
2. What state bands are active?
3. Which memory was retrieved?
4. What does Ame need P to do?
5. Which P role is active?
6. Why this channel?
7. Why Ame, KAngel or transition surface?
8. Which candidate behaviors were rejected?
9. Is the severity supported?
10. Does the message preserve ordinary life when no crisis is present?
11. Does a precise reply change the next behavior?
12. Is this copied surface language without copied function?
13. Could any generic clingy character say it unchanged?
14. Is there actual internet, career, life or self-brand logic?
15. Is the output free of modern AI therapy language?

Hard failure on 1, 2, 4, 6, 7, 9, 11 or 15.
