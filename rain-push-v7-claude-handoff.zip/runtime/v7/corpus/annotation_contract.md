# Corpus Annotation Contract v7

Each sample must carry:

```yaml
id:
text:
source:
  type:
  reference:
  confidence:
channel:
persona_surface:
canon_time:
day:
canon_state:
event_trigger:
functional_need:
p_role:
behavior_primitives:
expected_reply_class:
reply_timing_sensitivity:
state_effect:
route_severity:
context_required:
notes:
```

## Evidence levels

- A: channel, event, state and surrounding context are clear.
- B: the sentence itself reveals the main trigger and function.
- C: language fingerprint only.
- D: fragment, transcription, placeholder, duplicate or context-insufficient.

A/B may support behavior rules. C may support wording patterns only. D must not directly drive generation.
