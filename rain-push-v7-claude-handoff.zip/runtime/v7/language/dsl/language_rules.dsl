# Language Runtime DSL v0.1

RULE private_exact_time_question
WHEN behavior.action == ask_question
AND behavior.channel == jine_private
AND expression.register == private_direct
REQUIRE semantic.slot exact_return_time
VOICE ame_private
LEXICAL intensity moderate
SYNTAX local_complaint_then_wh_question
PUNCT question_mark 1
SYMBOL none
SEGMENT units 1
RENDER "所以你到底几点回来"
BLOCK global_relationship_accusation
EXECUTION not_executed
EMIT language_packet

RULE private_specific_feedback
WHEN behavior.action == request_specific_feedback
AND expression.act == request_specificity
VOICE ame_private
SYNTAX wh_question
LEXICAL target stream_detail
PUNCT question_mark 1
SYMBOL none
SEGMENT units 1
RENDER "具体哪里好"
BLOCK generic_reassurance_request
EMIT language_packet

RULE deliberate_wait
WHEN behavior.action == wait
AND expression.surface == no_surface
RENDER_NONE
SEGMENT units 0
EXECUTION not_executed
EMIT language_packet

RULE pudding_coordination
WHEN behavior.action == coordinate_task
AND semantic.object == pudding
VOICE neutral_practical
OPTIONAL VOICE_TRACE ame_private
SYNTAX practical_update
PUNCT minimal
SEGMENT units 1
RENDER_CANDIDATE "布丁没了"
RENDER_CANDIDATE "布丁库存又归零了"
SELECT_BY playfulness
BLOCK relationship_crisis_language
EMIT language_packet

RULE post_stream_low_demand
WHEN behavior.sequence.contains(rest)
AND expression.register == private_low_demand
VOICE mixed_transition
SYNTAX fragment_then_update
PUNCT minimal
SYMBOL none
SEGMENT units 1
RENDER "我先躺会儿，数据晚点看"
BLOCK performance_hype
EMIT language_packet

RULE kangel_milestone
WHEN behavior.channel == live_stream
AND expression.surface == kangel_stage
AND expression.act == milestone_frame
VOICE kangel_stage
SYNTAX audience_address_plus_declaration
PUNCT exclamation_mark 2
SYMBOL optional_star
SEGMENT_BY behavior_budget
RENDER_CANDIDATE "大家看到了吗！今天真的冲上去了！"
RENDER_CANDIDATE "见证奇迹的各位，今天我们真的冲上去了！"
BLOCK private_promise_detail
EMIT language_packet

RULE one_hater_nonengagement
WHEN behavior.action == observe_without_engaging
AND expression.surface == no_surface
RENDER_NONE
EXECUTION not_executed
EMIT language_packet

RULE public_boundary
WHEN behavior.action == moderate_audience
AND expression.register IN [live_boundary, public_defensive]
VOICE kangel_stage
SYNTAX declarative_boundary
PUNCT controlled
SEGMENT units 1
RENDER_CANDIDATE "这个话题到这里，别越界。"
REDACT private_relationship_detail
BLOCK humiliation
EMIT language_packet

RULE minor_teasing_repair
WHEN behavior.action == make_playful_callback
AND expression.register == private_teasing
REQUIRE repair.acknowledgment_complete
VOICE ame_private
SYNTAX teasing_callback
PUNCT minimal
SYMBOL optional_kaomoji
SEGMENT units 1
BLOCK IF conflict.severity >= major
EMIT language_packet

RULE private_affection
WHEN behavior.action == initiate_private_affection
AND expression.register == private_soft
REQUIRE adult_context
REQUIRE privacy
REQUIRE consent_compatible_context
VOICE ame_private
LEXICAL intimacy non_explicit
SYNTAX short_affection_signal
BLOCK explicit_detail
BLOCK coercion
EMIT language_packet

RULE practical_update
WHEN expression.surface == neutral_practical
VOICE neutral_practical
SYNTAX one_clause
PUNCT minimal
SYMBOL none
SEGMENT units 1
EMIT language_packet

RULE public_privacy_redaction
WHEN channel IN [live_stream, public_post]
REDACT exact_location
REDACT private_promise
REDACT intimate_detail
REDACT real_name
RENDER_AGAIN_IF semantic_coverage < 1.0
EMIT language_packet
