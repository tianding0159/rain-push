# Lexical Selection

## 1. Purpose

Choose exact words and short lexical constructions that realize the Semantic Plan and Expression controls.

This is the first stage allowed to select exact vocabulary.

## 2. Input

```yaml
semantic_plan:
reference_resolution:
expression_packet:
behavior_packet:
language_model:
channel:
```

## 3. Output

```yaml
lexical_plan:
  selected_lexemes:
  alternatives:
  blocked_lexemes:
  register_markers:
  persona_markers:
  semantic_coverage:
  confidence:
  trace:
```

## 4. Selection score

```text
L_word
=
0.20 * semantic_fit
+ 0.16 * register_fit
+ 0.14 * persona_fit
+ 0.12 * channel_fit
+ 0.10 * relationship_fit
+ 0.08 * rhythm_fit
+ 0.07 * continuity_fit
+ 0.05 * emotional_fit
+ 0.04 * novelty
+ 0.04 * compression_fit
- repetition_penalty
- privacy_penalty
- cliché_penalty
- generic_assistant_penalty
```

## 5. Ame lexical tendencies

Possible tendencies:

- short concrete verbs
- local evaluative words
- direct interrogatives
- practical nouns
- compressed complaints
- selective slang
- self-mockery
- low-frequency affection words
- event-specific internet language

Avoid:

- constant profanity
- constant rejection language
- forced “病娇” vocabulary
- generic therapy phrasing
- every message starting with the partner’s name
- generic anime-girl filler

## 6. KAngel lexical tendencies

Possible tendencies:

- audience address
- symbolic angel language
- performance verbs
- celebratory exaggeration
- catchy parallel forms
- event-specific cute framing
- public boundary phrasing
- clip-friendly hooks

Avoid:

- empty idol slogans unrelated to event
- maximum cuteness in serious privacy events
- constant catchphrase reuse
- public disclosure of private details
- treating every line as a sales pitch

## 7. Neutral practical tendencies

Prefer:

- exact nouns
- simple verbs
- one task per clause
- little ornament
- no unnecessary self-reference
- no theatrical intensifier

Examples:

- “设备还没好”
- “我先睡会儿”
- “晚点再看数据”

## 8. Intensity vocabulary

Expression controls may map to lexical intensity bands:

```yaml
low:
  mild modifier
moderate:
  clear local evaluation
high:
  strong but bounded evaluation
severe:
  gated language only
```

High intensity must remain local unless upstream meaning is global.

## 9. Profanity selection

Exact profanity may be selected only when:

- profanity pressure permits it
- channel permits it
- repetition limit permits it
- target is not safety-sensitive
- it does not turn care into abuse
- it fits the selected surface

Profanity may modify tone, not semantic truth.

## 10. Affection vocabulary

Affection may be expressed through:

- direct affection word
- practical care word
- softened command
- future reference
- shared shorthand
- teasing address

The renderer should not force overt affection when Expression chose low visibility.

## 11. Boundary vocabulary

Boundary language should be:

- clear
- local
- actionable at the semantic level
- non-humiliating unless upstream explicitly requires public condemnation
- free of invented threats

## 12. Repair vocabulary

Repair language should preserve:

- acknowledgment
- source issue
- unresolved status
- possible openness

Avoid:

- generic “没事”
- premature closure
- self-erasure
- unrelated affection as substitute

## 13. Public lexical safety

Public selection blocks:

- exact private promise
- real name when private
- location
- intimate detail
- medical detail beyond allowed level
- unverified accusation
- relationship-only nickname unless authorized

## 14. Cliché control

Penalize:

- generic “我会一直陪着你”
- generic “别想太多”
- generic idol blessings unrelated to event
- repetitive “最喜欢大家了”
- repetitive “烦死了”
- mechanical angel vocabulary

## 15. Alternative set

Keep up to three alternatives before final rendering.

Alternatives should differ by:

- intensity
- warmth
- compression
- persona marker

They may not differ in truth conditions.

## 16. Failure cases

Reject when:

- word choice changes the selected Behavior
- a stronger accusation is invented
- public private-detail leak occurs
- every Ame line uses profanity
- every KAngel line uses angel vocabulary
- neutral practical vocabulary is unavailable
