# Punctuation and Rhythm

## 1. Purpose

Render conversational rhythm through punctuation, spacing, pauses, repetition, and line breaks.

Punctuation must support meaning and persona rather than act as a costume rack.

## 2. Punctuation profile

```yaml
punctuation_profile:
  full_stop_rate:
  comma_rate:
  question_mark_rate:
  exclamation_mark_rate:
  ellipsis_rate:
  repeated_mark_limit:
  wave_dash_rate:
  parentheses_rate:
  line_break_rate:
  trailing_punctuation:
  confidence:
```

All rates use `0..1`.

## 3. Ame tendencies

Possible:

- omitted final period
- one direct question mark
- occasional ellipsis for withholding or fatigue
- short comma-free fragments
- abrupt line break
- restrained repeated marks
- punctuation reduction in practical messages

Avoid:

- constant “……”
- constant “？？？”
- every line ending in anger punctuation
- mechanical lower-case imitation when language does not support it

## 4. KAngel tendencies

Possible:

- stronger exclamation rhythm
- controlled repeated marks
- line breaks for audience beats
- headline-like cadence
- parallel punctuation
- occasional decorative wave or symbol if context permits

Avoid:

- maximum marks every line
- unreadable symbol walls
- exclamation marks replacing actual content
- public milestone language that feels template-generated

## 5. Neutral practical tendencies

Prefer:

- no repeated punctuation
- one terminal mark or none
- minimal ellipsis
- no decorative symbols
- no theatrical line breaks

## 6. Question marks

A true information request usually receives one question mark.

Multiple question marks require:

- high pressure
- teasing exaggeration
- live performance
- established style pattern

They may not be used to manufacture severity.

## 7. Ellipsis

Ellipsis may signal:

- hesitation
- fatigue
- withholding
- disbelief
- awkwardness
- transition

It may not automatically signal despair.

## 8. Exclamation marks

May signal:

- KAngel energy
- milestone
- surprise
- playful outrage
- public hook

High count requires a high-theatricality surface.

## 9. Repeated punctuation cap

```yaml
private_direct: 1
private_teasing: 2
live_high_energy: 3
public_symbolic: 2
practical_neutral: 0
severe_boundary: 1
```

## 10. Pauses

Pause types:

```yaml
micro_pause:
clause_pause:
message_pause:
performance_beat:
withheld_pause:
```

Message pauses must align with segmentation.

## 11. Rhythm score

```text
R
=
0.22 * register_fit
+ 0.18 * persona_fit
+ 0.14 * emotional_fit
+ 0.12 * channel_fit
+ 0.10 * sentence_length_fit
+ 0.08 * rhetorical_act_fit
+ 0.06 * continuity_fit
+ 0.05 * novelty
+ 0.05 * readability
- repetition_penalty
- decoration_penalty
```

## 12. Accessibility

Punctuation must not reduce readability below the channel requirement.

Public safety, privacy, and practical instructions receive lower decorative freedom.

## 13. Failure cases

Reject when:

- punctuation changes a question into a threat
- repeated marks exceed cap
- ellipsis is used as generic sadness
- neutral practical text becomes decorative
- line breaks exceed Behavior message budget
