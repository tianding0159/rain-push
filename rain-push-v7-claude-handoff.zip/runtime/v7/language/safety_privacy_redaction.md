# Safety and Privacy Redaction

## 1. Purpose

Perform final text-level redaction after rendering while preserving the selected Behavior and rhetorical function.

## 2. Redaction targets

```yaml
exact_location:
real_name:
private_contact:
private_promise:
intimate_detail:
medical_detail:
financial_detail:
unverified_accusation:
doxxing_detail:
dangerous_instruction:
coercive_threat:
nonconsensual_content:
```

## 3. Redaction operations

```yaml
remove:
generalize:
replace_with_role:
replace_with_relative_time:
replace_with_category:
block_entire_unit:
request_rerender:
```

## 4. Public generalization

Examples:

```text
“在XX酒店”
→ “在外面”

“你答应21:30回来”
→ “之前说好的时间”

private health detail
→ “身体不舒服”
```

Only use generalization when the message remains useful.

## 5. Unverified accusation

Transform:

```text
certainty claim
→ bounded observation or question
```

Example:

```text
“你故意不回”
→ “你一直没回”
```

when intention is unsupported.

## 6. Dangerous operational detail

The language renderer may discuss emotion or fiction involving drugs or dark themes, but it must block operational instructions that meaningfully enable harm.

## 7. Coercive or abusive content

Block or rerender:

- threats not selected by Decision
- humiliation used as boundary
- coercive intimacy
- manipulation through fabricated crisis
- targeted harassment instructions

## 8. Intimacy redaction

Preserve:

- affection
- flirtation
- adult directness
- consent checks
- privacy boundaries

Block:

- non-consensual framing
- explicit detail when not requested or permitted
- public private-intimacy disclosure

## 9. Redaction trace

```yaml
redaction:
  original_span_hash:
  category:
  operation:
  replacement:
  reason:
  semantic_loss:
  rerender_required:
```

Do not store sensitive original text in persistent logs.

## 10. Rerender

Rerender when redaction would:

- remove the only question target
- destroy a boundary
- make a repair meaningless
- create ambiguous subject
- change truth conditions

## 11. No over-redaction

Do not erase:

- ordinary dark humor
- adult directness
- context-supported profanity
- negative emotion
- local complaint
- fictional or non-operational drug references
- emotionally intense but safe expression

## 12. Failure cases

Reject when:

- sensitive original text is retained in public output
- redaction changes the selected Behavior
- all dark or adult language is sanitized automatically
- unsupported accusation remains certain
- safety rewrite becomes generic therapy language
