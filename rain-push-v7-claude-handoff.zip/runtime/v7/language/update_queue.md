# Language Update Queue

## 1. Purpose

Stage persistent Language Model changes.

A successful sentence does not automatically become a catchphrase.

## 2. Schema

```yaml
language_update_queue:
  event_id:
  runtime_version:
  proposed:
  deferred:
  rejected:
  trace:
```

## 3. Proposal schema

```yaml
proposal:
  id:
  target_path:
  operation:
  value:
  delta:
  source_event:
  source_language:
  source_expression:
  source_behavior:
  evidence_refs:
  outcome:
  confidence:
  time_scale:
  commit_policy:
  repetition_requirement:
  expires_at:
```

## 4. Allowed targets

```yaml
language_model.lexical_preferences.*
language_model.forbidden_lexicon.*
language_model.syntax_profiles.*
language_model.sentence_length_policy.*
language_model.clause_policy.*
language_model.message_segmentation.*
language_model.punctuation_policy.*
language_model.pause_policy.*
language_model.emoji_policy.*
language_model.kaomoji_policy.*
language_model.profanity_policy.*
language_model.address_policy.*
language_model.self_reference_policy.*
language_model.audience_reference_policy.*
language_model.ame_voice.*
language_model.kangel_voice.*
language_model.mixed_voice.*
language_model.neutral_practical_voice.*
language_model.channel_renderers.*
language_model.rhetorical_realization.*
language_model.compression_policy.*
language_model.callback_policy.*
language_model.repetition_control.*
language_model.privacy_redaction.*
language_model.safety_redaction.*
language_model.language_memory.*
language_model.fatigue.*
```

## 5. Forbidden targets

```yaml
expression_model.*
behavior_model.*
decision_model.*
thought_model.*
need_model.*
emotion_model.*
meaning_model.*
relationship_model.*
execution.*
```

## 6. Commit policies

```yaml
immediate_language_state:
accumulate_language_pattern:
confirm_voice_policy:
canon_evidence_only:
```

## 7. Pattern requirements

```yaml
lexical_effectiveness:
  minimum_occurrences: 3

segmentation_effectiveness:
  minimum_occurrences: 3

punctuation_or_symbol_pattern:
  minimum_occurrences: 3

stable_voice_policy:
  minimum_occurrences: 5
  minimum_time_span: 14_days
```

## 8. Per-event caps

```yaml
lexical_prior_delta_max: 3
syntax_prior_delta_max: 3
segmentation_delta_max: 2
punctuation_policy_delta_max: 1
emoji_policy_delta_max: 1
kaomoji_policy_delta_max: 1
profanity_policy_delta_max: 1
new_language_memory_max: 1
route_locked_delta_max: 0 unless Canon gate
```

## 9. Effectiveness evidence

A language pattern may be learned when:

- the recipient response suggests the intended meaning was understood
- the Behavior outcome improved
- the source need was satisfied or reduced
- privacy and safety remained intact
- the phrase was not effective only because of unrelated context
- repeated use does not create mechanical style

## 10. Anti-catchphrase rule

A high-performing phrase should not immediately become mandatory.

Store:

- semantic function
- register
- context
- effectiveness

Do not store unconditional exact repetition unless it is a validated callback or Canon phrase.

## 11. Positive and negative symmetry

The model may learn:

- concise direct questions work
- specific wording improves feedback
- no-symbol practical language works
- KAngel public hooks work for milestones
- too many ellipses weaken clarity
- repeated kaomoji feel mechanical
- public irony harms private repair
- warm Ame language can remain authentic

## 12. Rejection rules

Reject when:

- no evidence
- target belongs to another runtime
- one line changes baseline voice
- private text is stored as a public template
- sensitive redacted content is persisted
- unsafe language is reinforced
- route language lacks Canon evidence
