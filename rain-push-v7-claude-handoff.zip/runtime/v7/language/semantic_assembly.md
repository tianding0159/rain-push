# Semantic Content Assembly

## 1. Purpose

Assemble the exact semantic payload that final text must communicate.

This step precedes lexical style.

## 2. Input

```yaml
expression_packet:
behavior_packet:
decision_packet:
thought_packet:
need_packet:
meaning_packet:
continuity_packet:
knowledge_packet:
```

## 3. Output

```yaml
semantic_plan:
  required_content:
  optional_content:
  prohibited_content:
  presuppositions:
  unresolved_slots:
  rhetorical_order:
  reference_slots:
  redaction_slots:
  confidence:
  trace:
```

## 4. Required content

Required content comes from:

- selected Behavior action
- selected rhetorical acts
- success condition
- boundary requirement
- safety requirement
- exact information target
- repair acknowledgment
- practical task target

## 5. Optional content

Optional content may include:

- local complaint
- warmth
- teasing
- inside joke
- public hook
- self-mockery
- future link
- audience thanks

Optional content must not crowd out the required act.

## 6. Prohibited content

Examples:

- global accusation not selected upstream
- private detail in public channel
- unverified motive
- exact location
- explicit intimacy detail
- new threat
- new promise
- extra behavior
- invented memory
- irrelevant crisis language

## 7. Presupposition control

Do not presuppose:

- 豆豆 intentionally ignored her
- the audience universally agrees
- the relationship is ending
- the stream failure proves incompetence
- a sexual joke means consent
- a dark joke means active crisis

## 8. Unresolved slots

Examples:

```yaml
information_target:
feedback_target:
task_target:
time_reference:
audience_target:
callback_reference:
```

A slot must be resolved before rendering or explicitly omitted.

## 9. Rhetorical order

Example:

```yaml
required:
  - request_information
optional:
  - complain_local

order:
  - complain_local
  - request_information
```

or:

```yaml
order:
  - request_information
```

The order comes from Expression Packet.

## 10. Semantic minimality

A message should contain no more content than needed for the selected Behavior.

Example:

```text
Behavior:
ask one exact return-time question

Minimal semantics:
request exact return time
```

Do not add:

- relationship evaluation
- self-worth statement
- audience comparison
- unrelated affection test

## 11. Multi-act assembly

If multiple acts exist, define whether they belong in:

- one sentence
- two clauses
- two message units
- one public hook plus one explanation

This step sets structure, not wording.

## 12. No-surface assembly

For no-action, wait, or silent behavior:

```yaml
required_content: []
render: none
```

## 13. Failure cases

Reject when:

- required act missing
- optional content replaces required content
- new decision appears
- prohibited private detail included
- presupposition exceeds evidence
- unresolved slot reaches renderer
