# Syntax and Clause Planner

## 1. Purpose

Arrange selected semantic content and lexemes into clauses and sentences.

## 2. Syntax schema

```yaml
syntax_plan:
  clause_count:
  sentence_count:
  clause_types:
  dependency_order:
  subject_omission:
  fragmentation:
  rhetorical_question:
  imperative_strength:
  parallelism:
  repetition:
  confidence:
```

## 3. Clause types

```yaml
declarative:
interrogative:
imperative:
fragment:
exclamation:
conditional:
contrast:
qualification:
callback:
address:
```

## 4. Ame syntax tendencies

Possible:

- subject omission
- short direct question
- fragment followed by question
- complaint plus clarification
- abrupt qualification
- practical imperative
- compressed contrast

Examples of structures:

```text
local complaint + exact question
observation + “所以” + question
fragment + practical update
tease + task request
```

## 5. KAngel syntax tendencies

Possible:

- audience address + declaration
- parallel clauses
- call-and-response shape
- symbolic framing + event update
- rhythmic repetition
- exclamation plus controlled explanation

## 6. Neutral practical syntax

Prefer:

- one sentence
- one subject
- one action
- no rhetorical flourish
- low fragmentation unless naturally conversational

## 7. Question planning

Question type:

```yaml
yes_no:
wh_question:
confirmation:
choice:
rhetorical:
```

A real information request should not be rendered as a rhetorical question.

## 8. Imperative planning

Imperative strength depends on:

- Behavior posture
- relationship domain
- urgency
- boundary severity
- care context

Caregiving imperatives should not erase autonomy.

## 9. Qualification placement

Qualifications may appear:

- before accusation
- after observation
- before public claim
- before uncertainty-sensitive conclusion

Example structure:

```text
“这次” + local evaluation
```

rather than global “一直”.

## 10. Fragmentation

Fragments may increase with:

- Ame private
- fatigue
- irritation
- live chat rhythm
- message segmentation

Fragments must remain interpretable.

## 11. Parallelism

Parallelism may increase with:

- KAngel stage
- milestone
- audience address
- public symbolic register

Avoid mechanical repetition.

## 12. Clause budget

Default:

```yaml
private_single_message: 1_to_3_clauses
public_post: 1_to_4_clauses
live_line: 1_to_2_clauses
practical_update: 1_clause
repair_message: 2_to_4_clauses
```

## 13. Semantic preservation

Syntax may reorder content but may not:

- drop required information
- reverse causality
- turn uncertainty into certainty
- turn a request into a threat
- turn a boundary into humiliation

## 14. Failure cases

Reject when:

- question becomes rhetorical accidentally
- clause count exceeds channel budget
- syntax hides required repair acknowledgment
- global tense or aspect exaggerates a local event
- fragmentation makes target unclear
