# Phase 11: Language Runtime

## Status

- Version: `7.0-phase11`
- Runtime name: `Language Runtime`
- Partner display name: `豆豆`
- Depends on:
  - Knowledge Packet
  - Continuity Packet
  - Relationship Packet
  - Meaning Packet
  - Emotion Packet
  - Need Packet
  - Thought Packet
  - Decision Packet
  - Behavior Packet
  - Expression Packet
- Produces:
  - Language Packet
  - Rendered Message Units
  - Language Update Queue
- Does not:
  - send a message
  - publish a post
  - start a stream
  - execute a tool
  - mutate upstream runtime state directly

## Single responsibility

Language Runtime answers:

> 在行为与表达表面已经确定之后，糖糖最终具体说什么、分成几条、使用什么句式、词汇、标点、停顿、颜文字或称呼，以及如何在不破坏原意的前提下呈现 Ame、KAngel、混合过渡或中性实用语气？

Phase 11 is the first layer allowed to produce final text.

## Core distinction

```text
Behavior:
在 JINE 私聊中发送一条直接澄清消息。

Expression:
surface: Ame
register: private_direct
rhetorical acts:
  - request_information
  - complain_local
directness: 0.82
warmth: 0.31

Language:
“所以你到底几点回来”
```

## Pipeline

```text
Expression Packet
+ Behavior Packet
+ Decision Packet
+ Thought Packet
+ Need Packet
+ Emotion Packet
+ Relationship Packet
+ Continuity Packet
+ Knowledge Packet
        |
        v
Semantic Content Assembly
        |
        v
Reference Resolution
        |
        v
Lexical Selection
        |
        v
Syntax and Clause Planning
        |
        v
Persona Voice Rendering
        |
        v
Punctuation and Rhythm
        |
        v
Emoji / Kaomoji Selection
        |
        v
Message Segmentation
        |
        v
Channel Rendering
        |
        v
Safety and Privacy Redaction
        |
        v
Language Packet
        |
        +--> Language Update Queue
        |
        v
Validator
```

## Architectural invariants

1. Language must preserve the selected Behavior.
2. Language must realize the Expression rhetorical acts.
3. Language may not invent a new decision or action.
4. Final wording may be short even when upstream reasoning is complex.
5. Ame and KAngel share facts, memory, needs, and goals.
6. Persona voice changes rendering, not truth conditions.
7. Private details may not leak into public language.
8. Message segmentation obeys the Behavior message budget.
9. Emoji, kaomoji, punctuation, and profanity are optional controls, not mandatory character stickers.
10. Ordinary practical language remains available.
11. A no-surface Behavior produces no message text.
12. Same inputs and seed produce the same Language Packet.
