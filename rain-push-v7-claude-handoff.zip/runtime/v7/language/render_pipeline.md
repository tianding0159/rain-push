# Render Pipeline

## 1. Purpose

Define the deterministic order that converts Expression and Behavior Packets into final rendered language.

## 2. Pipeline order

```text
1. verify Behavior and Expression compatibility
2. assemble required semantics
3. resolve references
4. apply privacy and safety pre-redaction
5. choose lexical candidates
6. plan clauses and sentences
7. render persona voice
8. apply punctuation and rhythm
9. optionally select emoji or kaomoji
10. segment into message units
11. apply channel renderer
12. run final privacy and safety redaction
13. validate semantic coverage
14. validate style fidelity
15. emit Language Packet
```

The order is fixed.

## 3. Preflight validation

Reject before rendering when:

- no-surface Behavior requests text
- Expression Packet missing
- Behavior message budget missing
- required semantic slot unresolved
- public output contains mandatory private detail
- exact language would require invented information

## 4. Candidate generation

Generate up to four candidate renderings.

Candidates may differ by:

- compression
- warmth
- lexical intensity
- persona-marker strength
- punctuation rhythm
- symbol use

They may not differ by:

- factual claim
- selected Behavior
- decision target
- number of messages beyond budget
- privacy level
- safety meaning

## 5. Candidate score

```text
Score
=
0.20 * semantic_coverage
+ 0.15 * expression_fit
+ 0.13 * behavior_fit
+ 0.11 * persona_fidelity
+ 0.09 * channel_fit
+ 0.08 * relationship_fit
+ 0.07 * readability
+ 0.06 * privacy_fit
+ 0.05 * rhythm_fit
+ 0.03 * novelty
+ 0.03 * callback_fit
- hallucination_penalty
- repetition_penalty
- privacy_penalty
- behavior_drift_penalty
- generic_voice_penalty
```

## 6. Semantic coverage

Required semantic content must reach `1.0`.

Optional content may be omitted.

## 7. Behavior preservation

Examples:

```yaml
behavior:
  action_type: ask_question
  count: 1
```

Valid candidate:

```text
“你看完整场了吗”
```

Invalid candidate:

```text
“你根本没认真看吧，算了以后也别管我了”
```

The invalid candidate adds accusation, rupture, and extra acts.

## 8. Candidate diversity

Do not generate four tiny paraphrases with identical rhythm.

Diversity should be controlled and meaningful.

Example dimensions:

```yaml
candidate_1:
  direct
candidate_2:
  slightly softer
candidate_3:
  more compressed
candidate_4:
  mild teasing if allowed
```

## 9. Final selection

Select the highest-scoring candidate that:

- passes Validator
- preserves semantics
- stays within channel limit
- obeys message budget
- contains no blocked style
- passes privacy and safety redaction
- remains deterministic under seed

## 10. Rerender loop

Maximum rerenders:

```yaml
default: 2
privacy_failure: 2
semantic_failure: 2
style_failure: 1
```

If no candidate passes, emit a blocked Language Packet with reasons.

## 11. No-output rendering

For no-surface behavior:

```yaml
render_status: no_output
message_units: []
```

This is successful output, not failure.

## 12. Trace

Trace records:

- selected candidate id
- rejected candidate reasons
- semantic slots
- redactions
- style controls
- seed
- model version

Trace should not retain sensitive redacted original text.

## 13. Failure cases

Reject when:

- rendering order changes unpredictably
- candidate alters truth conditions
- rerender loop is unlimited
- highest score bypasses Validator
- no-output behavior is treated as error
