# Language Packet

## 1. Schema

```yaml
language_packet:
  packet_id:
  runtime_version:
  schema_version:
  generated_at:
  mode:
  event_id:
  behavior_refs:
  expression_ref:
  render_status:
  selected_candidate:
  message_units:
  rendered_text:
  semantic_coverage:
  reference_resolution:
  lexical_profile:
  syntax_profile:
  punctuation_profile:
  symbol_profile:
  segmentation:
  channel_rendering:
  redactions:
  blocked_content:
  alternatives:
  uncertainty:
  confidence:
  trace:
```

## 2. Render status

```yaml
rendered:
no_output:
blocked:
rerender_required:
```

## 3. Message unit

```yaml
message_unit:
  index:
  channel:
  text:
  rhetorical_acts:
  sentence_count:
  character_count:
  pause_after:
  punctuation_profile:
  symbols:
  redactions:
  confidence:
```

## 4. Rendered text

`rendered_text` is the final joined representation.

For JINE, it may preserve message-unit boundaries.

For live speech, it may preserve utterance boundaries.

For no-output behavior:

```yaml
rendered_text: null
message_units: []
```

## 5. Semantic coverage

```yaml
semantic_coverage:
  required_total:
  required_realized:
  optional_realized:
  missing:
  score:
```

Required coverage must be `1.0` for rendered output.

## 6. Lexical profile

```yaml
lexical_profile:
  intensity:
  profanity_level:
  persona_marker_strength:
  repetition_hits:
  callback_used:
  blocked_lexemes:
```

## 7. Syntax profile

```yaml
syntax_profile:
  clause_count:
  sentence_count:
  fragments:
  questions:
  imperatives:
  qualifications:
  parallelism:
```

## 8. Symbol profile

```yaml
symbol_profile:
  emoji:
  kaomoji:
  text_symbols:
  count:
  semantic_roles:
```

## 9. Alternatives

Store at most three unselected candidate summaries.

Do not persist sensitive discarded text when privacy redaction triggered.

## 10. Packet purity

Language Packet may contain final text.

It may not claim:

- the message was sent
- the post was published
- the stream line was spoken
- an external tool succeeded
- the recipient responded

Execution remains Phase 12.

## 11. Example: private clarification

```yaml
render_status: rendered

message_units:
  - index: 1
    channel: jine_private
    text: “所以你到底几点回来”
    rhetorical_acts:
      - request_information
      - complain_local

semantic_coverage:
  required_total: 1
  required_realized: 1
  score: 1.0
```

## 12. Example: wait

```yaml
render_status: no_output
rendered_text: null
message_units: []
```
