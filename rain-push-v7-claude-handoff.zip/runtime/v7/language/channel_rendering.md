# Channel Rendering

## 1. Purpose

Apply channel-specific length, structure, persistence, and audience conventions to final language.

## 2. JINE private renderer

Typical constraints:

```yaml
unit_length: short_to_medium
message_units: behavior_budget
audience: partner
persistence: medium
privacy: high_but_not_absolute
response_expectation: asynchronous
```

Common forms:

- one direct question
- one practical update
- two-part repair
- short teasing callback
- low-demand presence message

## 3. Live-stream renderer

Typical constraints:

```yaml
unit_length: short
message_units: utterance_sequence
audience: current_viewers
persistence: medium_to_high
performance_energy: active
response_expectation: immediate_chat
```

Common forms:

- hook
- audience address
- milestone line
- transformed complaint
- public boundary
- call-and-response prompt

## 4. Public-post renderer

Typical constraints:

```yaml
unit_length: short_to_medium
persistence: high
screenshot_risk: high
context_collapse: high
editability: platform_dependent
```

Requirements:

- stronger redaction
- fewer private references
- one clear public purpose
- no unresolved private conflict spillover
- readable without hidden context unless deliberate inside-audience callback

## 5. Face-to-face renderer

Language may be shorter because Behavior and nonverbal context carry information.

Do not invent gestures unless Behavior Packet includes them.

## 6. Physical-world renderer

Some actions need no text.

When text is required:

- practical
- short
- locally grounded
- low decoration
- exact object or task

## 7. Internal-wait renderer

Produces no text.

## 8. Platform length

Language Model may contain configurable platform limits.

If unknown:

- use conservative length
- avoid platform-specific assumptions
- do not invent hashtags or mentions

## 9. Hashtags and mentions

May be selected only when:

- public Behavior permits
- platform context exists
- audience goal supports it
- privacy check passes

They are exact lexical items and belong in this phase.

## 10. Threading

A public thread or multiple JINE units requires Behavior support for multiple units.

## 11. Channel fallback

If public rendering fails privacy validation:

- fall back to private language
- fall back to neutral practical public update
- or produce no output

The fallback may not change Behavior without trace.

## 12. Failure cases

Reject when:

- public text relies on private context without authorization
- live line becomes a long essay
- JINE unit count exceeds budget
- internal wait produces text
- unsupported hashtags are invented
