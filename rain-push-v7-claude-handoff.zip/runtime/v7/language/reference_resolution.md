# Reference Resolution

## 1. Purpose

Resolve who, what, when, and which prior event each final expression refers to.

## 2. Reference slots

```yaml
speaker:
partner:
audience:
third_party:
event:
object:
task:
promise:
time:
location:
stream:
metric:
callback:
persona:
```

## 3. Resolution schema

```yaml
reference:
  slot:
  resolved_value:
  source_packet:
  confidence:
  public_safe:
  exactness:
  fallback:
```

## 4. Partner reference

Generated partner reference defaults to `豆豆` when a name is needed.

The renderer may omit explicit address when:

- subject is obvious
- repetition control applies
- a short direct message reads more naturally
- the register is neutral practical

The renderer must not silently substitute another name.

## 5. Audience reference

Possible resolved forms:

- current viewers
- all fans
- a hostile subset
- one viewer
- platform audience
- no explicit audience reference

Do not turn one viewer into “everyone”.

## 6. Persona reference

Possible semantic referents:

- Ame
- KAngel
- private self
- stage self
- both surfaces
- current surface only

Ame and KAngel remain one person.

## 7. Time reference

Resolve:

- exact clock time
- relative time
- promised time
- deadline
- “later”
- “after stream”
- “tomorrow”

Do not invent exact time from vague upstream data.

## 8. Promise reference

A promise may be referred to only when Continuity Packet confirms:

- content
- owner
- due time or condition
- current status

## 9. Callback reference

A callback may use shorthand only when:

- shared language exists
- callback confidence is sufficient
- current channel audience understands it
- privacy constraints permit it

## 10. Public-safe resolution

Public language may generalize:

```text
exact private promise
→ “之前说好的事”

exact location
→ “外面”

specific private health detail
→ “身体不舒服”
```

Only when the required Behavior still remains intelligible.

## 11. Ambiguity handling

When a reference cannot be resolved:

- ask internally for slot completion
- use a safe generic reference
- omit optional reference
- block rendering if required meaning would be lost

## 12. Failure cases

Reject when:

- wrong person is addressed
- one audience member becomes all viewers
- exact private detail leaks publicly
- vague time becomes invented exact time
- callback is used without shared context
- Ame and KAngel are treated as different speakers
