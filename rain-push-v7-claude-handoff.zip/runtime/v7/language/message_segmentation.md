# Message Segmentation

## 1. Purpose

Split rendered content into one or more message units while obeying Behavior count and channel conventions.

## 2. Input

```yaml
behavior_packet:
expression_packet:
semantic_plan:
syntax_plan:
channel:
language_model:
```

## 3. Output

```yaml
segmentation_plan:
  unit_count:
  units:
  split_reasons:
  merge_reasons:
  maximum_allowed:
  confidence:
```

## 4. Hard rule

```text
unit_count <= behavior.message_or_action_count
```

If Behavior allows one message, Language Runtime may not create three bubbles.

## 5. Split reasons

Valid:

- two distinct rhetorical acts
- emotional turn
- public hook plus explanation
- clarification followed by practical update
- live audience rhythm
- deliberate pause
- callback as separate beat

## 6. Merge reasons

Prefer one unit when:

- one direct question
- one practical update
- one low-stakes boundary
- one acknowledgment
- message budget is one
- splitting would create pressure or spam

## 7. Ame segmentation tendencies

Possible:

- one compact line
- two short bubbles for emotional turn
- fragment then direct question
- practical update alone

Avoid mechanical multi-bubble dramatization.

## 8. KAngel segmentation tendencies

Possible:

- hook
- announcement
- audience-response line

The Behavior budget still controls count.

## 9. Public post segmentation

May use:

- one paragraph
- short line breaks
- headline plus body
- bullet-like rhythm only when event supports it

## 10. Live rendering

Live output may be represented as one line or several utterance units, but each must remain within the Behavior sequence.

## 11. Silence

No-surface Behavior yields:

```yaml
unit_count: 0
units: []
```

## 12. Message burst control

Block:

- repeated single-word bubbles
- multiple question marks across separate units
- repeated partner address
- artificial cliffhanger
- escalation by segmentation

unless explicitly selected by Behavior and supported by style.

## 13. Unit schema

```yaml
unit:
  index:
  rhetorical_acts:
  semantic_content:
  sentence_count:
  expected_length:
  pause_after:
```

## 14. Failure cases

Reject when:

- unit count exceeds Behavior budget
- one direct question is split into spam
- silence produces a unit
- segmentation changes act order
- a required clause is dropped
