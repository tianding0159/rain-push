# Expression Pressure

## 1. Purpose

Expression Pressure measures how strongly internal emotion pushes toward outward expression.

It is not an action decision.

It is not message count.

It provides later phases with pressure and surface tension.

## 2. Components

```yaml
expression_pressure:
  internal_intensity:
  unresolved_meaning:
  suppression_duration:
  channel_opportunity:
  relationship_safety:
  audience_pressure:
  body_disinhibition:
  recent_expression:
  fatigue:
  masking_cost:
```

## 3. Formula

```text
P_expression
=
0.24 * internal_intensity
+ 0.16 * unresolved_meaning
+ 0.14 * suppression_duration
+ 0.10 * channel_opportunity
+ 0.10 * relationship_safety
+ 0.08 * audience_pressure
+ 0.06 * body_disinhibition
+ 0.07 * masking_cost
+ 0.05 * novelty
- recent_expression_release
- fatigue_inhibition
```

Clamp to `0..1`.

## 4. Interpretation

```yaml
0.00..0.24:
  low
0.25..0.49:
  contained
0.50..0.69:
  active
0.70..0.84:
  high
0.85..1.00:
  spillover_risk
```

## 5. Expression channels

### JINE

Best for:

- direct attachment emotion
- irritation
- specific requests
- private vulnerability
- practical complaints

### Live stream

Best for:

- performance high
- audience euphoria
- theatrical anger
- cute reframing
- content conversion

### Public post

Best for:

- symbolic emotion
- audience-facing pride
- indirect anger
- platform dread
- poetic or negative posting under valid channel mode

### Face-to-face

Best for:

- embarrassment
- tenderness
- body comfort
- direct conflict
- repair

## 6. Surface pressure split

```yaml
ame_pressure:
kangel_pressure:
public_post_pressure:
silence_pressure:
```

High internal pressure does not imply Ame expression if the active channel is live stream.

## 7. Suppression cost

```text
masking_cost
=
hidden_intensity
* duration
* channel_mismatch
* unresolved_source
```

High masking cost can produce:

- abrupt tone break
- post-stream crash
- private follow-up
- accidental persona leak

These are later-phase possibilities, not decisions here.

## 8. Release

Expression may lower pressure.

Release amount depends on:

- specificity
- whether actual source was expressed
- whether 豆豆 responded accurately
- whether public expression worsened exposure
- whether the expression was masked

Generic venting may provide little release.

## 9. Pressure accumulation examples

### Generic feedback unresolved

```yaml
irritation: 55
shame: 32
suppression_duration: medium
expression_pressure: 0.68
```

### Stream performance

```yaml
performance_high: 80
fatigue: 70
private_vulnerability: hidden
kangel_pressure: high
ame_pressure: accumulating
```

### Minor pudding issue

```yaml
irritation: 35
absurd_amusement: 30
relationship_safety: high
expression_pressure: 0.42
```

## 10. Spillover

Spillover risk rises when:

- multiple emotions exceed 60
- masking cost is high
- unresolved question remains
- body fatigue is high
- channel transition occurs
- recent regulation failed

## 11. Block rules

- low intensity cannot create high pressure without long suppression
- route spillover requires route evidence
- deep night alone cannot create pressure
- performance high does not erase private pressure
- audience pressure cannot directly become relationship accusation
