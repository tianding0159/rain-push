# Emotion Regulation

## 1. Purpose

Emotion Regulation models how emotional intensity is modified before later phases decide needs or behavior.

Regulation is not always healthy, deliberate, or successful.

## 2. Regulation sources

```yaml
self_regulation:
doudou_regulation:
career_regulation:
internet_regulation:
body_regulation:
channel_regulation:
avoidance_regulation:
humor_regulation:
```

## 3. Self-regulation strategies

### Reframing

Examples:

- “算了，反正也能拿去直播”
- treating a mistake as content
- converting embarrassment into a joke

Possible effects:

- embarrassment down
- internet_excitement up
- unresolved shame may remain

### Intellectualization

Examples:

- analyzing audience behavior
- discussing platform logic
- turning a relationship concern into career analysis

Possible effects:

- surface anxiety down
- underlying vulnerability unchanged
- control appraisal up

### Self-branding

Examples:

- angel framing
- demon framing
- “垃圾女人” framing
- game-character framing

Possible effects:

- shame reorganized into performative identity
- expression becomes easier
- global self-worth may remain unstable

### Topic shift

Effects depend on whether source meaning is resolved.

- resolved shift: healthy closure
- unresolved shift: suppression
- abrupt repeated shift: avoidance pattern

### Sleep / food / ordinary routine

May reduce:

- fatigue
- irritability
- post-stream crash
- low-level vulnerability

Does not automatically solve:

- betrayal
- unresolved exact question
- severe identity conflict

## 4. 豆豆-mediated regulation

### Specific feedback

Effective for:

- validation uncertainty
- career evaluation
- “你到底有没有认真看”

Possible effects:

```yaml
validation_relief: up
irritation: down
trust.attention: supported
shame_sensitivity: down
```

### Generic reassurance

May help:

- mild loneliness
- low uncertainty

May fail when:

- exact question unanswered
- repeated broken promise
- specific feedback requested
- contradiction remains

### Practical action

Examples:

- buying food
- fixing equipment
- completing promised task
- giving exact return time

Effective for:

- practical uncertainty
- shared-life irritation
- producer distrust
- control loss

### Shared humor

Effective when:

- inside joke valid
- conflict minor
- both parties still engaged

May fail when:

- event severe
- humor invalidates concrete harm
- route-critical state

### Presence

Effective for:

- loneliness
- vulnerability
- post-stream crash
- mild unreality

Presence is not automatically equivalent to verbal reassurance.

## 5. Career regulation

### Streaming

Can:

- raise performance_high
- suppress shame
- convert pain to content
- increase audience euphoria
- delay crash

May also:

- increase public pressure
- deepen dependence on attention
- worsen fatigue

### Data checking

Can:

- reduce uncertainty if result is clear
- increase career hunger
- amplify failure sting
- reinforce recognition tolerance

### Planning

Can:

- increase control
- reduce helplessness
- redirect irritation

## 6. Internet regulation

### Meme conversion

Can reduce:

- embarrassment
- local shame
- helplessness

Can increase:

- internet excitement
- scandal energy
- audience anticipation

### Posting

Can:

- externalize anger
- seek audience confirmation
- create public spillover
- worsen later shame

### Anonymous board use

Meaning depends on Canon darkness bands.

- observe
- self-stage
- attack

Emotion Regulation must read valid channel state.

## 7. Body regulation

```yaml
water:
food:
sleep:
warmth:
movement:
medically_safe_care:
```

Body regulation affects only supported emotions.

It cannot resolve:

- loyalty conflict
- identity betrayal
- unfulfilled hard callback

## 8. Regulation effectiveness formula

```text
effectiveness
=
0.25 * strategy_target_fit
+ 0.20 * source_credibility
+ 0.15 * timing_fit
+ 0.15 * specificity
+ 0.10 * relationship_trust
+ 0.10 * follow_through
+ 0.05 * body_state_fit
- invalidation_penalty
- repetition_fatigue
```

## 9. Regulation result

```yaml
regulation_result:
  strategy:
  target_emotions:
  effective_delta:
  unresolved_components:
  rebound_risk:
  confidence:
```

## 10. Failed regulation

Examples:

- 豆豆 says “别想太多” after a specific ignored question
- joking during a major conflict
- telling her to rest when she asked for stream analysis
- praising KAngel when she asked about Ame
- practical help without acknowledging a loyalty injury

Failure may increase:

- irritation
- shame
- attunement distrust
- expression pressure

## 11. Overregulation

Too much regulation can feel controlling.

Examples:

- repeatedly telling her what she should feel
- solving every problem without collaboration
- forcing calm
- treating all dark humor as crisis

Meaning:

- control loss
- invalidation
- identity reduction

## 12. Canon constraints

- precise replies can work
- absurd shared humor can work
- not every serious reply helps
- not every harsh joke harms
- context determines effect
- ordinary food/rest regulation is real but limited
- route-level states require more than one comforting line
