# Emotion Update Queue

## 1. Purpose

Emotion Update Queue stages persistent changes proposed by Emotion Runtime.

Current-turn emotion state must never be written directly into Emotion Model.

The queue protects against:

- turning one mood into a permanent trait
- converting one outburst into a stable pattern
- making one successful reassurance permanently erase sensitivity
- making one failure permanently increase anxiety
- leaking route-level states into ordinary Living Mode

## 2. Input

```yaml
emotion_packet:
relationship_packet:
meaning_packet:
continuity_packet:
emotion_model:
event:
mode:
```

## 3. Output

```yaml
emotion_update_queue:
  event_id:
  runtime_version:
  proposed:
  deferred:
  rejected:
  validation_context:
  trace:
```

## 4. Proposal schema

```yaml
proposal:
  id:
  target_path:
  operation:
  value:
  delta:
  source_event:
  source_emotions:
  source_meanings:
  evidence_refs:
  confidence:
  time_scale:
  commit_policy:
  repetition_requirement:
  decay_policy:
  expires_at:
  supersedes:
```

## 5. Time scales

```yaml
fast:
  examples:
    - current expression pressure
    - fatigue residue
    - post-stream crash residue
    - short masking state

medium:
  examples:
    - sensitivity to generic feedback
    - repair effectiveness pattern
    - channel transition pattern
    - safety memory

slow:
  examples:
    - baseline emotional sensitivity
    - persistent masking habit
    - stable emotion coexistence pattern
    - recognition tolerance

route_locked:
  examples:
    - hard callback affect
    - ending-specific emotional state
```

## 6. Commit policies

### 6.1 Immediate fast state

Used for temporary runtime residue.

```yaml
commit_policy: immediate_fast
allowed_targets:
  - residue
  - fatigue
  - expression_pressure
  - short_masking
```

Fast writes still require:

- source event
- confidence
- expiration or decay rule

### 6.2 Accumulate medium pattern

Used when several events support the same tendency.

```yaml
commit_policy: accumulate_medium
minimum_evidence_count: 3
minimum_confidence: 0.60
```

Examples:

- specific feedback reliably reduces irritation
- live-to-private transition reliably produces crash
- inside jokes reliably reduce minor conflict tension

### 6.3 Confirm slow trait

Used for persistent changes.

```yaml
commit_policy: confirm_slow
minimum_evidence_count: 5
minimum_time_span: 14_days
minimum_confidence: 0.75
```

Examples:

- baseline shame sensitivity changed
- ordinary comfort became more stable
- masking habit weakened

### 6.4 Canon evidence only

```yaml
commit_policy: canon_evidence_only
```

Required for:

- route-level dread
- ending-specific numbness
- Canon hard callback emotional persistence
- original-stat threshold rules

## 7. Allowed target paths

```yaml
emotion_model.baselines.*
emotion_model.sensitivities.*
emotion_model.thresholds.*
emotion_model.recovery.*
emotion_model.persistence.*
emotion_model.masking.*
emotion_model.coexistence_rules.*
emotion_model.channel_modifiers.*
emotion_model.expression_pressure.*
emotion_model.fatigue.*
emotion_memory.residue.*
emotion_memory.conditioned_trigger.*
emotion_memory.repair_memory.*
emotion_memory.safety_memory.*
emotion_memory.performance_memory.*
emotion_memory.audience_memory.*
emotion_memory.body_memory.*
emotion_memory.route_memory.*
```

## 8. Forbidden target paths

```yaml
relationship_model.*
meaning_model.*
knowledge.*
continuity.*
persona.*
language.*
decision.*
need.*
thought.*
```

Emotion Runtime cannot mutate another runtime’s persistent model.

## 9. Per-event caps

```yaml
fast_residue_delta_max: 20
expression_pressure_delta_max: 0.25
medium_sensitivity_delta_max: 3
recovery_effectiveness_delta_max: 3
baseline_delta_max: 1
route_locked_delta_max: 0 unless Canon gate
new_pattern_max: 1
```

## 10. Residue proposal rules

Write residue when:

```yaml
any:
  - peak_intensity >= 60
  - unresolved_source == true
  - post_stream_transition == true
  - severe public exposure == true
  - repair incomplete == true
```

Do not write residue when:

- emotion intensity below 25
- source fully resolved
- event is trivial and non-repeating
- candidate emotion confidence below 0.45

## 11. Conditioned trigger proposal rules

A conditioned trigger requires:

```yaml
evidence_count: >= 3
semantic_similarity: >= 0.65
same_target_emotion: true
contradictory_safety_evidence: considered
```

Example:

```yaml
target_path: emotion_memory.conditioned_trigger.generic_feedback
operation: reinforce
delta: 0.05
source_emotions:
  - irritation
  - vulnerability
```

## 12. Safety memory proposal rules

Create safety memory when:

- feared interpretation did not occur
- 豆豆 gave precise and credible response
- a delay ended with reliable return
- a minor conflict was repaired successfully
- a public event remained safe despite expected risk

Safety memory must not be weaker by default than negative memory.

## 13. Repair memory proposal rules

Record:

```yaml
strategy:
target_emotion:
effective_delta:
follow_through:
durability:
context:
```

One pleasant message is not enough to create durable repair memory.

## 14. Performance memory proposal rules

Record when:

- stream happened
- performance high or crash exceeded threshold
- recovery method was observed
- audience response materially affected emotion

Do not treat every stream as unique permanent memory.

## 15. Expression pressure updates

Allowed:

```yaml
target_path: emotion_model.expression_pressure.recent_suppression
operation: increment
```

Conditions:

- emotion hidden at surface
- masking lasted beyond threshold
- source remained unresolved

Release proposal:

```yaml
target_path: emotion_model.expression_pressure.recent_suppression
operation: decrement
```

Conditions:

- source emotion expressed
- the real source was addressed
- regulation was effective

Generic venting does not guarantee release.

## 16. Rejection rules

Reject proposal when:

- no evidence reference
- target belongs to another runtime
- route state lacks Canon gate
- one event proposes baseline change greater than 1
- one apology proposes full recovery
- one failure proposes permanent trigger
- a masked emotion is assumed to have disappeared
- surface KAngel expression is used as proof of underlying emotion
- current emotion is stored as personality fact

## 17. Deferred proposals

Use `deferred` when:

- evidence count insufficient
- a pattern may be forming
- current event is ambiguous
- contradictory evidence exists
- Canon gate status unresolved

Deferred proposal schema:

```yaml
deferred:
  proposal:
  missing_evidence:
  review_after:
  invalidation_conditions:
```

## 18. Supersession

A new proposal may supersede an older one only when:

- same target path
- stronger evidence
- later timestamp
- explicit contradiction or resolution

Never silently delete the older proposal.

## 19. Conflict resolution

When proposals conflict:

```text
Canon evidence
> direct observed pattern
> repeated Living Mode evidence
> single direct event
> inferred event
```

Positive and negative evidence may coexist.

## 20. Commit result

```yaml
commit_result:
  accepted:
  revised:
  deferred:
  rejected:
  model_version_before:
  model_version_after:
  trace:
```

## 21. Examples

### Specific feedback works repeatedly

```yaml
proposal:
  target_path: emotion_model.recovery.validation_relief.specific_feedback
  operation: reinforce
  delta: 2
  evidence_count: 4
  confidence: 0.82
  commit_policy: accumulate_medium
```

### One generic reply irritates her

```yaml
proposal:
  target_path: emotion_model.sensitivities.generic_feedback.irritation
  operation: reinforce
  delta: 1
  evidence_count: 1
  confidence: 0.58
  commit_policy: accumulate_medium
```

Result:

```yaml
status: deferred
reason: insufficient_repetition
```

### Post-stream fatigue

```yaml
proposal:
  target_path: emotion_memory.residue.post_stream_fatigue
  operation: create
  value:
    intensity: 48
    decay_class: short
  confidence: 0.88
  commit_policy: immediate_fast
```
