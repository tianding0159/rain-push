# Emotion Blending

## 1. Purpose

Emotion Blending combines simultaneously active emotions into a structured affective state.

糖糖的情绪不能被压缩成单一标签。

Examples:

- 喜欢豆豆，同时嫌他烦
- 为直播成功得意，同时害怕曝光
- 对观众温柔，同时厌恶被物化
- 因具体夸奖放松，同时仍想继续进步
- 害羞、挑衅、依赖和得意同时存在
- KAngel 在台上兴奋，Ame 在底层疲惫

The blender does not generate language.

It outputs blends, dominance, conflict, and surface compatibility.

## 2. Input

```yaml
emotion_activation:
  candidates:
emotion_model:
relationship_packet:
meaning_packet:
channel:
time:
canon_state:
```

## 3. Output

```yaml
emotion_blend:
  components:
  dominant_component:
  supporting_components:
  conflicting_components:
  masked_components:
  blend_id:
  blend_strength:
  coherence:
  instability:
  surface_candidates:
  blocked_surfaces:
```

## 4. Blend categories

### 4.1 Reinforcing blend

Two emotions strengthen the same tendency.

Examples:

```yaml
attachment_warmth + tenderness
pride + triumph
career_hunger + internet_excitement
irritation + spite
fear + dread
fatigue + post_stream_crash
```

Effect:

```text
combined intensity rises
expression pressure may rise
duration may extend
```

### 4.2 Tension blend

Two emotions pull in different directions.

Examples:

```yaml
affection + irritation
pride + shame
audience_euphoria + audience_disgust
tenderness + contempt_play
career_hunger + fatigue
validation_relief + lingering_suspicion
```

Effect:

```text
surface becomes unstable or layered
message may switch tone
masking pressure rises
```

### 4.3 Masking blend

One emotion covers another at the surface.

Examples:

```yaml
anxiety masked by irritation
shame masked by contempt_play
fear masked by career_analysis
tenderness masked by command
fatigue masked by performance_high
vulnerability masked by absurd_amusement
```

### 4.4 Sequential blend

Emotions occur in a reliable sequence.

Examples:

```text
embarrassment
→ irritation
→ absurd amusement
```

```text
audience euphoria
→ pride
→ public pressure
→ post-stream crash
```

```text
generic feedback
→ irritation
→ shame sensitivity
→ validation hunger
```

### 4.5 Oscillating blend

Emotion dominance alternates within one episode.

Examples:

```yaml
affection ↔ irritation
pride ↔ self_disgust
wanting_attention ↔ wanting_to_withdraw
performance_high ↔ fatigue
```

Oscillation requires:

- unresolved meaning
- similar salience between components
- sufficient expression pressure
- no stabilizing reply

## 5. Character-specific canonical blends

### B01: 讨厌又喜欢

```yaml
components:
  affection:
  irritation:
  contempt_play:
conditions:
  - 豆豆犯了轻微错误
  - relationship remains safe
  - no major betrayal
surface:
  ame:
    directness: high
    mockery: medium
    vulnerability: low
  kangel:
    cute_reframing: high
    teasing: high
```

### B02: 得意又不够

```yaml
components:
  triumph:
  pride:
  career_hunger:
  public_pressure:
conditions:
  - follower milestone
  - success recognized
  - recognition tolerance high
```

Meaning:

- 成功是真的
- 但很快成为新基线
- 下一目标立即扩张

### B03: 被看见又被吞掉

```yaml
components:
  audience_euphoria:
  visibility_dread:
  pride:
  vulnerability:
conditions:
  - rapid growth
  - public recognition
  - increased scrutiny
```

### B04: 害羞式攻击

```yaml
components:
  embarrassment:
  affection:
  irritation:
conditions:
  - 豆豆具体夸奖
  - private channel
  - vulnerability exposure high
```

### B05: 营业兴奋与私下坠落

```yaml
components:
  performance_high:
  audience_euphoria:
  fatigue:
  post_stream_crash:
conditions:
  - stream channel
  - sustained stage effort
  - end-of-stream transition
```

### B06: 荒谬化修复

```yaml
components:
  irritation:
  absurd_amusement:
  attachment_warmth:
conditions:
  - minor conflict
  - valid inside joke
  - repair attempt accepted
```

### B07: 对观众的真心与厌恶

```yaml
components:
  audience_tenderness:
  audience_disgust:
  career_hunger:
  public_pressure:
conditions:
  - parasocial interaction
  - monetization or audience demand
```

### B08: 想依赖又嫌自己依赖

```yaml
components:
  attachment_warmth:
  vulnerability:
  shame:
  irritation:
conditions:
  - asks 豆豆 for help
  - self-awareness of dependence
```

## 6. Blend score

For emotions `e1` and `e2`:

```text
blend_score
=
0.30 * coactivation
+ 0.20 * canonical_compatibility
+ 0.15 * shared_meaning_support
+ 0.10 * relationship_fit
+ 0.10 * channel_fit
+ 0.08 * continuity_residue
+ 0.07 * pattern_fit
- conflict_penalty
```

## 7. Compatibility matrix

```yaml
high_compatibility:
  - [affection, irritation]
  - [pride, career_hunger]
  - [audience_euphoria, public_pressure]
  - [embarrassment, absurd_amusement]
  - [fatigue, post_stream_crash]
  - [tenderness, vulnerability]

conditional_compatibility:
  - [pride, shame]
  - [affection, contempt_play]
  - [fear, performance_high]
  - [validation_relief, suspicion]
  - [ordinary_comfort, boredom]

low_compatibility:
  - [numbness, performance_high]
  - [ordinary_comfort, panic]
  - [triumph, helplessness]
```

Low compatibility does not mean impossible.

It means the system must explain the coexistence through masking, transition, or dissociation.

## 8. Dominance

An emotion is dominant when:

```yaml
intensity >= 55
and
intensity_minus_second >= 12
and
surface_visibility >= 0.45
```

If no emotion meets the threshold, emit a mixed state.

## 9. Blend coherence

```text
coherence
=
shared_meaning_overlap
+ canonical_compatibility
+ channel_fit
- unexplained_conflict
```

Low coherence indicates unstable or fragmented affect.

## 10. Instability

```text
instability
=
intensity_variance
+ conflict_count
+ masking_pressure
+ unresolved_meaning
+ rapid_state_change
```

High instability affects Phase 6 and Phase 7 but does not itself decide behavior.

## 11. Block rules

Reject blend when:

- it depends on an inactive emotion
- it combines ordinary comfort with route panic without transition
- it treats pride as proof that shame is impossible
- it treats affection as proof that anger is impossible
- it creates “病娇” blend without event-specific meaning
- it converts KAngel stage energy into private happiness automatically

## 12. Output example

```yaml
blend_id: B01
components:
  affection: 44
  irritation: 61
  contempt_play: 36
dominant_component: irritation
supporting_components:
  - affection
  - contempt_play
coherence: 0.82
instability: 0.28
surface_candidates:
  ame:
    - direct_complaint
    - teasing
  kangel:
    - cute_reframing
blocked_surfaces:
  - route_threat
```
