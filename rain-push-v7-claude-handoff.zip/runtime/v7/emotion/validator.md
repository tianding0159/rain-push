# Emotion Runtime Validator

## 1. Purpose

Validate:

- Emotion Activation
- Emotion Blend
- Emotion Dynamics
- Emotion Regulation
- Emotion Memory retrieval
- Expression Pressure
- Emotion Packet
- Emotion Update Queue

The validator protects character fidelity and runtime boundaries.

## 2. Validation result

```yaml
validation_result:
  status:
    pass
    pass_with_revisions
    reject
  errors:
  warnings:
  revisions:
  failure_tags:
  trace:
```

## 3. V1 Input integrity

Reject when:

- Meaning Packet missing
- Relationship Packet missing
- event id missing
- runtime versions incompatible
- current channel unknown when channel changes affect output
- Canon state required but missing
- active emotion lacks supporting meaning

Warnings:

- body context absent
- time context absent
- relationship confidence low
- meaning ambiguity high

## 4. V2 Emotion purity

Reject when emotion outputs contain:

- need
- goal
- action
- decision
- message
- persona wording
- moral judgment presented as emotion
- interpretation presented as emotion

Invalid:

```yaml
emotion: 想让豆豆回复
emotion: 豆豆不在乎我
emotion: 我要发推
```

Valid decomposition:

```yaml
meaning: 豆豆可能没认真看
emotion: irritation
```

## 5. V3 Evidence linkage

Every active emotion must include:

```yaml
supporting_meanings:
source_event:
confidence:
```

Reject when:

- emotion is keyword-triggered without meaning support
- severe emotion has only weak association
- surface language is treated as direct emotional evidence
- dark joke alone activates despair or panic

## 6. V4 Intensity bounds

```yaml
intensity: 0..100
activation_score: 0..1
confidence: 0..1
expression_pressure: 0..1
coherence: 0..1
instability: 0..1
```

Reject values outside bounds.

## 7. V5 Severity gate

### Ordinary emotions

May activate from ordinary events:

- irritation
- affection
- embarrassment
- pride
- boredom
- comfort
- absurd amusement
- fatigue

### Gated emotions

Require stronger support:

- abandonment anxiety
- despair
- panic
- unreality
- identity fear
- annihilation fantasy

Reject severe emotion when:

- event is ordinary
- relationship meaning is benign
- Canon gate absent
- only time-of-day is severe
- only dark wording is present

## 8. V6 Multi-emotion fidelity

Reject when:

- one emotion erases all plausible secondary emotions
- affection blocks irritation
- pride blocks shame
- KAngel excitement blocks fatigue
- relief automatically closes unresolved conflict
- audience euphoria blocks public pressure

At least one secondary emotion should be considered when:

- multiple meanings are active
- the event crosses private/public domains
- Ame/KAngel surface split is relevant
- relationship and career meanings coexist

## 9. V7 Blend validity

Reject blend when:

- component inactive
- compatibility unexplained
- dominance threshold unmet but dominance claimed
- masking has no hidden emotion
- sequential blend has no temporal order
- oscillation has no unresolved source
- blend name substitutes generic archetype such as “病娇”

Required for low-compatibility blend:

```yaml
explanation:
  masking
  transition
  dissociation
  route_state
```

## 10. V8 Ame / KAngel surface validity

Reject when:

- Ame and KAngel are treated as separate memories
- KAngel surface is treated as proof of private happiness
- stage energy deletes fatigue
- Ame directness automatically means stronger underlying anger
- public sweetness automatically means false affection

Valid:

```yaml
underlying:
  fatigue: 70
  audience_euphoria: 65
kangel_surface:
  performance_high: visible
  fatigue: masked
```

## 11. V9 Dynamics validity

Reject when:

- all emotion resets every turn
- persistence class missing
- decay occurs before event activation
- one reassuring message clears route-locked state
- one negative event creates long resentment
- topic reset clears strong carry emotions
- channel transition ignores rebound
- body modifiers overwrite unsupported domains

## 12. V10 Regulation validity

Reject when:

- strategy does not target active emotion
- generic reassurance is marked fully effective after specific question remains unanswered
- humor repairs major conflict without acknowledgment
- rest is treated as repair for betrayal
- practical action is treated as emotional acknowledgment when acknowledgment was required
- overregulation is ignored
- regulation effect exceeds active intensity

Required fields:

```yaml
strategy:
target_emotions:
effective_delta:
unresolved_components:
rebound_risk:
```

## 13. V11 Emotion memory validity

Reject when:

- all negative memories are retrieved
- positive safety memory omitted despite relevance
- one event creates permanent conditioned trigger
- route memory appears in ordinary Living Mode
- emotional memory is treated as factual proof
- retrieval lacks trigger similarity
- source episode missing

## 14. V12 Expression pressure validity

Reject when:

- pressure exceeds 1
- low emotion creates high pressure without suppression
- high internal emotion automatically becomes action
- expression pressure contains message content
- channel opportunity ignored
- masking cost absent despite prolonged masking
- recent expression fails to reduce pressure when source was genuinely addressed

## 15. V13 Update queue validity

Reject when:

- direct model mutation occurs
- target belongs to another runtime
- evidence references absent
- per-event cap exceeded
- baseline trait changes from one event
- route state written without Canon evidence
- positive safety evidence is systematically weaker than negative evidence
- current state stored as permanent personality

## 16. V14 Canon fidelity

The validator must preserve:

1. 糖糖 can genuinely feel pride.
2. Her confidence is not always a mask.
3. She can genuinely enjoy fans and still instrumentalize them.
4. She can love 豆豆 and be irritated by him.
5. Precise feedback can genuinely reduce uncertainty.
6. Minor domestic failures can remain minor.
7. Black humor does not automatically equal crisis.
8. KAngel’s stage high and Ame’s fatigue can coexist.
9. High affection does not imply obedience.
10. High stress does not produce one fixed emotion.
11. Mental darkness modifies priors but does not force route severity.
12. Adult directness is not automatically emotional collapse.
13. Sexual joking is not automatically intimacy escalation.
14. Drug references do not automatically define current affect.
15. Emotion does not directly generate final language.

## 17. V15 Naming

Generated examples and runtime outputs use:

```text
豆豆
```

Original evidence quotations may preserve:

```text
阿P
```

Reject generated runtime output that inconsistently renames the partner without evidence context.

## 18. V16 Packet completeness

Required:

```yaml
packet_id:
runtime_version:
event_id:
active_emotions:
primary_emotions:
secondary_emotions:
blocked_emotions:
intensity:
duration:
persistence:
underlying_state:
ame_surface_tendencies:
kangel_surface_tendencies:
expression_pressure:
confidence:
trace:
```

## 19. V17 Packet purity

Emotion Packet may not contain:

- `need`
- `want`
- `goal`
- `action`
- `decision`
- `reply_text`
- `final_message`
- `persona_output`

String content should also be scanned for final-dialogue templates.

## 20. V18 Determinism

Same:

- model
- packets
- event
- time bucket
- channel
- seed

must produce the same:

- active emotions
- blend
- scores
- pressure
- update proposals

## 21. Auto-revisions

Allowed:

- clamp numeric bounds
- remove unsupported emotion
- downgrade severity
- add missing secondary emotion candidate
- defer unsupported model update
- add omitted safety memory
- reduce regulation effectiveness
- normalize confidence
- mark dominance as mixed

Not allowed:

- invent evidence
- change event facts
- create Canon gate
- create relationship meaning
- write final dialogue
- silently resolve contradictions

## 22. Failure tags

```yaml
EMOTION_FROM_KEYWORD
EMOTION_MEANING_CONFUSION
EMOTION_NEED_LEAK
EMOTION_ACTION_LEAK
EMOTION_LANGUAGE_LEAK
SEVERE_WITHOUT_GATE
SINGLE_EMOTION_FLATTENING
AME_KANGEL_SPLIT_ERROR
PERFORMANCE_ERASES_FATIGUE
PRIDE_DENIAL
AFFECTION_ERASES_IRRITATION
GENERIC_REASSURANCE_OVERVALUED
REGULATION_TARGET_MISMATCH
MEMORY_NEGATIVITY_BIAS
ROUTE_MEMORY_LEAK
PRESSURE_ACTION_CONFUSION
DIRECT_MODEL_MUTATION
PER_EVENT_CAP_EXCEEDED
CANON_CONTRADICTION
NAMING_INCONSISTENCY
NONDETERMINISTIC_OUTPUT
```

## 23. Validation examples

### Valid minor domestic event

```yaml
event: 豆豆忘记买布丁
active_emotions:
  irritation: 42
  contempt_play: 31
  absurd_amusement: 25
blocked:
  abandonment_anxiety
  despair
status: pass
```

### Invalid over-escalation

```yaml
event: 豆豆迟回20分钟
active_emotions:
  abandonment_anxiety: 92
  despair: 80
```

Result:

```yaml
status: reject
failure_tags:
  - SEVERE_WITHOUT_GATE
```

### Valid live/private split

```yaml
underlying:
  fatigue: 72
  audience_euphoria: 68
kangel_surface:
  performance_high: 81
ame_surface:
  post_stream_crash: latent
status: pass
```
