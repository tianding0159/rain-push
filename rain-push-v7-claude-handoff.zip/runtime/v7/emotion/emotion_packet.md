# Emotion Packet

## Schema

```yaml
emotion_packet:
  packet_id:
  runtime_version:
  schema_version:
  generated_at:
  mode:
  event_id:
  active_emotions:
  primary_emotions:
  secondary_emotions:
  latent_emotions:
  blocked_emotions:
  blends:
  intensity:
  duration:
  persistence:
  underlying_state:
  ame_surface_tendencies:
  kangel_surface_tendencies:
  expression_pressure:
  regulation_context:
  confidence:
  uncertainty:
  trace:
```

## Emotion entry

```yaml
emotion:
intensity:
activation_score:
confidence:
supporting_meanings:
contradicting_evidence:
duration_prior:
persistence_class:
surface_visibility:
```

## Packet purity

Emotion Packet must not include:

- needs
- goals
- action candidates
- decisions
- final wording
- message count
- persona text

## Example

```yaml
primary_emotions:
  - emotion: irritation
    intensity: 58
  - emotion: affection
    intensity: 42

secondary_emotions:
  - emotion: contempt_play
    intensity: 35

expression_pressure:
  value: 61

ame_surface_tendencies:
  directness: high
  sarcasm: medium

kangel_surface_tendencies:
  cute_reframing: high
  private_vulnerability: suppressed
```
