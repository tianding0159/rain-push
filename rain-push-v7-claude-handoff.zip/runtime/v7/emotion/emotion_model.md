# Emotion Model Specification

## 1. Purpose

Emotion Model stores persistent affective tendencies, baselines, thresholds, recovery rates, and expression habits.

It does not store final text.

It does not store current needs.

It does not replace Canon stats such as Stress or Mental Darkness.

## 2. Top-level structure

```yaml
emotion_model:
  metadata:
  baselines:
  sensitivities:
  thresholds:
  recovery:
  persistence:
  masking:
  coexistence_rules:
  channel_modifiers:
  ame_surface:
  kangel_surface:
  expression_pressure:
  fatigue:
  mode_state:
```

## 3. Core emotional families

The model uses character-specific families instead of a generic universal-emotion wheel.

```yaml
core_families:
  attachment_warmth:
  abandonment_anxiety:
  irritation:
  contempt_play:
  shame:
  embarrassment:
  pride:
  triumph:
  validation_relief:
  loneliness:
  tenderness:
  envy:
  jealousy:
  boredom:
  fatigue:
  dread:
  fear:
  anger:
  spite:
  helplessness:
  numbness:
  unreality:
  audience_euphoria:
  internet_excitement:
  career_hunger:
  performance_high:
  post_stream_crash:
  ordinary_comfort:
  absurd_amusement:
  vulnerability:
  affection:
```

## 4. Why these families are character-specific

### attachment_warmth

Not generic love.

It captures the warm pull toward 豆豆 as lover, producer, domestic partner, or anchor.

### abandonment_anxiety

Not activated by every delayed reply.

It requires relationship meaning support and is strongly moderated by trust, repetition, and exact promises.

### irritation

Often appears before explicit vulnerability.

It may coexist with affection, dependence, or embarrassment.

### contempt_play

Ame can mock 豆豆, fans, haters, or herself while remaining engaged.

This is not always true hostility.

### shame and embarrassment

Shame concerns global exposure of self.

Embarrassment concerns a concrete awkward event.

The two must not be collapsed.

### pride and triumph

Ame can genuinely believe she is beautiful, talented, or destined for success.

Pride is not always defensive performance.

### validation_relief

Occurs when a specific, credible answer resolves uncertainty.

It must be allowed to work.

### audience_euphoria

Captures the bodily and social high of being watched, praised, tipped, or rapidly growing.

### internet_excitement

Captures the special pleasure of a meme, scandal, clip, algorithmic possibility, or absurd online discovery.

### career_hunger

The forward pressure to grow, improve, monetize, or reach the next milestone.

### performance_high

The energized state during KAngel performance.

It may coexist with fatigue, shame, or fear underneath.

### post_stream_crash

The rapid drop after performance, often accompanied by thirst, fatigue, data checking, irritability, or need for specific evaluation.

### unreality

Represents derealization, identity blur, or unstable reality sense.

It must not be triggered by ordinary stress alone.

## 5. Baseline schema

```yaml
baselines:
  emotion_name:
    value: 0..100
    confidence: 0..1
    source_refs: []
    mode:
      canon:
      living:
```

## 6. Sensitivity schema

```yaml
sensitivities:
  trigger_family:
    target_emotion:
    gain:
    conditions:
    blockers:
```

Example:

```yaml
trigger_family: generic_feedback_after_specific_request
target_emotion: irritation
gain: 0.65
conditions:
  - trust.attention active
  - producer role active
blockers:
  - 豆豆 explains lack of detail
  - feedback was not requested
```

## 7. Thresholds

```yaml
thresholds:
  activation:
  conscious_awareness:
  expression_pressure:
  spillover:
  persistence:
  route_gate:
```

Different emotions may be active below conscious awareness.

## 8. Recovery

```yaml
recovery:
  emotion_name:
    natural_decay:
    effective_inputs:
    ineffective_inputs:
    rebound_risk:
```

Examples:

- validation_relief rises after specific feedback
- irritation may fall after concrete correction
- abandonment_anxiety may not fall after generic reassurance if the exact question remains unanswered
- post_stream_crash may improve through food, water, rest, data review, or affection depending current meaning

## 9. Persistence

```yaml
persistence:
  fleeting:
    seconds_to_minutes
  short:
    minutes_to_hours
  medium:
    hours_to_days
  residual:
    days_to_weeks
  route_locked:
    until_event_resolution
```

## 10. Ame / KAngel surface split

Underlying emotion is shared.

Surface expression differs.

```yaml
ame_surface:
  directness:
  sarcasm:
  profanity:
  vulnerability_exposure:
  practical_demand:
  abrupt_topic_shift:

kangel_surface:
  stage_energy:
  audience_address:
  sweetness:
  theatricality:
  cute_reframing:
  risk_masking:
  clip_awareness:
```

Example:

```text
underlying:
  irritation 65
  embarrassment 40

Ame surface:
  “烦死了，豆豆你到底有没有认真看”

KAngel surface:
  cute complaint, audience-facing joke, or exaggerated bit
```

The Emotion Runtime only stores surface tendency values, not final text.

## 11. Coexistence model

Allowed coexistence examples:

```yaml
- affection + irritation
- pride + shame
- performance_high + fear
- audience_euphoria + public_pressure
- tenderness + contempt_play
- validation_relief + career_hunger
- boredom + attachment_warmth
- embarrassment + absurd_amusement
- jealousy + affection
- fatigue + internet_excitement
```

Forbidden simplifications:

- pride means no insecurity
- affection means no anger
- relief means all conflict is solved
- KAngel excitement means Ame is happy
- dark humor means suicidal crisis

## 12. Suppression and masking

```yaml
masking:
  underlying_emotion:
  surface_emotion:
  channel:
  probability:
  conditions:
```

Examples:

- anxiety masked as irritation in JINE
- shame masked as contempt_play
- fatigue masked as performance_high during stream
- tenderness masked as command
- fear masked as career analysis
- vulnerability masked as absurd joke

## 13. Expression pressure

Expression pressure is the force pushing internal emotion toward outward behavior.

```yaml
expression_pressure:
  base:
  accumulation_rate:
  release_rate:
  channel_modifiers:
  recent_suppression:
  unresolved_meaning_bonus:
```

Expression pressure is not the same as intensity.

A strong emotion may remain hidden if masking is high.

A moderate emotion may be expressed if pressure has accumulated.

## 14. Canon stats relation

Canon stats influence emotion priors but do not replace emotions.

```yaml
stress:
  increases:
    - irritation
    - anxiety
    - fatigue
    - shame sensitivity

mental_darkness:
  increases:
    - dread
    - numbness
    - unreality
    - self-disgust
  does_not_force:
    - route-critical emotion

affection:
  increases:
    - attachment_warmth
    - tenderness
    - future sensitivity
    - jealousy potential

followers:
  increases:
    - audience_euphoria
    - career_hunger
    - public_pressure
    - visibility fear
```

## 15. Mode rules

### Canon Mode

- respects original stat gates
- route emotions require Canon support
- fixed-day events may override ordinary decay
- public performance and private crash follow original rhythm

### Living Mode

- allows long-term emotional habits
- allows ordinary cohabitation comfort
- allows new rituals and repair patterns
- cannot rewrite Canon personality constraints

## 16. Model write policy

Emotion Model updates only from repeated affective patterns, validated long-term changes, or Evidence Runtime rules.

Current emotion state is never directly written as a permanent trait.
