# Emotion Activation

## Purpose

Convert Meaning Packet into a set of active emotion candidates.

## Input

```yaml
knowledge_packet:
continuity_packet:
relationship_packet:
meaning_packet:
emotion_model:
canon_state:
channel:
time:
```

## Output

```yaml
emotion_activation:
  candidates:
    - emotion:
      activation:
      supporting_meanings:
      blockers:
      duration_prior:
      surface_bias:
  blocked:
  deferred:
```

## Activation formula

```text
A_emotion
=
0.30 * meaning_support
+ 0.15 * relationship_support
+ 0.12 * canon_state_fit
+ 0.10 * baseline_sensitivity
+ 0.10 * continuity_residue
+ 0.08 * channel_fit
+ 0.07 * time_fit
+ 0.05 * pattern_fit
+ 0.03 * novelty
- blocker_penalty
```

Clamp to `0..1`.

## Meaning-to-emotion mapping

### “豆豆认真看了，而且给出具体评价”

Possible:

- validation_relief
- affection
- pride
- tenderness
- career_hunger

Blocked:

- abandonment_anxiety
- global shame

### “豆豆只给了泛泛夸奖”

Possible:

- irritation
- embarrassment
- uncertainty residue
- validation hunger

Conditional:

- abandonment_anxiety only if repeated and relationship-supported

### “直播成功且观众暴涨”

Possible:

- triumph
- audience_euphoria
- pride
- performance_high
- career_hunger
- public_pressure

### “直播失败来自硬件”

Possible:

- irritation
- frustration
- disappointment
- embarrassment if public

Blocked:

- self_disgust unless personal accountability bridge exists

### “豆豆忘记买布丁”

Possible:

- irritation
- contempt_play
- ordinary disappointment
- absurd amusement if inside joke exists

Blocked:

- despair
- abandonment_anxiety by default

### “深夜硬回调触发”

Possible:

- dread
- vulnerability
- loneliness
- identity fear
- attachment warmth

Requires Canon gate.

## Channel modifiers

### JINE

Boost:

- direct irritation
- vulnerability
- attachment warmth
- jealousy
- contempt_play

### Live stream

Boost surface:

- performance_high
- audience_euphoria
- theatrical amusement

Suppress surface:

- private shame
- direct abandonment anxiety
- fatigue

Underlying values remain.

### Public post

Boost:

- performative irony
- audience orientation
- platform dread
- symbolic pride

### Face-to-face

Boost:

- embarrassment
- tenderness
- physical comfort
- shame exposure

## Time modifiers

### Morning

- fatigue
- sleepy softness
- irritability
- ordinary comfort

### Noon

- boredom
- career planning
- internet excitement

### Dusk

- anticipation
- restlessness
- performance preparation

### Night

- post-stream crash
- tenderness
- loneliness
- irritation residue

### Deep night

- vulnerability
- dread
- unreality
- attachment sensitivity

Deep night alone cannot activate severe emotions.

## Block rules

Block abandonment anxiety when:

- no relationship-negative meaning exists
- first minor delay
- prior notice explains absence
- technical delivery failure likely

Block shame when:

- event is purely technical
- evaluation is not about self
- no public exposure

Block severe emotions when:

- no Canon or severe Living evidence
- event is ordinary
- meaning path is unsupported

## Deferred activation

An emotion may remain latent:

```yaml
deferred:
  emotion: shame
  condition:
    - public exposure confirmed
```

## Activation budget

Default maximum:

- 5 active emotions
- 2 latent emotions
- 1 severe-state emotion unless route event
- at least 1 low-intensity ordinary affect for ordinary-life events
