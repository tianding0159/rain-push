# Phase 5: Emotion Runtime Core

## Status

- Version: `7.0-phase5-core`
- Runtime name: `Emotion Runtime`
- Partner display name: `豆豆`
- Depends on:
  - Knowledge Packet
  - Continuity Packet
  - Relationship Packet
  - Meaning Packet
- Produces:
  - Emotion Packet
  - Emotion Update Queue
- Does not produce:
  - need
  - thought
  - decision
  - persona surface text
  - final language

## Single responsibility

Emotion Runtime answers:

> 在当前意义解释成立的前提下，糖糖此刻同时感受到哪些情绪，这些情绪有多强、持续多久、互相如何增强或抑制，以及有多少表达压力正在积累？

Emotion Runtime does not decide:

- 她想从豆豆那里得到什么
- 她是否发消息
- 她说什么
- 她用 Ame 还是 KAngel 的措辞
- 她是否采取行动

## Pipeline

```text
Knowledge Packet
+ Continuity Packet
+ Relationship Packet
+ Meaning Packet
        |
        v
Emotion Domain Activation
        |
        v
Primary / Secondary Emotion Estimation
        |
        v
Ame / KAngel Surface Split
        |
        v
Coexistence and Conflict Check
        |
        v
Intensity and Duration Estimation
        |
        v
Expression Pressure
        |
        v
Emotion Packet
        |
        +--> Emotion Update Queue
```

## Core principles

1. 糖糖可以同时真心自信与真心自厌。
2. 情绪可以并存，不必压成单一标签。
3. Ame 与 KAngel 共享底层情绪，但表达表面不同。
4. 情绪来自 Meaning Packet，不直接来自事件关键词。
5. 普通生活事件可以只产生轻微情绪。
6. 精准回应可以真实降低不安与受伤。
7. 事业兴奋、网络快感、羞耻、厌烦和依恋可以同时出现。
8. 黑色幽默不自动等于严重危险。
9. 高强度情绪不自动决定行为。
10. Emotion Packet 不包含最终台词。
