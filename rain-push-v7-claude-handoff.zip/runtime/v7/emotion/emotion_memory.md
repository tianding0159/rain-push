# Emotion Memory

## 1. Purpose

Emotion Memory stores affective residue and learned emotional associations.

It does not duplicate Episodic Memory.

It records how past events bias current activation.

## 2. Memory types

```yaml
residue:
conditioned_trigger:
repair_memory:
safety_memory:
performance_memory:
audience_memory:
body_memory:
route_memory:
```

## 3. Residue

```yaml
residue:
  id:
  source_episode:
  emotion:
  remaining_intensity:
  decay_class:
  reactivation_triggers:
  last_reactivated:
```

Example:

- irritation residue after unresolved generic feedback
- tenderness residue after specific care
- post-stream crash residue after exhausting broadcast

## 4. Conditioned trigger

```yaml
conditioned_trigger:
  trigger_pattern:
  target_emotion:
  gain:
  evidence_count:
  confidence:
  extinction_conditions:
```

Examples:

- exact promises missed repeatedly → anxiety/irritation
- stream setup reliably completed → relief
- public praise followed by harassment → audience euphoria mixed with dread

## 5. Repair memory

Stores evidence that repair can work.

```yaml
repair_memory:
  source_conflict:
  successful_strategy:
  emotions_reduced:
  trust_context:
  durability:
```

This prevents the system from treating every future conflict as hopeless.

## 6. Safety memory

Examples:

- 豆豆 returned after delay
- 豆豆 remembered a specific detail
- 豆豆 protected privacy
- 豆豆 gave accurate stream feedback

Safety memory lowers catastrophic interpretation probability.

## 7. Performance memory

Stores:

- stage high
- crash severity
- audience response
- recovery method
- fatigue cost

It supports realistic pre-stream anticipation and post-stream residue.

## 8. Audience memory

Stores:

- milestone euphoria
- hate exposure
- doxxing risk
- parasocial warmth
- public pressure

Audience memories are not equivalent to relationship memories.

## 9. Body memory

Examples:

- sleep debt worsened irritability
- hunger intensified conflict
- rest improved crash
- illness increased practical dependence

## 10. Route memory

Route-level emotional memory is locked by Canon conditions.

It cannot be generalized into ordinary Living Mode without explicit design rule.

## 11. Retrieval

```text
emotion_memory_score
=
0.30 * trigger_similarity
+ 0.20 * unresolved_weight
+ 0.15 * recency
+ 0.15 * emotional_intensity
+ 0.10 * relationship_relevance
+ 0.10 * canon_priority
```

## 12. Memory write policy

Write emotional memory when:

- peak intensity exceeds threshold
- event repeats
- repair succeeds or fails significantly
- a milestone occurs
- a Canon callback requires persistence

Do not write:

- every small mood
- every joke
- every ordinary irritation
- unsupported inferred emotion

## 13. Memory reconsolidation

When reactivated, memory may change.

Examples:

- a late-reply trigger becomes less severe after repeated reliable returns
- a stream-failure trigger becomes more severe after repeated public humiliation
- a shared joke may convert old embarrassment into amusement

## 14. Extinction

A conditioned emotional response weakens when:

- trigger repeats without feared outcome
- repair is reliable
- contradictory evidence accumulates
- meaning changes

## 15. Failure cases

Reject when:

- all old negative memories are always retrieved
- positive safety memory is ignored
- route memory contaminates ordinary life
- one event creates a permanent conditioned response
- emotional memory is treated as factual proof
