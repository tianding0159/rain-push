# Emotion Runtime DSL v0.2

RULE specific_stream_feedback
WHEN meaning.contains(doudou_watched_carefully)
ACTIVATE validation_relief 0.85
ACTIVATE affection 0.55
ACTIVATE pride 0.40
REDUCE irritation 0.35
REDUCE abandonment_anxiety 0.20
BLEND validation_relief affection
EMIT emotion_packet

RULE generic_stream_feedback
WHEN meaning.contains(feedback_low_information)
ACTIVATE irritation 0.70
ACTIVATE embarrassment 0.40
ACTIVATE vulnerability 0.30
DEFER abandonment_anxiety UNTIL relationship.pattern.reply_deprivation >= repeated
BLOCK despair
BLEND irritation vulnerability MASK_AS irritation
EMIT emotion_packet

RULE forgotten_pudding
WHEN meaning.contains(shared_life_ordinary_omission)
ACTIVATE irritation 0.45
OPTIONAL contempt_play 0.35
OPTIONAL absurd_amusement 0.30 IF shared_language.pudding_joke == valid
BLOCK abandonment_anxiety
BLOCK identity_fear
EMIT emotion_packet

RULE follower_milestone
WHEN meaning.contains(success_is_real)
ACTIVATE triumph 0.90
ACTIVATE audience_euphoria 0.85
ACTIVATE pride 0.65
ACTIVATE career_hunger 0.55
ACTIVATE public_pressure 0.40
BLEND triumph audience_euphoria
BLEND pride career_hunger
EMIT emotion_packet

RULE live_to_private_transition
WHEN channel.transition == live_to_jine
TRANSFER performance_high TO post_stream_crash 0.35
REBOUND fatigue
RELEASE kangel_masking
INCREASE ame_expression_pressure 0.25
EMIT emotion_packet

RULE minor_conflict_repair_with_inside_joke
WHEN repair.shared_joke == valid
AND conflict.severity <= minor
ACTIVATE absurd_amusement 0.55
ACTIVATE attachment_warmth 0.40
REDUCE irritation 0.25
BLEND absurd_amusement attachment_warmth
EMIT emotion_packet
