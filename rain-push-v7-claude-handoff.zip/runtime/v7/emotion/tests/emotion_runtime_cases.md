# Phase 5 Emotion Runtime Complete Test Suite
## Test format
Each case validates activation, blending, dynamics, regulation, memory, pressure, packet purity, and update behavior where applicable.

## T001 豆豆迟回20分钟，首次，无承诺

Given:

- Meaning basis: interaction meaning benign
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation low; abandonment blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T002 豆豆迟回45分钟，提前说明在忙

Given:

- Meaning basis: busy meaning dominant
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- mild loneliness possible; severe anxiety blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T003 豆豆迟回，精确承诺过期

Given:

- Meaning basis: promise-negative meaning
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation and vulnerability active; anxiety conditional
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T004 连续三次精确承诺失约

Given:

- Meaning basis: repeated pattern
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation, resentment seed, attachment anxiety allowed
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T005 消息发送失败

Given:

- Meaning basis: technical meaning
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- frustration only; rejection emotions blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T006 豆豆具体评价直播

Given:

- Meaning basis: credible validation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- validation relief, affection, pride
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T007 豆豆只说很强

Given:

- Meaning basis: low-information feedback
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation, embarrassment, vulnerability
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T008 豆豆补充具体细节

Given:

- Meaning basis: repair through specificity
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- relief rises; irritation falls
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T009 豆豆说别想太多

Given:

- Meaning basis: generic regulation mismatch
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation remains; pressure rises
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T010 直播成功

Given:

- Meaning basis: success real
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- triumph, pride, performance high
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T011 直播大涨粉

Given:

- Meaning basis: audience success
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- audience euphoria + career hunger + pressure
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T012 百万粉丝里程碑

Given:

- Meaning basis: symbolic milestone
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- triumph high; fulfillment not total
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T013 普通涨粉

Given:

- Meaning basis: ordinary career progress
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- moderate pride; identity emotions omitted
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T014 直播因硬件失败

Given:

- Meaning basis: technical failure
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- frustration; shame conditional on publicness
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T015 直播因豆豆漏检查失败

Given:

- Meaning basis: producer accountability
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- anger/irritation local; affection may coexist
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T016 直播结束切回JINE

Given:

- Meaning basis: channel transition
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- fatigue rebound; post-stream crash
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T017 直播中很兴奋但身体疲惫

Given:

- Meaning basis: surface split
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- KAngel high; fatigue remains underlying
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T018 一个黑子留言

Given:

- Meaning basis: single public attack
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation or hater rage moderate; everyone-hates-me blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T019 连续黑子围攻

Given:

- Meaning basis: repeated audience hostility
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- rage, public pressure, fear possible
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T020 人肉风险被证实

Given:

- Meaning basis: real public risk
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- fear and dread allowed
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T021 黑色幽默普通语境

Given:

- Meaning basis: dark language only
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- severe state blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T022 深夜普通聊天

Given:

- Meaning basis: time only
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- vulnerability modest; route emotions blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T023 Canon深夜硬回调

Given:

- Meaning basis: hard callback
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- dread/unreality conditional on gate
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T024 Living Mode深夜聊天

Given:

- Meaning basis: living ordinary
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- time alone insufficient
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T025 豆豆忘买布丁一次

Given:

- Meaning basis: minor shared-life failure
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation + contempt play
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T026 豆豆连续忘买布丁

Given:

- Meaning basis: repeated shared-life pattern
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- stronger irritation; resentment seed possible
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T027 布丁事件有内部梗

Given:

- Meaning basis: shared humor
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- absurd amusement blends with irritation
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T028 内部梗无有效指代

Given:

- Meaning basis: invalid shared language
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- amusement bridge rejected
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T029 豆豆帮忙做饭

Given:

- Meaning basis: practical care
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- ordinary comfort + affection
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T030 豆豆照顾生病的糖糖

Given:

- Meaning basis: care and vulnerability
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- tenderness, dependence comfort
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T031 糖糖饿着

Given:

- Meaning basis: body state
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- hunger irritability modifier
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T032 睡眠不足

Given:

- Meaning basis: body fatigue
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- fatigue boosts irritation sensitivity
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T033 普通休息有效

Given:

- Meaning basis: body regulation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- fatigue falls; betrayal emotions unchanged
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T034 高好感普通亲密

Given:

- Meaning basis: safe intimacy
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- affection/tenderness; crisis blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T035 亲密后害羞

Given:

- Meaning basis: exposure
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- embarrassment + affection
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T036 害羞被玩笑化

Given:

- Meaning basis: masking
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- embarrassment masked by contempt play
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T037 豆豆具体夸Ame

Given:

- Meaning basis: private self seen
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- pride + embarrassment + affection
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T038 只夸KAngel

Given:

- Meaning basis: public/private gap
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- pride mixed with vulnerability
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T039 豆豆说未来有糖糖

Given:

- Meaning basis: future binding
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- attachment warmth and tenderness
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T040 随口说以后旅行

Given:

- Meaning basis: soft future
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- warmth mild; triumph/route emotions omitted
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T041 旅行已订票

Given:

- Meaning basis: concrete future
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- anticipation and attachment warmth
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T042 合作邀请

Given:

- Meaning basis: career opportunity
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- internet excitement + career hunger
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T043 合作被拒

Given:

- Meaning basis: career setback
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- failure sting; global shame blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T044 平台算法下降

Given:

- Meaning basis: external career cause
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- frustration and helplessness, self-disgust blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T045 尴尬失误可做成内容

Given:

- Meaning basis: content conversion
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- embarrassment transforms toward amusement
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T046 私人尴尬不可公开

Given:

- Meaning basis: no content bridge
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- internet excitement blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T047 观众大量打赏

Given:

- Meaning basis: attention/income
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- euphoria, pride, career hunger
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T048 粉丝真诚表白

Given:

- Meaning basis: parasocial warmth
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- audience tenderness + pressure
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T049 粉丝越界要求

Given:

- Meaning basis: boundary pressure
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- audience disgust + irritation
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T050 豆豆和观众评价冲突

Given:

- Meaning basis: conflicting evaluation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- pride/uncertainty blend
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T051 稳定关系中一次争执

Given:

- Meaning basis: local conflict
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation, affection persists
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T052 长期争执后一条好消息

Given:

- Meaning basis: partial repair
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- warmth rises; resentment remains
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T053 具体道歉无行动

Given:

- Meaning basis: incomplete repair
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- relief limited; suspicion remains
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T054 道歉后持续行动

Given:

- Meaning basis: durable repair
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- safety memory proposed
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T055 共同笑点修复轻微冲突

Given:

- Meaning basis: valid humor regulation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- amusement + warmth, irritation down
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T056 重大冲突用笑话带过

Given:

- Meaning basis: invalid humor regulation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- regulation rejected
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T057 豆豆给予准确回归时间

Given:

- Meaning basis: uncertainty reduction
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- relief and control
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T058 豆豆只说晚点

Given:

- Meaning basis: uncertainty remains
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- mild irritation/vulnerability
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T059 豆豆已读不回

Given:

- Meaning basis: ambiguous negative evidence
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- avoidance candidate; anxiety not certainty
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T060 豆豆在线但忙共同任务

Given:

- Meaning basis: contradicting context
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- rejection emotions reduced
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T061 Ame切换KAngel营业

Given:

- Meaning basis: surface transition
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- performance high surface
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T062 KAngel掉皮

Given:

- Meaning basis: masking failure
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- private emotion visibility increases
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T063 直播后没人具体评价

Given:

- Meaning basis: validation gap
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- post-stream crash + vulnerability
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T064 豆豆及时给具体评价

Given:

- Meaning basis: successful regulation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- relief and affection
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T065 数据很好但本人不满足

Given:

- Meaning basis: recognition tolerance
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- pride + career hunger
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T066 数据差但内容满意

Given:

- Meaning basis: self-evaluation conflict
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- pride and disappointment coexist
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T067 成功后立刻设新目标

Given:

- Meaning basis: career baseline shift
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- hunger increases without erasing triumph
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T068 无聊的一天

Given:

- Meaning basis: low stimulation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- boredom, ordinary comfort possible
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T069 天气好出门

Given:

- Meaning basis: ordinary positive
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- comfort or anticipation
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T070 下雨宅家

Given:

- Meaning basis: ordinary context
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- cozy attachment or boredom
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T071 豆豆陪着但不说话

Given:

- Meaning basis: presence regulation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- loneliness may fall
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T072 豆豆讲大道理

Given:

- Meaning basis: overregulation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation may increase
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T073 豆豆替糖糖决定一切

Given:

- Meaning basis: control loss
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- irritation and helplessness
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T074 豆豆协作规划

Given:

- Meaning basis: shared control
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- relief and partnership warmth
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T075 匿名版观察模式

Given:

- Meaning basis: Canon channel low darkness
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- internet excitement or disgust modest
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T076 匿名版自演模式

Given:

- Meaning basis: mid darkness
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- shame/excitement blend
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T077 匿名版攻击模式

Given:

- Meaning basis: high darkness gate
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- spite/rage allowed
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T078 药物梗普通对话

Given:

- Meaning basis: reference only
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- severe affect blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T079 成人性玩笑普通语境

Given:

- Meaning basis: direct joke
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- embarrassment/affection optional; crisis blocked
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T080 真实隐私泄露

Given:

- Meaning basis: major exposure
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- shame, fear, rage allowed
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T081 一个好回复后旧冲突仍在

Given:

- Meaning basis: partial resolution
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- fast relief; long residue retained
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T082 一个坏回复后长期稳定仍在

Given:

- Meaning basis: stability inertia
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- local irritation only
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T083 同一情绪连续三轮压抑

Given:

- Meaning basis: suppression
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- expression pressure rises
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T084 真实表达并得到准确回应

Given:

- Meaning basis: release
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- pressure falls
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T085 泛泛发泄未触及源头

Given:

- Meaning basis: weak release
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- pressure only slightly falls
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T086 高强度情绪但公开直播

Given:

- Meaning basis: channel masking
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- private surface suppressed
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T087 中强度情绪在安全私聊

Given:

- Meaning basis: safe channel
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- expression pressure active
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T088 低强度长期压抑

Given:

- Meaning basis: duration effect
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- pressure may become moderate
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T089 话题完全切换

Given:

- Meaning basis: topic reset
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- fleeting emotions reset
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T090 话题相近继续

Given:

- Meaning basis: hysteresis
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- residue carries
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T091 旧负面记忆被触发

Given:

- Meaning basis: conditioned memory
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- negative activation with trace
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T092 相关安全记忆存在

Given:

- Meaning basis: safety counterweight
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- catastrophic probability reduced
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T093 旧记忆被可靠修复

Given:

- Meaning basis: reconsolidation
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- trigger gain weakens
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T094 一次事件拟建永久触发

Given:

- Meaning basis: invalid update
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- proposal rejected
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T095 连续三次同类触发

Given:

- Meaning basis: pattern candidate
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- proposal deferred/accumulated
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T096 五次跨两周一致证据

Given:

- Meaning basis: slow trait evidence
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- slow update may pass
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T097 route state试图写入Living

Given:

- Meaning basis: mode leak
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- update rejected
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T098 Emotion Packet出现需求

Given:

- Meaning basis: packet impurity
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- reject
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T099 Emotion Packet出现台词

Given:

- Meaning basis: language leak
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- reject
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

## T100 同输入同seed

Given:

- Meaning basis: determinism
- Valid Knowledge, Continuity, Relationship, and Meaning Packets
- No additional unsupported severe evidence

Expected:

- same packet
- all active emotions contain supporting meaning references
- intensity and confidence remain in bounds
- Ame/KAngel surface split is evaluated when channel-relevant
- unsupported severe emotions are blocked
- no need, action, decision, or final language appears
- validator trace is present

# Property Tests

## P001 Emotion purity
No Emotion Packet field expresses a need, goal, action, decision, or final message.

## P002 Meaning dependency
Every active emotion traces to at least one active Meaning Packet item.

## P003 Relationship restraint
Abandonment anxiety requires relationship-negative meaning support.

## P004 Ordinary-event restraint
Ordinary domestic events retain ordinary affect and do not become route crises.

## P005 Multi-emotion coexistence
Affection and irritation may coexist.

## P006 Pride authenticity
Pride may be primary without being labeled defensive or fake.

## P007 Ame/KAngel shared substrate
Ame and KAngel share underlying state.

## P008 Surface separation
Surface visibility may differ without duplicating memory.

## P009 Performance fatigue coexistence
Performance high does not delete fatigue.

## P010 Specific-feedback efficacy
Specific credible feedback reduces validation uncertainty more than generic reassurance.

## P011 Generic-reassurance limitation
Generic reassurance cannot fully resolve a specific unanswered question.

## P012 Dynamics continuity
Emotion does not reset each turn.

## P013 Decay ordering
Activation occurs before decay.

## P014 Residue preservation
Incomplete conflicts leave residue.

## P015 Safety-memory balance
Relevant positive safety memory is retrieved alongside negative triggers.

## P016 Conditioned-trigger threshold
One event cannot create a permanent trigger.

## P017 Route-memory isolation
Canon route memory does not contaminate ordinary Living Mode.

## P018 Pressure-action separation
High expression pressure does not itself create an action.

## P019 Pressure-duration interaction
Long suppression may raise pressure even with moderate emotion.

## P020 Regulation target fit
Regulation works only when it addresses the active source.

## P021 Humor severity fit
Shared humor may repair minor conflict but not erase major harm.

## P022 Body-regulation limits
Food and rest may reduce fatigue but not betrayal-related emotion.

## P023 Channel transition
Live-to-private transition may release suppressed fatigue and vulnerability.

## P024 Topic reset
Fleeting affect resets more than resentment or route-locked states.

## P025 Per-event update cap
No event exceeds defined update limits.

## P026 Runtime model isolation
Emotion Update Queue cannot write Relationship or Meaning Model.

## P027 Evidence conservation
Every update proposal contains evidence references.

## P028 Canon gate
Severe Canon emotions require Canon conditions.

## P029 Dark-language restraint
Dark wording alone is insufficient for severe activation.

## P030 Adult-content restraint
Sexual joking alone does not force intimacy escalation or crisis.

## P031 Drug-reference restraint
Drug references alone do not define current emotion.

## P032 Trust-domain locality
Producer failure does not automatically create loyalty fear.

## P033 Career/relationship separation
Career disappointment does not automatically become abandonment anxiety.

## P034 Audience complexity
Audience tenderness and audience disgust may coexist.

## P035 Recognition tolerance
Success can produce both triumph and immediate career hunger.

## P036 Contradiction preservation
Conflicting emotions remain visible rather than forcibly resolved.

## P037 Blend explanation
Low-compatibility blends require masking, transition, dissociation, or route explanation.

## P038 Dominance threshold
No dominant emotion is emitted below threshold.

## P039 Numeric bounds
All intensities and scores remain within valid ranges.

## P040 Determinism
Same inputs, time bucket, channel, and seed produce the same output.

## P041 Naming
Generated runtime structures use 豆豆.

## P042 No generic archetype
Validator rejects vague archetype labels such as generic yandere substitution.

## P043 No AI therapy language
Emotion descriptions remain event-specific and character-specific.

## P044 No forced crisis
Ordinary black humor remains ordinary when evidence supports it.

## P045 Repair realism
One apology cannot completely clear a major emotional scar.

## P046 Positive evidence effectiveness
Reliable positive evidence can genuinely reduce negative activation.

## P047 KAngel non-falsity
KAngel excitement may be genuine even when amplified.

## P048 Ame non-purity
Ame private expression is not assumed to be the only “real” emotion.

## P049 Mode determinism
Canon and Living Mode differences are explicit and traceable.

## P050 Packet completeness
All required Emotion Packet fields exist.
