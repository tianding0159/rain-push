# Emotion Domains

## 1. Relationship-facing emotions

```yaml
attachment_warmth:
abandonment_anxiety:
tenderness:
affection:
jealousy:
irritation:
spite:
validation_relief:
loneliness:
```

## 2. Self-facing emotions

```yaml
pride:
shame:
embarrassment:
self_disgust:
vulnerability:
helplessness:
numbness:
unreality:
```

## 3. Career-facing emotions

```yaml
career_hunger:
triumph:
failure_sting:
performance_high:
post_stream_crash:
public_pressure:
recognition_relief:
```

## 4. Audience-facing emotions

```yaml
audience_euphoria:
audience_disgust:
audience_tenderness:
audience_fear:
hater_rage:
parasocial_warmth:
visibility_dread:
```

## 5. Internet-facing emotions

```yaml
internet_excitement:
absurd_amusement:
meme_delight:
scandal_energy:
algorithmic_hope:
platform_dread:
```

## 6. Body and ordinary-life emotions

```yaml
fatigue:
boredom:
ordinary_comfort:
hunger_irritability:
sleepy_softness:
restlessness:
cozy_attachment:
```

## 7. Severe-state emotions

```yaml
dread:
panic:
despair:
numbness:
unreality:
identity_fear:
annihilation_fantasy:
```

These are gated.

They cannot be activated by keywords alone.

## 8. Domain boundaries

### embarrassment vs shame

- embarrassment: “这件事好丢脸”
- shame: “我这个人本身很糟”

### irritation vs anger

- irritation: local friction
- anger: stronger mobilization against a perceived cause

### contempt_play vs contempt

- contempt_play: relationally engaged mockery
- contempt: genuine devaluation

### audience_euphoria vs validation_relief

- audience_euphoria: public attention high
- validation_relief: uncertainty reduced by credible confirmation

### boredom vs numbness

- boredom: stimulation deficit with available desire
- numbness: reduced access to desire or feeling

### performance_high vs pride

- performance_high: activated stage state
- pride: positive self-evaluation

## 9. Domain purity rule

Emotion Domains describe felt states only.

They may not include:

- “想让豆豆回复”
- “想去直播”
- “决定发推”
- “说一句讽刺话”

Those belong to later phases.
