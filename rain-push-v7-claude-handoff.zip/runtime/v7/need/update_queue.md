# Need Update Queue

## 1. Purpose

Stage persistent Need Model changes.

Current active need state is not automatically a trait.

## 2. Schema

```yaml
need_update_queue:
  event_id:
  runtime_version:
  proposed:
  deferred:
  rejected:
  trace:
```

## 3. Proposal

```yaml
proposal:
  id:
  target_path:
  operation:
  value:
  delta:
  source_event:
  source_needs:
  evidence_refs:
  confidence:
  time_scale:
  commit_policy:
  repetition_requirement:
  expires_at:
```

## 4. Commit policies

```yaml
immediate_state:
  - deprivation residue
  - current satisfaction memory

accumulate_pattern:
  - repeated satisfier effectiveness
  - repeated counterfeit satisfier
  - conflict pattern

confirm_baseline:
  - persistent need sensitivity
  - stable maintenance supply

canon_evidence_only:
  - route-locked need
  - hard callback need
```

## 5. Allowed targets

```yaml
need_model.baseline_sensitivities.*
need_model.deprivation_thresholds.*
need_model.maintenance_needs.*
need_model.satisfaction_memory.*
need_model.counterfeit_satisfiers.*
need_model.conflict_patterns.*
need_model.persistence_rules.*
```

## 6. Forbidden targets

```yaml
emotion_model.*
relationship_model.*
meaning_model.*
thought.*
decision.*
action.*
language.*
```

## 7. Per-event caps

```yaml
deprivation_delta_max: 15
satisfaction_memory_delta_max: 5
counterfeit_strength_delta_max: 3
baseline_sensitivity_delta_max: 1
new_conflict_pattern_max: 1
route_locked_delta_max: 0 unless Canon gate
```

## 8. Pattern requirements

```yaml
counterfeit_satisfier:
  minimum_occurrences: 3

stable_satisfier:
  minimum_occurrences: 3

baseline_change:
  minimum_occurrences: 5
  minimum_time_span: 14_days
```

## 9. Positive and negative symmetry

Reliable satisfaction evidence must be able to reduce deprivation sensitivity.

The model must not only accumulate negative patterns.

## 10. Rejection rules

Reject when:

- no evidence
- target belongs to another runtime
- one event changes baseline strongly
- route need lacks Canon gate
- an action is stored as need
- final wording is stored
- counterfeit satisfaction is marked durable
