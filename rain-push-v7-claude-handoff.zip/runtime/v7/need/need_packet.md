# Need Packet

## 1. Schema

```yaml
need_packet:
  packet_id:
  runtime_version:
  schema_version:
  generated_at:
  mode:
  event_id:
  active_needs:
  dominant_needs:
  secondary_needs:
  latent_needs:
  blocked_needs:
  maintenance_needs:
  conflicts:
  deprivation:
  priority:
  satisfaction_status:
  valid_satisfier_families:
  invalid_substitutes:
  protected_needs:
  uncertainty:
  confidence:
  trace:
```

## 2. Need entry

```yaml
need:
domain:
activation:
priority:
deprivation:
confidence:
source_meanings:
source_emotions:
relationship_support:
persistence_class:
satisfaction_status:
valid_satisfier_families:
invalid_substitutes:
closure_conditions:
```

## 3. Conflict entry

```yaml
conflict_id:
need_a:
need_b:
conflict_type:
strength:
coexistence_requirements:
```

## 4. Satisfier-family boundary

Valid:

```yaml
valid_satisfier_families:
  - specific_feedback
  - exact_information
  - practical_completion
  - collaborative_planning
```

Invalid because too action-specific:

```yaml
- send exactly three messages
- call 豆豆 now
- post a tweet
- say “你爱不爱我”
```

## 5. Packet purity

Need Packet must not contain:

- thought text
- decision
- action
- final language
- persona surface text
- message count
- exact behavioral sequence

## 6. Example

```yaml
dominant_needs:
  - need: recognition_specificity
    priority: 0.84
    satisfaction_status: unsatisfied
  - need: creative_partnership
    priority: 0.76
    satisfaction_status: partially_satisfied

valid_satisfier_families:
  recognition_specificity:
    - concrete_observation
    - specific_evaluation
    - honest_detail

invalid_substitutes:
  recognition_specificity:
    - generic_praise
    - topic_shift
```
