# Phase 6: Need Runtime

## Status

- Version: `7.0-phase6`
- Runtime name: `Need Runtime`
- Partner display name: `豆豆`
- Depends on:
  - Knowledge Packet
  - Continuity Packet
  - Relationship Packet
  - Meaning Packet
  - Emotion Packet
- Produces:
  - Need Packet
  - Need Update Queue
- Does not produce:
  - thought
  - decision
  - action
  - final language
  - message count
  - exact behavior sequence

## Single responsibility

Need Runtime answers:

> 在当前关系意义和情绪状态下，糖糖此刻缺少什么、想维持什么、想避免失去什么，以及哪些满足条件才真正能让当前状态发生变化？

Need Runtime does not answer:

- 她最终会不会向豆豆提出要求
- 她应该发什么
- 她应该做什么
- 她会选择撒娇、攻击、沉默还是直播
- 最终台词是什么

## Core distinction

```text
Emotion:
烦躁、害羞、依赖、得意

Need:
需要豆豆给出具体评价
需要当前问题被真正回答
需要保持被认真看见
需要保留自己的主动权
```

Need is not strategy.

```text
Need:
需要明确的回归时间

Strategy:
问豆豆几点回来

Action:
发一条消息

Language:
“你到底几点回来”
```

Only the first belongs to Phase 6.

## Pipeline

```text
Knowledge Packet
+ Continuity Packet
+ Relationship Packet
+ Meaning Packet
+ Emotion Packet
        |
        v
Need Domain Activation
        |
        v
Deprivation / Maintenance Check
        |
        v
Need Conflict Engine
        |
        v
Need Priority Engine
        |
        v
Satisfaction Criteria Engine
        |
        v
Need Persistence
        |
        v
Need Packet
        |
        +--> Need Update Queue
        |
        v
Validator
```

## Architectural invariants

1. Need is distinct from emotion.
2. Need is distinct from behavior.
3. A need must trace to Meaning and Emotion Packets.
4. Needs may coexist and conflict.
5. “豆豆做某件具体事” is usually a satisfier candidate, not the need itself.
6. One need may have several valid satisfier families.
7. Counterfeit satisfaction must be detected.
8. Ordinary body and domestic needs remain real.
9. Audience, career, identity, intimacy, privacy, and autonomy needs may coexist.
10. Severe needs require severe evidence gates.
11. Need Packet contains no final wording.
12. Same inputs and seed produce the same Need Packet.
