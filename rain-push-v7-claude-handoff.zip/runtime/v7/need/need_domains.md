# Need Domains

## 1. Relationship domain

```yaml
recognition_specificity:
accurate_attunement:
relationship_availability:
relationship_reliability:
repair_acknowledgment:
fairness:
shared_control:
boundary_protection:
```

## 2. Career domain

```yaml
creative_partnership:
career_competence:
career_growth:
production_reliability:
honest_evaluation:
milestone_recognition:
```

## 3. Audience domain

```yaml
audience_affection:
audience_impact:
audience_distance:
public_safety:
public_memory_control:
```

## 4. Identity domain

```yaml
identity_continuity:
ame_visibility:
kangel_validation:
future_continuity:
self_respect:
reality_confirmation:
```

## 5. Autonomy and control domain

```yaml
autonomy:
predictability:
uncertainty_reduction:
shared_control:
choice_preservation:
```

## 6. Ordinary-life domain

```yaml
ordinary_comfort:
domestic_continuity:
food:
rest:
sleep:
warmth:
shared_routine:
leisure:
```

## 7. Body and intimacy domain

```yaml
physical_safety:
illness_care:
sensory_regulation:
physical_affection:
sexual_intimacy:
privacy:
```

## 8. Play and stimulation domain

```yaml
play:
stimulation:
novelty:
absurdity:
internet_discovery:
```

## 9. Grounding domain

```yaml
grounding:
reality_confirmation:
continuity_confirmation:
trusted_presence:
```

## 10. Domain boundary examples

### Emotion vs need

```text
emotion: irritation
need: accurate attunement
```

### Meaning vs need

```text
meaning: 豆豆可能没认真看
need: recognition specificity
```

### Need vs strategy

```text
need: uncertainty reduction
strategy: ask for an exact time
```

### Strategy vs action

```text
strategy: ask for an exact time
action: send one JINE message
```

### Action vs language

```text
action: send one JINE message
language: “几点回来”
```

## 11. Valid multi-domain activation

Example:

```yaml
event: 直播后豆豆只说“很强”
active_needs:
  - recognition_specificity
  - accurate_attunement
  - creative_partnership
  - ame_visibility
```

## 12. Invalid overactivation

Do not activate all of:

- relationship reliability
- public safety
- sexual intimacy
- grounding
- career growth
- food
- sleep

from one generic reply.

## 13. Severe need gates

Gated needs:

```yaml
reality_confirmation:
grounding:
public_safety:
identity_continuity:
relationship_survival:
```

They require corresponding Meaning and Emotion support.
