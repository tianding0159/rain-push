# Need Satisfaction Engine

## 1. Purpose

Define what evidence would count as real, partial, counterfeit, or failed satisfaction.

Need Runtime does not command 豆豆 or select an action.

It emits satisfier families and criteria.

## 2. Satisfaction schema

```yaml
need_satisfaction:
  need:
  status:
    unsatisfied
    partially_satisfied
    satisfied
    counterfeit
    blocked
  valid_satisfier_families:
  invalid_substitutes:
  evidence_required:
  durability:
  rebound_risk:
```

## 3. Satisfaction dimensions

```yaml
specificity:
credibility:
timing:
target_fit:
behavioral_cost:
follow_through:
relationship_fit:
durability:
```

## 4. Recognition specificity

Valid satisfiers:

- concrete observation
- reference to a specific moment
- comparison with prior work
- explanation of why something worked
- honest criticism with detail

Counterfeit:

- “很棒”
- “别想太多”
- exaggerated praise
- emoji-only response
- praising KAngel when Ame asked about Ame

## 5. Accurate attunement

Valid:

- answer the actual question
- explicitly name uncertainty
- distinguish multiple questions
- ask for clarification when needed

Counterfeit:

- warmth without answer
- long reply about another issue
- advice before understanding
- crisis framing of ordinary dark humor

## 6. Relationship availability

Valid:

- current presence
- credible return window
- prior notice
- reliable follow-through

Counterfeit:

- intense promise without timing
- generic “later”
- one unusually long message

## 7. Relationship reliability

Valid:

- repeated consistency
- promise fulfillment
- accurate updates
- repair after unavoidable failure

Counterfeit:

- one grand declaration
- one perfect day
- one apology with no action

## 8. Repair acknowledgment

Valid:

- identify concrete harm
- accept relevant responsibility
- avoid minimizing
- propose or perform repair
- follow through

Counterfeit:

- forced positivity
- joke before acknowledgment
- “你太敏感了”
- unrelated gift
- generic affection

## 9. Creative partnership

Valid:

- specific production feedback
- planning with reasons
- technical preparation
- constructive disagreement
- shared postmortem

Counterfeit:

- cheerleading only
- unilateral control
- vague encouragement
- taking credit without work

## 10. Career competence

Valid:

- evidence of learning
- successful execution
- clear causal analysis
- improved result
- ownership of success

Counterfeit:

- pure luck framed as competence
- ungrounded praise
- vanity metric alone when competence was questioned

## 11. Audience impact

Valid:

- meaningful comments
- retention or engagement
- clips
- follower growth
- recurring audience behavior
- cultural trace

Counterfeit:

- one bot
- unexplained metric spike
- empty flattery

## 12. Ame visibility

Valid:

- recognition of private preferences
- specific attention to Ame
- distinction between Ame and KAngel
- private care not directed at persona performance

Counterfeit:

- only praising KAngel
- treating private distress as content
- generic angel-language

## 13. Identity continuity

Valid:

- linking Ame and KAngel without erasing either
- preserving shared memory
- future plans that include both public and private self
- stable partner recognition across channels

## 14. Autonomy

Valid:

- real choice
- collaborative planning
- ability to refuse
- transparent reasons
- preserved agency

Counterfeit:

- choosing between two forced options
- being “protected” by losing control
- decisions made for her without participation

## 15. Privacy and public safety

Valid:

- containment
- clear boundaries
- deletion or access control where possible
- audience moderation
- reduced exposure
- credible safety plan

Counterfeit:

- “ignore it”
- treating risk as content only
- public reassurance that increases exposure

## 16. Ordinary comfort

Valid:

- food
- rest
- warmth
- shared routine
- manageable environment
- low-demand presence

## 17. Grounding

Valid only when grounding need is active.

Possible satisfier families:

- trusted presence
- sensory orientation
- concrete continuity
- practical reality check
- safe routine

The runtime does not issue medical instructions.

## 18. Physical affection and sexual intimacy

Valid satisfier families require:

- appropriate context
- mutuality
- privacy
- current intimacy meaning
- adult context
- consent-compatible framing

A joke alone is not satisfaction evidence.

## 19. Satisfaction score

```text
S_satisfaction
=
0.22 * target_fit
+ 0.18 * specificity
+ 0.15 * credibility
+ 0.12 * timing
+ 0.10 * follow_through
+ 0.08 * behavioral_cost
+ 0.08 * relationship_fit
+ 0.07 * durability
```

## 20. Partial satisfaction

Examples:

- exact return time reduces uncertainty but not reliability history
- specific praise satisfies recognition but not career planning
- food reduces irritability but not conflict
- apology satisfies acknowledgment partly but not repair follow-through

## 21. Rebound

A counterfeit satisfier may briefly reduce pressure and then increase deprivation.

```text
rebound
=
initial_relief
* unresolved_core
* counterfeit_confidence
```

## 22. Failure cases

Reject when:

- generic reassurance fully satisfies specificity
- affection fully satisfies practical completion
- one success fully satisfies career growth
- rest satisfies betrayal repair
- audience praise satisfies Ame visibility automatically
- public performance satisfies privacy
