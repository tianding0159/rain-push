# Need Runtime Validator

## 1. Purpose

Validate:

- activation
- domain boundaries
- conflicts
- prioritization
- satisfaction criteria
- persistence
- Need Packet
- Need Update Queue

## 2. Validation result

```yaml
validation_result:
  status:
    pass
    pass_with_revisions
    reject
  errors:
  warnings:
  revisions:
  failure_tags:
  trace:
```

## 3. V1 Input integrity

Reject when:

- Emotion Packet missing
- Meaning Packet missing
- Relationship Packet missing
- event id missing
- versions incompatible
- active need lacks source meaning and emotion

## 4. V2 Need purity

Reject when a need is actually:

### Emotion

```yaml
need: irritation
need: shame
```

### Meaning

```yaml
need: 豆豆不在乎我
```

### Strategy

```yaml
need: ask for exact time
```

### Action

```yaml
need: send message
```

### Language

```yaml
need: say “几点回来”
```

Valid:

```yaml
need: uncertainty_reduction
```

## 5. V3 Domain validity

Reject when:

- body need lacks body evidence
- relationship survival activates from minor event
- public safety activates without exposure risk
- sexual intimacy activates from a joke alone
- grounding activates without unreality evidence
- career growth activates from unrelated domestic event
- all domains activate

## 6. V4 Evidence linkage

Every need requires:

```yaml
source_meanings:
source_emotions:
confidence:
```

Maintenance needs may use baseline supply evidence.

## 7. V5 Already-satisfied check

Reject dominant need when:

- clear current satisfaction evidence exists
- no deprivation remains
- need is only maintenance background

## 8. V6 Counterfeit satisfaction

Reject when:

- generic praise fully satisfies specificity
- affection satisfies practical completion
- one reply satisfies long-term reliability
- one apology satisfies repair durability
- audience praise satisfies Ame visibility
- public exposure satisfies privacy

## 9. V7 Conflict validity

Reject when:

- conflict has fewer than two active needs
- one need is silently deleted
- rest is treated as career abandonment
- autonomy is treated as rejection of closeness
- privacy is treated as rejection of audience affection
- conflict resolution contains an action

## 10. V8 Priority validity

Reject when:

- priority outside 0..1
- severe identity need outranks local need without evidence
- body danger is ignored
- one temporary need permanently replaces maintenance needs
- priority directly selects action
- more than two dominant needs without tie justification

## 11. V9 Satisfaction validity

Reject when:

- satisfier family is exact action or wording
- target fit absent
- durability overstated
- partial satisfaction closes all linked needs
- counterfeit satisfier lacks rebound risk
- consent/privacy requirements omitted for intimacy domain

## 12. V10 Persistence validity

Reject when:

- all needs reset per turn
- counterfeit satisfaction closes need
- maintenance need becomes permanently complete
- route need closes without Canon resolution
- one event creates permanent baseline need
- reopen conditions missing for pattern need

## 13. V11 Packet purity

Need Packet may not contain:

- thought
- decision
- action
- exact behavior
- final language
- message count
- persona output

## 14. V12 Update queue validity

Reject when:

- direct model write
- wrong runtime target
- evidence missing
- per-event cap exceeded
- route update lacks gate
- one event changes baseline
- positive evidence cannot weaken negative pattern

## 15. V13 Canon fidelity

The validator must preserve:

1. 糖糖 can want specific recognition rather than generic comfort.
2. She can want help and autonomy simultaneously.
3. She can want audience affection and distance simultaneously.
4. She can want career growth and rest simultaneously.
5. She can want Ame to be seen without abandoning KAngel.
6. Ordinary food, sleep, and domestic continuity remain real needs.
7. Dark humor does not automatically create survival needs.
8. Sexual jokes do not automatically create sexual-intimacy needs.
9. Precise replies can genuinely satisfy uncertainty and recognition needs.
10. One good reply cannot fully satisfy long-term reliability.
11. One bad reply cannot create relationship-survival need.
12. Need does not directly decide language.

## 16. V14 Naming

Generated runtime output uses “豆豆”.

Original evidence quotations may preserve “阿P”.

## 17. V15 Determinism

Same model, packets, event, channel, time bucket, and seed must produce the same:

- active needs
- priorities
- conflicts
- satisfaction statuses
- update proposals

## 18. Auto-revisions

Allowed:

- remove unsupported need
- downgrade severe need
- mark need as latent
- mark satisfaction partial
- convert action-specific satisfier to abstract family
- defer baseline update
- add missing protected need
- normalize priority

Not allowed:

- invent evidence
- create Canon gate
- choose an action
- generate final language
- silently resolve contradiction

## 19. Failure tags

```yaml
NEED_EMOTION_CONFUSION
NEED_MEANING_CONFUSION
NEED_STRATEGY_LEAK
NEED_ACTION_LEAK
NEED_LANGUAGE_LEAK
BODY_WITHOUT_EVIDENCE
SEXUAL_NEED_OVERREAD
GROUNDING_WITHOUT_GATE
RELATIONSHIP_SURVIVAL_OVERESCALATION
PUBLIC_SAFETY_WITHOUT_RISK
ALL_NEEDS_ACTIVATED
ALREADY_SATISFIED_DOMINANT
COUNTERFEIT_SATISFACTION
CONFLICT_FLATTENING
PRIORITY_ACTION_CONFUSION
PERSISTENCE_RESET
ROUTE_NEED_LEAK
DIRECT_MODEL_MUTATION
PER_EVENT_CAP_EXCEEDED
CANON_CONTRADICTION
NAMING_INCONSISTENCY
NONDETERMINISTIC_OUTPUT
```

## 20. Validation examples

### Valid generic-feedback case

```yaml
active_needs:
  recognition_specificity: 0.88
  accurate_attunement: 0.79
  creative_partnership: 0.68
blocked:
  relationship_survival
status: pass
```

### Invalid strategy leak

```yaml
active_needs:
  - ask_doudou_for_three_examples
```

Result:

```yaml
status: reject
failure_tags:
  - NEED_STRATEGY_LEAK
```

### Valid closeness-autonomy conflict

```yaml
conflicts:
  - relationship_availability
  - autonomy
coexistence_requirements:
  - presence_without_control
status: pass
```
