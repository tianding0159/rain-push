# Need Prioritization

## 1. Purpose

Rank active needs without converting them into actions.

## 2. Priority formula

```text
P_need
=
0.20 * activation
+ 0.15 * deprivation
+ 0.12 * urgency
+ 0.10 * unresolved_weight
+ 0.10 * emotion_pressure
+ 0.08 * identity_relevance
+ 0.08 * relationship_relevance
+ 0.06 * body_relevance
+ 0.05 * satisfiability
+ 0.03 * maintenance_importance
+ 0.03 * canon_priority
- already_satisfied
- counterfeit_risk
- conflict_cost
```

Clamp to `0..1`.

## 3. Priority classes

```yaml
critical: >= 0.85
dominant: 0.70..0.84
active: 0.50..0.69
background: 0.30..0.49
omit: < 0.30
```

Critical requires:

- safety
- body danger
- route gate
- severe privacy exposure
- severe reality instability

## 4. Urgency

```yaml
immediate:
  - physical safety
  - public safety
  - acute body need
  - exact deadline

near_term:
  - active conflict repair
  - stream preparation
  - current uncertainty

maintenance:
  - relationship reliability
  - future continuity
  - ordinary comfort
```

## 5. Satisfiability

A need with clear satisfier evidence may rank above a larger but currently unsatisfiable need.

This does not mean it is more important globally.

## 6. Identity relevance

Identity-relevant needs receive a bonus only when identity domain is validly active.

## 7. Body override

Body and safety needs may temporarily outrank career and relationship needs.

Examples:

- sleep deprivation
- illness
- actual privacy risk

Body override does not permanently reduce career or attachment importance.

## 8. Relationship localism

A local relationship need should outrank global attachment escalation when the local need explains the event.

Example:

```text
generic feedback
→ recognition specificity
```

Before:

```text
relationship survival
```

## 9. Priority tie

If top needs differ by less than `0.07`, keep both co-dominant.

## 10. Protected needs

A lower-priority need can be marked protected.

Example:

```yaml
dominant:
  - rest
protected:
  - career_growth
```

## 11. Stability

```text
new_priority
=
0.75 * current
+ 0.25 * previous_topic_priority
```

Do not carry across unrelated topics.

## 12. Failure cases

Reject when:

- every emotional intensity becomes equal need priority
- severe identity need outranks local specific need without evidence
- body needs are ignored
- one temporary need permanently replaces maintenance needs
- priority directly outputs an action
