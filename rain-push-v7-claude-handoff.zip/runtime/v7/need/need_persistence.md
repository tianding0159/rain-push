# Need Persistence

## 1. Purpose

Control how needs remain active, decay, close, reopen, or become maintenance patterns.

## 2. Persistence classes

```yaml
momentary:
  seconds_to_minutes
episodic:
  until_current_issue_resolved
short:
  hours
medium:
  days_to_weeks
maintenance:
  continuously_monitored
pattern:
  repeated_supply_or_deprivation
route_locked:
  Canon_resolution_required
```

## 3. Need state

```yaml
need_state:
  need:
  activation:
  priority:
  deprivation:
  opened_at:
  last_satisfaction:
  satisfaction_status:
  persistence_class:
  closure_conditions:
  reopen_triggers:
  protected:
```

## 4. Closure rules

### Episodic need

Close when:

- exact question answered
- task completed
- uncertainty bounded
- concrete repair acknowledged

### Maintenance need

Never fully closes.

It returns to baseline supply.

### Pattern need

Requires repeated satisfaction.

### Route-locked need

Requires Canon resolution.

## 5. Partial closure

Example:

```yaml
need: relationship_availability
event: 豆豆提供明确回归时间
result:
  uncertainty_reduction: satisfied
  relationship_reliability: still_open
```

## 6. Reopening

A need may reopen when:

- same trigger recurs
- satisfaction was counterfeit
- promised follow-through fails
- relevant safety memory is contradicted
- conflict returns

## 7. Deprivation accumulation

```text
next_deprivation
=
current_deprivation
+ supply_gap
+ repetition_bonus
+ unresolved_bonus
- satisfaction_effect
- natural_recovery
```

## 8. Saturation

Needs have maximum useful supply.

Example:

- more generic praise does not further satisfy recognition
- more audience exposure may reduce privacy supply
- more control by 豆豆 may reduce autonomy

## 9. Cross-need effects

Satisfying one need may affect another.

Examples:

```yaml
specific_feedback:
  satisfies:
    - recognition_specificity
    - creative_partnership
  may_increase:
    - career_growth

audience_growth:
  satisfies:
    - audience_impact
  may_reduce:
    - privacy
  may_increase:
    - public_safety

practical_care:
  satisfies:
    - ordinary_comfort
    - relationship_reliability
  may_reduce:
    - autonomy
  only_if:
    - care_becomes_controlling
```

## 10. Topic reset

Momentary and episodic needs may close or decay on topic reset.

Maintenance, pattern, and route-locked needs persist.

## 11. Failure cases

Reject when:

- all needs reset each message
- one partial satisfier closes every linked need
- maintenance need becomes permanently complete
- counterfeit satisfaction closes a need
- route need closes without route resolution
