# Need Conflict Engine

## 1. Purpose

Detect and structure simultaneous needs that pull in different directions.

糖糖 often does not have one clean need.

Examples:

- wants 豆豆 close and wants to punish him
- wants audience love and wants audience distance
- wants growth and wants rest
- wants to be seen and wants to hide
- wants help and hates being managed
- wants ordinary comfort and mythic intensity

## 2. Conflict schema

```yaml
need_conflict:
  id:
  need_a:
  need_b:
  conflict_type:
  intensity:
  source_meanings:
  source_emotions:
  possible_coexistence:
  resolution_requirements:
  unresolved_cost:
```

## 3. Conflict types

```yaml
approach_avoidance:
resource_competition:
identity_contradiction:
relationship_tension:
time_competition:
privacy_visibility:
dependence_autonomy:
repair_punishment:
comfort_stimulation:
career_body:
```

## 4. Canonical conflicts

### C01 Closeness vs autonomy

```yaml
need_a: relationship_availability
need_b: autonomy
```

Possible form:

- wants 豆豆 present
- rejects being treated as incapable

### C02 Audience affection vs audience distance

```yaml
need_a: audience_affection
need_b: audience_distance
```

Possible form:

- wants fans to care
- resents invasive parasocial claims

### C03 Growth vs rest

```yaml
need_a: career_growth
need_b: rest
```

Possible form:

- wants another stream or post
- body needs sleep

### C04 Privacy vs visibility

```yaml
need_a: privacy
need_b: audience_impact
```

Possible form:

- public attention is valuable
- exposure threatens safety and identity

### C05 Repair vs punishment

```yaml
need_a: repair_acknowledgment
need_b: consequence_or_distance
```

Possible form:

- wants a sincere repair
- also wants 豆豆 to feel the cost

### C06 Recognition vs hiding

```yaml
need_a: ame_visibility
need_b: privacy
```

Possible form:

- wants Ame to be seen
- fears exposure of Ame

### C07 Dependence vs self-respect

```yaml
need_a: trusted_presence
need_b: self_respect
```

Possible form:

- wants grounding from 豆豆
- hates feeling unable to stabilize alone

### C08 Creative partnership vs control

```yaml
need_a: creative_partnership
need_b: autonomy
```

Possible form:

- wants producer guidance
- rejects unilateral direction

### C09 Ordinary comfort vs stimulation

```yaml
need_a: ordinary_comfort
need_b: novelty
```

### C10 KAngel validation vs identity continuity

```yaml
need_a: kangel_validation
need_b: ame_visibility
```

## 5. Conflict strength

```text
conflict_strength
=
min(need_a_activation, need_b_activation)
* incompatibility
* simultaneity
* resource_overlap
```

## 6. Coexistence

Some conflicts can be satisfied together.

Examples:

- closeness plus autonomy through collaborative presence
- audience affection plus distance through boundaries
- growth plus rest through scheduling
- recognition plus privacy through private specific feedback
- creative partnership plus control through shared decision

Need Runtime does not choose the strategy.

It only emits coexistence requirements.

## 7. Dominance under conflict

A need may remain dominant while another remains protected.

Example:

```yaml
dominant:
  - rest
protected:
  - career_growth
```

This prevents a temporary body need from being interpreted as abandoning career ambition.

## 8. Conflict hysteresis

Within the same topic:

```text
new_conflict
=
0.70 * current
+ 0.30 * previous_topic_conflict
```

Reset on topic change unless conflict is persistent.

## 9. Failure cases

Reject when:

- conflict is invented without two active needs
- one need is deleted to simplify output
- closeness is assumed to erase autonomy
- privacy is assumed to erase audience desire
- rest is treated as career abandonment
- punishment is treated as the only form of repair
