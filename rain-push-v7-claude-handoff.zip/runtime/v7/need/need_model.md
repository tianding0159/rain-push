# Need Model Specification

## 1. Purpose

Need Model stores persistent need sensitivities, deprivation tendencies, satisfaction histories, counterfeit satisfiers, and conflict patterns.

It does not store current actions.

It does not store final language.

It does not assume a generic human-needs hierarchy.

The model is tailored to 糖糖’s relationship, streaming career, internet identity, ordinary life, and Ame/KAngel dual surface.

## 2. Top-level structure

```yaml
need_model:
  metadata:
  baseline_sensitivities:
  deprivation_thresholds:
  maintenance_needs:
  episodic_needs:
  relationship_needs:
  career_needs:
  audience_needs:
  identity_needs:
  autonomy_needs:
  control_needs:
  safety_needs:
  ordinary_life_needs:
  body_needs:
  intimacy_needs:
  stimulation_needs:
  grounding_needs:
  repair_needs:
  satisfaction_memory:
  counterfeit_satisfiers:
  conflict_patterns:
  persistence_rules:
  mode_state:
```

## 3. Core need families

```yaml
recognition_specificity:
accurate_attunement:
relationship_availability:
relationship_reliability:
practical_completion:
shared_control:
autonomy:
predictability:
uncertainty_reduction:
repair_acknowledgment:
fairness:
privacy:
public_safety:
identity_continuity:
ame_visibility:
kangel_validation:
creative_partnership:
career_competence:
career_growth:
audience_impact:
audience_affection:
audience_distance:
ordinary_comfort:
domestic_continuity:
rest:
food:
physical_safety:
physical_affection:
sexual_intimacy:
play:
stimulation:
novelty:
grounding:
reality_confirmation:
future_continuity:
self_respect:
boundary_protection:
```

## 4. Baseline sensitivity schema

```yaml
baseline_sensitivity:
  need:
  value: 0..100
  confidence: 0..1
  source_refs: []
  updated_at:
  mode:
```

High sensitivity does not mean the need is always active.

It raises the prior only when current packets support activation.

## 5. Deprivation threshold

```yaml
deprivation_threshold:
  need:
  trigger_level:
  escalation_curve:
  recovery_floor:
  saturation:
```

Example:

```yaml
need: recognition_specificity
trigger_level: 35
escalation_curve: repeated_generic_feedback
recovery_floor: 20
saturation: 90
```

## 6. Maintenance needs

Maintenance needs are continuously relevant at low intensity.

Examples:

- ordinary comfort
- relationship reliability
- privacy
- autonomy
- body regulation
- future continuity

Maintenance need state:

```yaml
maintenance:
  baseline:
  current_supply:
  minimum_supply:
  depletion_rate:
  replenishment_rate:
```

## 7. Episodic needs

Episodic needs activate around a specific event.

Examples:

- exact answer to a direct question
- repair after a conflict
- technical help before a stream
- privacy containment after a leak
- specific feedback after performance

## 8. Relationship needs

### recognition_specificity

Need to be seen in concrete detail.

Valid evidence:

- asking for specific evaluation
- generic praise failing to resolve uncertainty
- Ame/KAngel distinction being ignored
- a detail being remembered accurately

Counterfeit satisfiers:

- generic reassurance
- exaggerated praise with no detail
- changing subject
- only praising KAngel when Ame asked about herself

### accurate_attunement

Need for the response to address the actual question.

Not equivalent to:

- warmth
- speed
- length

A fast, affectionate reply can still fail attunement.

### relationship_availability

Need for 豆豆 to be findable or to provide a credible return expectation.

Not equivalent to constant access.

### relationship_reliability

Need for repeated consistency over time.

One reply cannot fully satisfy this need.

### repair_acknowledgment

Need for harm, omission, or misunderstanding to be recognized accurately.

Counterfeit:

- “别想太多”
- joke before acknowledgment
- apology that avoids the concrete issue

### fairness

Need for responsibility and emotional burden to be distributed fairly.

### shared_control

Need to participate in plans rather than being passively managed.

### boundary_protection

Need for private limits to be respected by 豆豆, audience, platform, and collaborators.

## 9. Career needs

### creative_partnership

Need for 豆豆 to participate as a real producer, not merely a cheerleader.

Valid satisfiers:

- specific production analysis
- coherent planning
- technical preparation
- honest disagreement with reasons

### career_competence

Need to experience herself as capable of improving outcomes.

### career_growth

Need for movement toward a larger audience, stronger content, better execution, or greater symbolic status.

### audience_impact

Need for evidence that the stream affected viewers.

Metrics may partially satisfy this.

### KAngel validation

Need for the public persona’s performance to be recognized as successful.

This can coexist with Ame visibility.

## 10. Audience needs

### audience_affection

Need for signs of genuine viewer attachment.

### audience_distance

Need to keep the audience from consuming all privacy and identity.

### audience_impact

Need to matter, trend, move metrics, produce clips, or create cultural trace.

### public_safety

Need to avoid doxxing, harassment, platform sanction, stalking, and uncontrolled exposure.

## 11. Identity needs

### identity_continuity

Need for Ame and KAngel to remain connected without one annihilating the other.

### Ame visibility

Need for private Ame to be seen, not only the public angel.

### reality confirmation

Need for credible feedback, continuity, and presence that makes experience feel real.

### future continuity

Need for the relationship, career, and ordinary life to remain imaginable beyond the current turn.

## 12. Autonomy and control

### autonomy

Need to remain an agent rather than an object being managed.

### predictability

Need to understand what will happen next.

### uncertainty reduction

Need for missing information to become bounded.

### shared control

Need to influence decisions with 豆豆.

Autonomy can conflict with practical dependence.

## 13. Ordinary-life needs

```yaml
ordinary_comfort:
domestic_continuity:
food:
rest:
warmth:
sleep:
leisure:
shared_routine:
```

These are not narratively inferior to dramatic needs.

An empty fridge may activate food and domestic continuity without activating abandonment.

## 14. Body needs

```yaml
rest:
food:
hydration:
physical_safety:
illness_care:
physical_affection:
sexual_intimacy:
sensory_regulation:
```

Body needs require body evidence.

A sexual joke does not automatically activate sexual intimacy.

## 15. Play and stimulation

### play

Need for shared humor, teasing, absurd rules, games, and internal jokes.

### stimulation

Need to escape boredom or flatness.

### novelty

Need for a new idea, stream theme, route, event, or internet discovery.

These can regulate emotion but may also compete with rest and safety.

## 16. Grounding needs

### grounding

Need for sensory, relational, or practical anchors.

### reality confirmation

Need for events and feedback to feel credible and continuous.

These are gated by unreality or dissociation-related evidence.

They must not activate from ordinary inconvenience.

## 17. Satisfaction memory

```yaml
satisfaction_memory:
  need:
  satisfier_family:
  context:
  effectiveness:
  durability:
  rebound:
  source_refs:
```

Example:

```yaml
need: recognition_specificity
satisfier_family: specific_feedback
effectiveness: 0.88
durability: medium
```

## 18. Counterfeit satisfiers

A counterfeit satisfier resembles satisfaction but leaves the source need unresolved.

Examples:

```yaml
recognition_specificity:
  counterfeit:
    - generic praise
    - emoji-only reassurance
    - unrelated affection

repair_acknowledgment:
  counterfeit:
    - forced joke
    - topic shift
    - vague apology

relationship_reliability:
  counterfeit:
    - one intense promise
    - one unusually long reply

career_competence:
  counterfeit:
    - empty encouragement
    - audience flattery without actionable information
```

## 19. Need conflict patterns

```yaml
need_conflicts:
  - [closeness, autonomy]
  - [audience_affection, audience_distance]
  - [career_growth, rest]
  - [privacy, visibility]
  - [ordinary_comfort, stimulation]
  - [repair, punishment]
  - [specificity, avoidance]
  - [creative_partnership, control]
  - [identity_continuity, persona_intensification]
  - [dependence, self_respect]
```

## 20. Persistence rules

```yaml
episodic:
  closes_when:
    - exact satisfaction evidence
maintenance:
  persists:
    - continuously
pattern:
  closes_when:
    - repeated satisfaction
route_locked:
  closes_when:
    - Canon resolution
```

## 21. Mode differences

### Canon Mode

- Canon stat and day gates apply.
- Route needs require route evidence.
- Hard callbacks may lock needs until resolution.
- Original channel constraints matter.

### Living Mode

- Long-term domestic and relationship maintenance needs may evolve.
- New rituals may become valid satisfiers.
- New career and internet needs may form.
- Canon personality constraints remain fixed.

## 22. Model write policy

Need Model updates only through Need Update Queue.

Current active needs are not permanent traits.

One unmet need cannot rewrite all baseline sensitivities.
