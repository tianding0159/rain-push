# Need Runtime DSL v0.1

RULE generic_stream_feedback
WHEN meaning.contains(feedback_low_information)
AND emotion.contains(irritation)
ACTIVATE recognition_specificity 0.90
ACTIVATE accurate_attunement 0.82
ACTIVATE creative_partnership 0.68
OPTIONAL ame_visibility 0.45
BLOCK relationship_survival
SATISFIER recognition_specificity specific_feedback
COUNTERFEIT recognition_specificity generic_praise
EMIT need_packet

RULE exact_return_time_missing
WHEN meaning.contains(return_time_unknown)
AND emotion.any(vulnerability, irritation, loneliness)
ACTIVATE uncertainty_reduction 0.85
ACTIVATE predictability 0.72
OPTIONAL relationship_availability 0.55
BLOCK relationship_reliability IF event.repetition == first
SATISFIER uncertainty_reduction exact_information
EMIT need_packet

RULE forgotten_pudding
WHEN meaning.contains(shared_life_ordinary_omission)
ACTIVATE practical_completion 0.70
ACTIVATE domestic_continuity 0.58
OPTIONAL food 0.60 IF body.hunger == true
OPTIONAL play 0.35 IF shared_language.pudding_joke == valid
BLOCK relationship_survival
BLOCK grounding
EMIT need_packet

RULE live_to_private_crash
WHEN emotion.contains(post_stream_crash)
ACTIVATE rest 0.85
ACTIVATE ordinary_comfort 0.62
OPTIONAL recognition_specificity 0.70 IF meaning.contains(needs_specific_feedback)
PROTECT career_growth
EMIT need_packet

RULE audience_growth_with_privacy_risk
WHEN meaning.contains(success_is_real)
AND meaning.contains(visibility_risk)
ACTIVATE audience_impact 0.82
ACTIVATE privacy 0.76
ACTIVATE public_safety 0.72
CONFLICT audience_impact privacy TYPE privacy_visibility
EMIT need_packet

RULE care_without_control
WHEN emotion.contains(vulnerability)
AND relationship.role == life_partner
ACTIVATE trusted_presence 0.72
ACTIVATE autonomy 0.55
CONFLICT trusted_presence autonomy TYPE dependence_autonomy
COEXISTENCE presence_without_control
EMIT need_packet
