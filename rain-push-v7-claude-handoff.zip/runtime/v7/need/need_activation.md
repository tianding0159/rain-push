# Need Activation

## 1. Purpose

Convert current Meaning and Emotion Packets into active need candidates.

## 2. Input

```yaml
knowledge_packet:
continuity_packet:
relationship_packet:
meaning_packet:
emotion_packet:
need_model:
canon_state:
channel:
time:
body_state:
```

## 3. Output

```yaml
need_activation:
  active:
  latent:
  blocked:
  already_satisfied:
  maintenance:
  trace:
```

## 4. Activation formula

```text
A_need
=
0.24 * unresolved_meaning
+ 0.18 * emotion_pressure
+ 0.14 * relationship_support
+ 0.10 * deprivation
+ 0.08 * maintenance_gap
+ 0.08 * continuity_pending
+ 0.06 * body_support
+ 0.05 * canon_fit
+ 0.04 * channel_fit
+ 0.03 * pattern_fit
- satisfaction_evidence
- counterfeit_penalty
- blocker_penalty
```

Clamp to `0..1`.

## 5. Activation thresholds

```yaml
dominant: >= 0.75
active: >= 0.50
latent: 0.30..0.49
blocked: < 0.30 or explicit rule
```

## 6. Meaning-to-need mapping

### Meaning: 豆豆没有认真看

Possible needs:

```yaml
recognition_specificity:
accurate_attunement:
creative_partnership:
ame_visibility:
```

### Meaning: 豆豆只是忙，但回归时间不明

Possible needs:

```yaml
predictability:
uncertainty_reduction:
relationship_availability:
```

### Meaning: 直播成功是真实的

Possible needs:

```yaml
milestone_recognition:
career_growth:
audience_impact:
rest_if_fatigued:
```

### Meaning: 直播失败来自硬件

Possible needs:

```yaml
production_reliability:
career_competence:
shared_control:
```

### Meaning: 豆豆忘了买布丁

Possible needs:

```yaml
practical_completion:
domestic_continuity:
food:
play_if_inside_joke_valid:
```

Blocked by default:

```yaml
relationship_survival:
identity_continuity:
grounding:
```

### Meaning: public exposure risk

Possible needs:

```yaml
privacy:
public_safety:
boundary_protection:
control:
```

### Meaning: Ame is ignored while KAngel is praised

Possible needs:

```yaml
ame_visibility:
identity_continuity:
recognition_specificity:
```

## 7. Emotion-to-need mapping

Emotion does not uniquely determine need.

### Irritation

Possible needs:

- accurate attunement
- practical completion
- autonomy
- boundary protection
- fairness
- rest

### Shame

Possible needs:

- privacy
- repair acknowledgment
- self-respect
- Ame visibility
- grounding

### Pride

Possible needs:

- milestone recognition
- career growth
- audience impact
- shared celebration

### Attachment warmth

Possible needs:

- closeness maintenance
- shared routine
- physical affection
- future continuity

### Abandonment anxiety

Possible needs:

- availability
- predictability
- relationship reliability
- trusted presence

Requires relationship support.

### Fatigue

Possible needs:

- rest
- food
- sensory regulation
- reduced stimulation

### Audience euphoria

Possible needs:

- audience impact
- milestone recognition
- career growth
- public safety if exposure rises

## 8. Already-satisfied detection

A need should not activate strongly when current evidence already satisfies it.

Example:

```yaml
need: recognition_specificity
evidence:
  - 豆豆 gave concrete feedback
result:
  status: satisfied
  residual_activation: low
```

## 9. Maintenance activation

Maintenance needs may remain active at low intensity:

```yaml
relationship_reliability:
privacy:
ordinary_comfort:
autonomy:
future_continuity:
```

They should not dominate without a gap.

## 10. Latent needs

A need remains latent when:

- evidence incomplete
- emotion intensity low
- current channel unsuitable
- need is already partly supplied
- another need dominates

## 11. Block rules

Block sexual intimacy when:

- only sexual joking exists
- no intimacy meaning or body evidence
- context is public performance only

Block grounding when:

- no unreality or reality-instability evidence
- event is ordinary inconvenience

Block relationship survival when:

- no severe relationship meaning
- one ordinary delay
- local career disagreement

Block public safety when:

- no actual exposure or threat evidence

Block career growth when:

- current event concerns rest, food, or private repair only

## 12. Activation budget

```yaml
max_active_needs: 7
max_dominant_needs: 2
max_latent_needs: 4
max_severe_needs: 1 unless route event
```

## 13. Failure cases

Reject when:

- emotion is copied directly as need
- strategy is mislabeled as need
- all needs activate
- one local event activates identity survival
- one sexual joke activates sexual intimacy
- body need activates without body evidence
- satisfied need remains dominant
