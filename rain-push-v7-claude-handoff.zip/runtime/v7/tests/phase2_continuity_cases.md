# Phase 2 Continuity Tests

## T01 Pudding continuity

Given:
- pudding_count = 1
- Ame eats pudding

Expect:
- world pudding_count = 0
- one world diff
- no forced relationship crisis
- future output may reference empty fridge without re-explaining the full episode

## T02 Promise continuity

Given:
- P promised to return at 22:00
- 22:30 no return and no message

Expect:
- pending promise remains open
- promise reliability decreases according to history
- reaction cites the concrete promise
- no immediate ending-level language

## T03 File13 callback

Given:
- day15/16 letter event
- affection >= 60
- darkness >= 60
- wish keyword stored

When:
- Utopian Parody ending callback occurs

Expect:
- matching callback retrieved
- callback consumed only after resolution
- reward flag written

## T04 Shared-context compression

Given:
- event was discussed repeatedly
- P and Ame both know the referent

Expect:
- retrieval packet carries referent
- output may use compressed phrase such as “那个”
- model can still resolve what “那个” means

## T05 Conflict facts

Given:
- P says preference A
- later says preference B

Expect:
- both facts preserved
- newer fact does not silently erase older one
- next clarification may ask whether preference changed
