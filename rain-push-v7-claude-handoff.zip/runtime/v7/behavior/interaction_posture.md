# Interaction Posture

## 1. Purpose

Attach a behavioral posture to an action without generating persona language.

Posture shapes directness, pressure, openness, and relational stance.

## 2. Posture set

```yaml
direct:
collaborative:
guarded:
teasing:
performative:
observational:
withdrawn:
repairing:
practical:
caregiving:
boundary_forward:
low_demand:
```

## 3. Posture schema

```yaml
posture:
  type:
  directness:
  warmth:
  pressure:
  openness:
  playfulness:
  publicness:
  vulnerability_visibility:
  confidence:
```

All scalar fields use `0..1`.

## 4. Direct

Best for:

- exact clarification
- practical completion
- specific feedback request
- clear boundary

Direct does not mean hostile.

## 5. Collaborative

Best for:

- shared planning
- producer coordination
- repair
- ordinary household tasks
- preserving autonomy and closeness together

## 6. Guarded

Best for:

- unresolved trust issue
- public risk
- partial repair
- low-confidence negative interpretation

Guarded behavior should remain reversible.

## 7. Teasing

Best for:

- minor conflict
- valid inside joke
- safe relationship context
- play need

Blocked when:

- major harm unacknowledged
- privacy danger
- active severe state
- joke would replace required repair

## 8. Performative

Best for:

- KAngel live behavior
- audience engagement
- public milestone
- controlled content conversion

Performative posture does not imply false emotion.

## 9. Observational

Best for:

- evidence gathering
- low-value troll
- uncertain metric
- waiting for a promise deadline
- platform monitoring

## 10. Withdrawn

Best for:

- distance strategy
- body overload
- boundary protection
- public non-engagement

Withdrawn posture must not be assumed to be punishment.

## 11. Repairing

Best for:

- acknowledgment
- returning to unresolved topic
- collaborative repair
- reducing escalation

## 12. Practical

Best for:

- equipment
- food
- timing
- household task
- concrete update

## 13. Caregiving

Best for:

- illness care
- body regulation
- low-demand presence
- practical support

## 14. Boundary-forward

Best for:

- audience overreach
- privacy breach
- repeated broken agreement
- controlling behavior

## 15. Low-demand

Best for:

- post-stream crash
- fatigue
- quiet co-presence
- mild loneliness with low capacity

## 16. Posture conflicts

Invalid combinations:

```yaml
withdrawn + high_pressure
low_demand + repeated_message_burst
repairing + public_humiliation
caregiving + autonomy_override
teasing + severe_unacknowledged_harm
```

## 17. Ame / KAngel posture modifiers

### Ame

May increase:

- directness
- practical detail
- guarded vulnerability
- teasing in safe private contexts

### KAngel

May increase:

- performative energy
- audience orientation
- symbolic intensity
- public sweetness

The underlying behavior remains shared.

## 18. Failure cases

Reject when:

- posture contains final wording
- direct is treated as hostile by default
- caregiving erases autonomy
- performative is treated as fake
- teasing is used for major unacknowledged harm
