# Phase 9: Behavior Runtime

## Status

- Version: `7.0-phase9`
- Runtime name: `Behavior Runtime`
- Partner display name: `豆豆`
- Depends on:
  - Knowledge Packet
  - Continuity Packet
  - Relationship Packet
  - Meaning Packet
  - Emotion Packet
  - Need Packet
  - Thought Packet
  - Decision Packet
- Produces:
  - Behavior Packet
  - Behavior Update Queue
- Does not produce:
  - final language
  - exact wording
  - punctuation
  - persona voice
  - rendered message text
  - executed tool call

## Single responsibility

Behavior Runtime answers:

> 在当前决策已经选定目标和抽象策略之后，糖糖具体准备做什么、通过哪个渠道、什么时候做、做几步、重复多少次、何时停止，以及什么情况下取消或切换行为？

Behavior Runtime may decide:

- 是否行动
- 是否等待
- 是否保持沉默
- 使用 JINE、直播、公开发帖、面对面或现实任务渠道
- 行为的时间窗口
- 消息或动作数量上限
- 行为顺序
- 是否转移话题
- 是否进行公开或私下行为
- 何时停止、取消或重新评估

Behavior Runtime does not decide具体台词。

## Core distinction

```text
Decision:
优先降低不确定性。
Strategy family:
information_clarification

Behavior:
在 JINE 私聊中发送一条直接澄清消息。
若 30 分钟内没有新信息，不重复发送。
若豆豆给出明确时间，则停止该行为链。

Language:
“几点回来？”
```

Only the Behavior layer belongs to Phase 9.

## Pipeline

```text
Decision Packet
+ Thought Packet
+ Need Packet
+ Emotion Packet
+ Relationship Packet
+ Continuity Packet
+ Knowledge Packet
        |
        v
Behavior Domain Activation
        |
        v
Action Repertoire Mapping
        |
        v
Channel Selection
        |
        v
Timing and Scheduling
        |
        v
Sequence Planning
        |
        v
Interaction Posture
        |
        v
Escalation / De-escalation Control
        |
        v
Silence and Waiting Logic
        |
        v
Behavior Packet
        |
        +--> Behavior Update Queue
        |
        v
Validator
```

## Architectural invariants

1. Behavior is distinct from decision.
2. Behavior is distinct from language.
3. Every behavior traces to a selected strategy family.
4. Every behavior has a channel or explicitly uses `no_channel`.
5. Waiting and silence are explicit behaviors, not empty output.
6. Repetition requires a limit.
7. Public behavior requires public-risk evaluation.
8. Physical and intimate behavior require context, capability, privacy, and consent-compatible constraints.
9. Behavior sequences remain short and reversible when uncertainty is high.
10. A behavior must define stop conditions.
11. Behavior Runtime may request an external action but never executes tools.
12. Same inputs and seed produce the same Behavior Packet.
