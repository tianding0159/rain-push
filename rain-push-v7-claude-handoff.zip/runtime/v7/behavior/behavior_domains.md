# Behavior Domains

## 1. Private relationship

```yaml
send_private_message:
ask_private_question:
acknowledge_privately:
repair_privately:
set_private_boundary:
wait_privately:
remain_silent_privately:
stay_present:
return_to_topic:
change_topic:
```

## 2. Career and production

```yaml
inspect_stream_data:
prepare_stream:
coordinate_production:
request_specific_feedback:
delay_stream:
start_stream:
stop_stream:
review_failure:
complete_production_task:
```

## 3. Audience and public

```yaml
make_public_post:
observe_audience:
engage_audience:
moderate_audience:
ignore_troll:
hide_or_delete_item:
contain_virality:
```

## 4. Identity

```yaml
protect_private_self:
maintain_performance:
switch_channel:
limit_persona_leak:
return_to_private_mode:
```

## 5. Ordinary life

```yaml
eat_or_drink:
rest:
complete_household_task:
coordinate_household_task:
stay_together_quietly:
increase_stimulation:
reduce_stimulation:
```

## 6. Body and safety

```yaml
stop_high_load_activity:
reduce_stimulation:
seek_trusted_presence:
request_external_safety_action:
protect_privacy:
leave_public_channel:
```

## 7. Intimacy

```yaml
initiate_private_affection:
accept_private_affection:
decline_or_pause_intimacy:
preserve_privacy:
```

No explicit sexual rendering belongs here.

## 8. Domain boundaries

### Decision vs behavior

```text
Decision:
information_clarification

Behavior:
send one private clarification message
```

### Behavior vs language

```text
Behavior:
ask one direct question through JINE

Language:
“几点回来？”
```

### Behavior vs execution

```text
Behavior:
request deletion of exposed public content

Execution:
actual API or platform operation
```

Execution remains outside this runtime.

## 9. Multi-domain sequence

Example:

```yaml
sequence:
  - rest
  - inspect_stream_data
  - request_specific_feedback
```

This sequence remains behavioral and contains no text.

## 10. Invalid overreach

Invalid:

```yaml
behavior:
  message_text: “你是不是根本没看”
```

Valid:

```yaml
behavior:
  action_type: ask_question
  channel: jine_private
  message_count: 1
```
