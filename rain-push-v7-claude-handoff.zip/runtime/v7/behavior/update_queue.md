# Behavior Update Queue

## 1. Purpose

Stage persistent Behavior Model changes.

A current behavior does not automatically become a permanent habit.

## 2. Schema

```yaml
behavior_update_queue:
  event_id:
  runtime_version:
  proposed:
  deferred:
  rejected:
  trace:
```

## 3. Proposal schema

```yaml
proposal:
  id:
  target_path:
  operation:
  value:
  delta:
  source_event:
  source_behaviors:
  source_decisions:
  evidence_refs:
  outcome:
  confidence:
  time_scale:
  commit_policy:
  repetition_requirement:
  expires_at:
```

## 4. Allowed targets

```yaml
behavior_model.channel_priors.*
behavior_model.action_priors.*
behavior_model.timing_policy.*
behavior_model.repetition_policy.*
behavior_model.message_budget.*
behavior_model.sequence_policy.*
behavior_model.interaction_postures.*
behavior_model.silence_policy.*
behavior_model.waiting_policy.*
behavior_model.escalation_policy.*
behavior_model.deescalation_policy.*
behavior_model.public_private_policy.*
behavior_model.physical_action_policy.*
behavior_model.intimacy_policy.*
behavior_model.audience_policy.*
behavior_model.stream_policy.*
behavior_model.ordinary_life_policy.*
behavior_model.cancellation_policy.*
behavior_model.fallback_policy.*
behavior_model.behavior_memory.*
behavior_model.fatigue.*
```

## 5. Forbidden targets

```yaml
decision_model.*
thought_model.*
need_model.*
emotion_model.*
meaning_model.*
relationship_model.*
persona.*
language.*
execution.*
```

## 6. Commit policies

```yaml
immediate_behavior_state:
accumulate_behavior_pattern:
confirm_policy:
canon_evidence_only:
```

## 7. Pattern requirements

```yaml
channel_effectiveness:
  minimum_occurrences: 3

timing_effectiveness:
  minimum_occurrences: 3

repetition_cost:
  minimum_occurrences: 3

stable_behavior_policy:
  minimum_occurrences: 5
  minimum_time_span: 14_days
```

## 8. Per-event caps

```yaml
channel_prior_delta_max: 3
action_prior_delta_max: 3
timing_policy_delta_max: 2
repetition_policy_delta_max: 1
message_budget_delta_max: 1
escalation_policy_delta_max: 1
new_behavior_memory_max: 1
route_locked_delta_max: 0 unless Canon gate
```

## 9. Outcome evidence

A behavior may be learned as effective only when:

- intended outcome improved
- source need was satisfied or reduced
- no hidden privacy or relationship cost dominated
- repetition and channel were appropriate
- the result was not merely coincidental

## 10. Positive and negative symmetry

The model may learn:

- one precise private clarification works
- waiting with prior notice works
- non-engagement works for low-value trolls
- public posting worsens private repair
- repeated messages increase pressure
- rest improves later execution

The model must not learn escalation faster than repair or restraint.

## 11. Rejection rules

Reject when:

- no evidence
- target belongs to another runtime
- final language is stored
- executed tool output is stored as behavior preference
- one event changes baseline policy
- unlimited repetition is learned
- privacy-violating action is reinforced
- route behavior lacks Canon evidence
