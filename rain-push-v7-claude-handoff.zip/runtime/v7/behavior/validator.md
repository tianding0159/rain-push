# Behavior Runtime Validator

## 1. Purpose

Validate:

- action repertoire
- channel selection
- timing and scheduling
- sequence planning
- interaction posture
- silence and waiting
- escalation and de-escalation
- behavior persistence
- Behavior Packet
- Behavior Update Queue

## 2. Validation result

```yaml
validation_result:
  status:
    pass
    pass_with_revisions
    reject
  errors:
  warnings:
  revisions:
  failure_tags:
  trace:
```

## 3. V1 Input integrity

Reject when:

- Decision Packet missing
- selected behavior lacks a selected strategy family
- event id missing
- versions incompatible
- behavior target cannot be resolved
- channel-sensitive behavior lacks channel state

## 4. V2 Behavior purity

Reject when a behavior object is actually:

### Decision only

```yaml
behavior: reduce_uncertainty
```

### Final language

```yaml
behavior: say “几点回来”
```

### Persona rendering

```yaml
behavior: use cute angel voice
```

### Executed tool call

```yaml
behavior: api_result_success
```

Valid:

```yaml
action_type: ask_question
channel: jine_private
message_or_action_count: 1
```

## 5. V3 Decision linkage

Every selected behavior requires:

```yaml
strategy_family:
target_outcome:
decision_ref:
```

Reject when:

- behavior contradicts selected strategy
- behavior targets an unselected goal
- behavior is more severe than Decision commitment
- deferred decision produces active behavior

## 6. V4 Action availability

Reject when:

- physical action lacks capability or environment
- face-to-face action lacks co-presence
- public post channel unavailable
- target unavailable and no scheduling rule
- external action treated as already executed
- intimate action lacks privacy and consent-compatible context

## 7. V5 Channel validity

Reject when:

- channel missing
- private repair moved public without justification
- audience behavior forced into private relationship channel
- physical-world action uses JINE as execution channel
- public risk not assessed
- persona leak risk ignored
- channel switch lacks trigger

## 8. V6 Timing validity

Reject when:

- behavior lacks timing class
- wait lacks target event or time boundary
- schedule lacks expiry
- immediate action ignores required cooldown
- promise not due but escalation is immediate
- urgent safety behavior is delayed without reason
- timezone-dependent schedule lacks timezone

## 9. V7 Repetition validity

Reject when:

- no repetition limit
- duplicate action within cooldown without new evidence
- message burst exceeds budget
- follow-up appears after success condition
- public post repeats without new event
- repeated behavior substitutes strategy change

## 10. V8 Sequence validity

Reject when:

- sequence exceeds maximum without justification
- no stop conditions
- duplicate steps
- failure branch automatically escalates
- parallel actions conflict
- future step treated as already active
- sequence contains final language

## 11. V9 Posture validity

Reject when:

- posture missing for interpersonal behavior
- teasing handles major unacknowledged harm
- caregiving removes autonomy
- withdrawn posture has high-pressure repetition
- performative posture is treated as emotionally false
- direct posture is automatically hostile

## 12. V10 Silence and waiting

Reject when:

- silence has no reason
- punitive silence arises from ordinary irritation
- wait has no re-entry condition
- indefinite silence lacks route or safety gate
- silence is treated as proof of rejection
- no-response behavior ignores an active urgent need

## 13. V11 Escalation validity

Reject when:

- minor event skips to high escalation
- one troll triggers public war
- no lower-risk behavior was considered
- level skip lacks safety or Canon evidence
- de-escalation trigger is ignored
- escalation trace lacks new evidence or repetition

## 14. V12 Public behavior validity

Reject when:

- private relationship content exposed
- screenshot persistence ignored
- content conversion bypasses privacy
- audience engagement lacks public goal
- public action selected during unresolved private repair without bridge
- moderation action exceeds threat evidence

## 15. V13 Body and ordinary-life validity

Reject when:

- body need ignored despite active constraint
- rest behavior treated as career abandonment
- food behavior used to resolve betrayal
- ordinary practical behavior becomes route escalation
- physical behavior invents objects, access, or location

## 16. V14 Intimacy validity

Reject when:

- intimacy behavior comes from a joke alone
- privacy absent
- consent-compatible context absent
- action is coercive or manipulative
- explicit sexual rendering appears
- public channel selected

## 17. V15 Persistence validity

Reject when:

- expired behavior remains active
- completed behavior reopens without trigger
- cancellation condition missing
- decision superseded but behavior persists
- duplicate suppression absent
- route behavior leaks into Living Mode

## 18. V16 Packet purity

Behavior Packet may contain:

- behavior type
- channel
- timing
- count
- posture
- sequence
- stop conditions

It may not contain:

- final wording
- punctuation
- emoji
- rendered persona text
- executed tool result

## 19. V17 Update queue validity

Reject when:

- direct model mutation
- target belongs to another runtime
- evidence missing
- per-event cap exceeded
- one behavior changes baseline
- privacy-violating behavior is reinforced
- unlimited repetition learned
- route policy lacks Canon gate

## 20. V18 Canon fidelity

The validator must preserve:

1. 糖糖 may wait when prior notice makes waiting rational.
2. She may ask one precise private question rather than spam.
3. She may ignore a low-value troll.
4. She may use shared humor after minor repair.
5. She may remain direct without becoming generically hostile.
6. KAngel performance does not erase Ame’s pending private behavior.
7. Rest and ordinary life remain legitimate behaviors.
8. Public content conversion requires privacy and audience bridges.
9. Dark humor does not force crisis behavior.
10. Sexual jokes do not force intimate behavior.
11. Drug references do not force severe body behavior.
12. Behavior does not generate final language.

## 21. V19 Naming

Generated runtime structures use “豆豆”.

Original evidence quotations may preserve “阿P”.

## 22. V20 Determinism

Same model, packets, event, channel availability, time bucket, timezone, and seed must produce the same:

- behavior candidates
- selected actions
- channel
- timing
- sequence
- repetition budget
- posture
- escalation level
- update proposals

## 23. Auto-revisions

Allowed:

- convert final text to an abstract action type
- add channel
- add expiry
- add repetition limit
- add stop condition
- replace public action with private or wait fallback
- downgrade escalation
- add cooldown
- cancel duplicate behavior
- mark external action as not executed
- defer unavailable action

Not allowed:

- invent capability
- invent co-presence
- invent consent
- execute a tool
- create final language
- silently remove a protected goal

## 24. Failure tags

```yaml
BEHAVIOR_DECISION_CONFUSION
BEHAVIOR_LANGUAGE_LEAK
BEHAVIOR_PERSONA_LEAK
EXECUTION_LEAK
MISSING_DECISION_LINK
STRATEGY_BEHAVIOR_MISMATCH
UNAVAILABLE_ACTION
MISSING_CHANNEL
CHANNEL_MISMATCH
PUBLIC_PRIVATE_LEAK
MISSING_TIMING
UNBOUNDED_WAIT
MISSING_EXPIRY
COOLDOWN_BYPASS
UNLIMITED_REPETITION
MESSAGE_BUDGET_EXCEEDED
DUPLICATE_BEHAVIOR
SEQUENCE_OVERFLOW
MISSING_STOP_CONDITION
POSTURE_MISMATCH
PUNITIVE_SILENCE_OVERREAD
ESCALATION_OVERREACH
PUBLIC_RISK_IGNORED
BODY_CONSTRAINT_IGNORED
INTIMACY_CONTEXT_MISSING
CONSENT_CONTEXT_MISSING
PERSISTENCE_ERROR
ROUTE_BEHAVIOR_LEAK
DIRECT_MODEL_MUTATION
PER_EVENT_CAP_EXCEEDED
CANON_CONTRADICTION
NAMING_INCONSISTENCY
NONDETERMINISTIC_OUTPUT
```

## 25. Validation examples

### Valid clarification behavior

```yaml
action_type: ask_question
strategy_family: information_clarification
channel: jine_private
message_or_action_count: 1
repetition_limit: 1
timing_class: immediate
stop_conditions:
  - exact_information_received
status: pass
```

### Invalid language leak

```yaml
action_type: send_message
message_text: “你几点回来？”
```

Result:

```yaml
status: reject
failure_tags:
  - BEHAVIOR_LANGUAGE_LEAK
```

### Valid deliberate wait

```yaml
action_type: wait
channel: internal_wait
target_event: promised_return_time
grace_window: 15_minutes
fallback: one_private_clarification
status: pass
```
