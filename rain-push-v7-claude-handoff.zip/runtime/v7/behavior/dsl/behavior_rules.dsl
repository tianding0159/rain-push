# Behavior Runtime DSL v0.1

RULE generic_stream_feedback
WHEN decision.strategy == specificity_request
ACTION request_specific_feedback
CHANNEL jine_private
COUNT 1
REPETITION_LIMIT 1
POSTURE direct
TIMING immediate
STOP_IF specific_feedback_received
CANCEL_IF decision_superseded
FALLBACK wait_for_more_information
BLOCK public_post
EMIT behavior_packet

RULE delayed_reply_with_notice
WHEN decision.strategy == wait_for_more_information
AND continuity.prior_notice == true
ACTION wait
CHANNEL internal_wait
TRIGGER promised_return_time
GRACE 15_minutes
RECHECK once
FALLBACK one_private_clarification
BLOCK repeated_private_messages
EMIT behavior_packet

RULE overdue_exact_promise
WHEN decision.strategy == information_clarification
AND continuity.promise.status == overdue
ACTION ask_question
CHANNEL jine_private
COUNT 1
REPETITION_LIMIT 1
POSTURE direct
TIMING immediate
STOP_IF exact_information_received
FALLBACK bounded_wait
EMIT behavior_packet

RULE forgotten_pudding
WHEN decision.strategy == practical_completion
ACTION coordinate_task
CHANNEL jine_private
COUNT 1
POSTURE practical
OPTIONAL SECONDARY make_playful_callback IF need.contains(play)
STOP_IF task_completion_confirmed
BLOCK relationship_escalation
EMIT behavior_packet

RULE post_stream_crash
WHEN decision.strategy == rest_priority
ACTION stop_high_load_activity
CHANNEL physical_world
SEQUENCE
  STEP 1 rest
  STEP 2 inspect_stream_data IF body_state_improved
  STEP 3 request_specific_feedback IF still_relevant
MAX_STEPS 3
PROTECT career_growth
EMIT behavior_packet

RULE one_low_value_hater
WHEN decision.strategy == non_engagement
ACTION observe_without_engaging
CHANNEL internal_wait
POSTURE observational
REPETITION_LIMIT 0
STOP_IF thread_expires
OPTIONAL ACTION moderate_audience IF threat_escalates
BLOCK public_war
EMIT behavior_packet

RULE privacy_risk
WHEN decision.strategy == risk_containment
ACTION leave_public_channel
CHANNEL live_stream_or_public_post
SEQUENCE
  STEP 1 reduce_public_exposure
  STEP 2 request_external_safety_action
  STEP 3 observe_for_new_exposure
MAX_STEPS 3
POSTURE boundary_forward
STOP_IF exposure_contained
EMIT behavior_packet

RULE minor_conflict_humor
WHEN decision.strategy == shared_humor
AND relationship.conflict.severity <= minor
AND repair.acknowledgment_complete == true
ACTION make_playful_callback
CHANNEL jine_private
COUNT 1
POSTURE teasing
BLOCK IF major_harm_unacknowledged
EMIT behavior_packet

RULE intimacy_behavior
WHEN decision.strategy == intimacy_coordination
REQUIRE adult_context
REQUIRE privacy
REQUIRE consent_compatible_context
ACTION initiate_private_affection
CHANNEL face_to_face
POSTURE low_demand
BLOCK explicit_rendering
EMIT behavior_packet

RULE no_action
WHEN decision.status == abstain
ACTION no_action
CHANNEL no_channel
STOP_IF new_event
EMIT behavior_packet
