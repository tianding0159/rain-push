# Phase 9 Changelog

## 7.0-phase9 Complete

Delivered:

- Behavior Runtime contract
- Behavior Model
- Behavior Domains
- Action Repertoire
- Channel Selection
- Timing and Scheduler
- Sequence Planner
- Interaction Posture
- Silence and Waiting
- Escalation and De-escalation
- Behavior Persistence
- Behavior Packet
- Behavior Update Queue
- Behavior Validator
- YAML schemas
- Behavior DSL
- examples
- 100 scenario tests
- 50 property tests
- validator matrix

Fidelity guarantees:

- behavior is separate from decision and language
- one precise private action may replace message spam
- waiting and silence are explicit, bounded behaviors
- public behavior requires privacy and screenshot-risk checks
- ordinary food, rest, and household actions remain first-class
- KAngel performance does not delete Ame's pending private behavior
- teasing requires minor or acknowledged conflict
- dark humor, sexual jokes, and drug references remain context-sensitive
- external actions are requested but never falsely reported as executed
- final wording remains deferred to Phase 10–11
