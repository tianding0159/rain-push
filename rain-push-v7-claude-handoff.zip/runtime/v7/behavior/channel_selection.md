# Channel Selection

## 1. Purpose

Select the channel through which a behavior should occur.

Channel selection is behavioral, not linguistic.

## 2. Channel set

```yaml
jine_private:
live_stream:
public_post:
face_to_face:
physical_world:
internal_wait:
no_channel:
```

## 3. Channel score

```text
C_channel
=
0.20 * strategy_fit
+ 0.16 * privacy_fit
+ 0.14 * target_availability
+ 0.12 * relationship_fit
+ 0.10 * information_bandwidth
+ 0.08 * timing_fit
+ 0.07 * reversibility
+ 0.05 * audience_fit
+ 0.04 * continuity_fit
+ 0.04 * mode_fit
- public_risk
- persona_leak_risk
- channel_mismatch
```

## 4. JINE private

Best for:

- clarification
- specific feedback request
- private repair
- practical coordination
- relationship update
- private reassurance

Risks:

- message bursts
- repeated checking
- asynchronous ambiguity
- screenshot risk if context is not trusted

## 5. Live stream

Best for:

- audience engagement
- performance continuation
- public content
- public celebration
- controlled audience interaction

Not suitable by default for:

- private relationship repair
- direct intimacy
- exposing private conflict
- solving a precise private misunderstanding

## 6. Public post

Best for:

- audience-facing update
- symbolic public action
- platform-facing communication
- controlled content conversion

Risks:

- screenshot persistence
- context collapse
- audience amplification
- privacy leak
- later shame
- accidental relationship spillover

## 7. Face-to-face

Best for:

- high-bandwidth repair
- practical coordination
- body cues
- private affection
- shared ordinary activity

Requires physical co-presence.

## 8. Physical world

Best for:

- food
- rest
- household task
- equipment preparation
- leaving a risky environment
- body regulation

Requires capability and environment evidence.

## 9. Internal wait

Used when:

- waiting for information
- cooldown
- deliberate non-response
- promise not due
- public provocation is low-value
- body state requires delay

## 10. No channel

Used for:

- no action
- completed decision
- unavailable action
- deferred strategy without scheduling

## 11. Public-to-private switch

Required when:

- private repair appears in public context
- audience attention threatens privacy
- Ame-specific concern emerges during KAngel performance
- public ambiguity would worsen the source need

## 12. Private-to-public switch

Allowed when:

- the goal is genuinely audience-facing
- privacy check passes
- private relationship content is not exposed
- public benefit exceeds spillover risk
- Decision Packet selected audience strategy

## 13. Channel conflict

If two channels score within `0.08`, retain:

- primary channel
- fallback channel

Do not duplicate the same behavior across both unless sequence logic requires it.

## 14. Channel availability

A channel may be unavailable because:

- target offline
- stream not active
- physical co-presence absent
- public posting disabled
- external connector unavailable
- quiet-hours rule
- safety restriction

## 15. Failure cases

Reject when:

- private repair is moved public without reason
- audience strategy is forced into JINE
- physical action is selected without co-presence or capability
- no channel field exists
- channel selection contains final text
