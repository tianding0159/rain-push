# Behavior Persistence

## 1. Purpose

Control how scheduled, waiting, active, and repeated behaviors persist, expire, cancel, or reopen.

## 2. Behavior state

```yaml
behavior_state:
  behavior_id:
  status:
  started_at:
  last_attempt:
  attempt_count:
  repetition_limit:
  cooldown_until:
  expiry:
  success_condition:
  stop_conditions:
  cancel_conditions:
  reopen_triggers:
  superseded_by:
```

## 3. Persistence classes

```yaml
instant:
single_attempt:
bounded_wait:
scheduled:
multi_step:
maintenance:
route_locked:
```

## 4. Single attempt

Examples:

- one clarification message
- one public post
- one feedback request
- one practical reminder

After the attempt:

- wait
- observe
- stop
- reopen only with new event

## 5. Bounded wait

Persists until:

- target event
- grace window expiry
- new evidence
- decision supersession
- risk change

## 6. Scheduled behavior

Requires:

- start window
- expiry
- precondition
- cancellation rule

## 7. Multi-step behavior

Only the current eligible step remains active.

Future steps are pending, not assumed.

## 8. Maintenance behavior

Examples:

- audience moderation
- low-demand presence
- safety monitoring
- ordinary routine

Maintenance behavior requires periodic review.

## 9. Route-locked behavior

Requires Canon gate and Canon resolution.

## 10. Cancellation

Cancel when:

- need satisfied
- target unavailable
- channel closes
- privacy risk rises
- consent withdrawn
- body state worsens
- behavior becomes redundant
- decision changes

## 11. Supersession

A new behavior supersedes an old one only when:

- same target outcome
- stronger Decision commitment
- changed constraint
- new evidence
- explicit conflict resolution

Keep old behavior in trace.

## 12. Reopening

A completed behavior may reopen only after:

- new event
- failed follow-through
- renewed need
- repeated pattern
- explicit callback

## 13. Duplicate suppression

Suppress when:

- same action
- same target
- same channel
- same unresolved source
- within cooldown
- no new evidence

## 14. Failure cases

Reject when:

- behavior repeats without limit
- expired behavior remains active
- completed behavior reopens without trigger
- cancellation condition is missing
- duplicate suppression absent
