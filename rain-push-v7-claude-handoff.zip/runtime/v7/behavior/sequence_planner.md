# Sequence Planner

## 1. Purpose

Build a short sequence of concrete behaviors that implements the selected strategy while preserving stop conditions and protected goals.

## 2. Sequence schema

```yaml
behavior_sequence:
  sequence_id:
  steps:
  max_steps:
  parallel_allowed:
  stop_conditions:
  fallback:
  expiry:
```

## 3. Step schema

```yaml
step:
  index:
  action_type:
  channel:
  timing:
  preconditions:
  success_condition:
  stop_if:
  next_if_success:
  next_if_failure:
```

## 4. Default limits

```yaml
uncertain_low_risk: 2_steps
ordinary_practical: 3_steps
relationship_repair: 3_steps
public_behavior: 2_steps
safety: 4_steps
route_locked: Canon_defined
```

## 5. Example: clarification

```yaml
steps:
  - index: 1
    action_type: ask_question
    channel: jine_private
    repetition_limit: 1
  - index: 2
    action_type: wait
    trigger: new_information
```

No wording is included.

## 6. Example: post-stream crash

```yaml
steps:
  - rest
  - inspect_stream_data
  - request_specific_feedback
```

The second and third steps stop if body state remains poor.

## 7. Example: privacy risk

```yaml
steps:
  - leave_public_channel
  - request_external_safety_action
  - observe_for_new_exposure
```

Actual external execution remains outside runtime.

## 8. Branching

One branch may be specified for success and one for failure.

Avoid decision trees larger than four terminal paths.

## 9. Parallel behavior

Parallel behavior allowed when:

- actions do not conflict
- one action is observation
- safety monitoring occurs during containment
- practical task and low-demand presence coexist

Not allowed when:

- two messages duplicate
- public and private repair occur simultaneously
- rest and high-load performance conflict
- silence and active confrontation target the same person

## 10. Sequence cancellation

Cancel remaining steps when:

- success condition met
- decision superseded
- risk increases
- consent withdrawn
- target unavailable
- repetition budget exhausted
- channel changes incompatibly

## 11. Fallback

Fallback must be lower risk or more reversible unless safety escalation is required.

Example:

```yaml
primary: ask_question
fallback: wait_for_more_information
```

## 12. Failure cases

Reject when:

- sequence contains final language
- more than default max steps without justification
- no stop condition
- failure branch escalates automatically
- duplicate actions appear
- behavior sequence executes a tool
