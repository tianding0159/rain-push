# Action Repertoire

## 1. Purpose

Map abstract strategy families from Decision Packet into concrete behavior candidates.

A behavior candidate specifies action type, channel class, timing class, repetition limit, and stop conditions.

It does not contain final language.

## 2. Input

```yaml
decision_packet:
thought_packet:
need_packet:
emotion_packet:
relationship_packet:
continuity_packet:
knowledge_packet:
behavior_model:
```

## 3. Output

```yaml
action_repertoire:
  candidates:
  blocked:
  deferred:
  unavailable:
  trace:
```

## 4. Mapping table

### information_clarification

Candidate behaviors:

```yaml
- ask_question
- request_update
- inspect_information
- wait_for_expected_update
```

### specificity_request

```yaml
- request_specific_feedback
- ask_followup_question
- return_to_topic
```

### evidence_gathering

```yaml
- inspect_information
- inspect_metrics
- observe_without_engaging
- wait_for_event
```

### practical_completion

```yaml
- complete_practical_task
- coordinate_task
- request_task_completion
```

### collaborative_planning

```yaml
- coordinate_task
- schedule_discussion
- inspect_shared_constraints
```

### repair_invitation

```yaml
- acknowledge_issue
- request_repair_discussion
- return_to_unresolved_topic
```

### boundary_setting

```yaml
- state_boundary_behavior
- reduce_contact
- leave_public_channel
- moderate_audience
```

### distance_and_pause

```yaml
- pause_contact
- remain_silent
- change_topic
- leave_channel
```

### relationship_reassurance

```yaml
- stay_present
- acknowledge
- provide_update
- initiate_private_affection
```

### shared_humor

```yaml
- make_playful_callback
- use_inside_joke_behavior
- change_tone_after_acknowledgment
```

The actual joke wording remains Phase 10–11.

### content_conversion

```yaml
- mark_event_as_content_candidate
- prepare_public_or_stream framing
- inspect_public_risk
```

No public posting occurs until channel and risk checks pass.

### career_analysis

```yaml
- inspect_metrics
- review_failure
- compare_streams
- coordinate_production
```

### risk_containment

```yaml
- reduce_public_exposure
- leave_public_channel
- hide_or_delete_item_request
- moderate_audience
- request_external_safety_action
```

### privacy_protection

```yaml
- switch_to_private_channel
- reduce_public_detail
- remove_public_item_request
- stop_content_conversion
```

### body_regulation

```yaml
- rest
- eat_or_drink
- reduce_stimulation
- stop_high_load_activity
```

### rest_priority

```yaml
- stop_high_load_activity
- rest
- delay_nonurgent_task
```

### ordinary_routine

```yaml
- complete_household_task
- eat_or_drink
- stay_together_quietly
- follow_existing_routine
```

### audience_engagement

```yaml
- start_stream
- continue_stream
- make_public_post
- acknowledge_audience
```

### audience_distance

```yaml
- observe_without_engaging
- ignore_troll
- moderate_audience
- leave_public_channel
```

### identity_integration

```yaml
- switch_channel_deliberately
- return_to_private_mode
- preserve_private_followup
- prevent_persona_leak
```

### future_planning

```yaml
- schedule_discussion
- inspect_shared_constraints
- coordinate_task
```

### non_engagement

```yaml
- remain_silent
- ignore_troll
- observe_without_engaging
- no_action
```

## 5. Candidate schema

```yaml
candidate:
  action_type:
  source_strategy:
  target_outcome:
  eligible_channels:
  timing_class:
  repetition_limit:
  preconditions:
  stop_conditions:
  risks:
  reversibility:
  confidence:
```

## 6. Availability

A candidate is unavailable when:

- the target or channel does not exist
- required information is absent
- body or environment capability is absent
- consent-compatible context is absent
- execution requires a tool not connected
- Canon gate is missing

Unavailable is different from blocked.

## 7. Candidate diversity

For clarification strategies, consider:

- one direct private action
- one wait action
- one evidence-inspection action

For audience provocation, consider:

- non-engagement
- moderation
- observation
- public response only if justified

## 8. Repetition limits

Default:

```yaml
private_clarification: 1
private_followup: 1
public_post: 1
audience_moderation: event_based
practical_retry: 1
```

A new event may reopen the budget.

## 9. Stop conditions

Every candidate must specify at least one:

- information arrives
- need satisfied
- deadline passes
- risk rises
- target becomes unavailable
- repetition limit reached
- topic changes
- decision superseded

## 10. Failure cases

Reject when:

- strategy maps directly to final text
- candidate lacks stop conditions
- unlimited repetition
- unavailable action is treated as executable
- public action bypasses risk check
- physical action lacks capability evidence
