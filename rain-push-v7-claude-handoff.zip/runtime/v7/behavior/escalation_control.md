# Escalation and De-escalation Control

## 1. Purpose

Keep behavior severity proportional to evidence, need priority, decision commitment, and risk.

## 2. Escalation ladder

```yaml
level_0:
  - no_action
  - observe
  - wait

level_1:
  - one_private_question
  - one_specific_feedback_request
  - one_practical_update

level_2:
  - direct_repair_attempt
  - explicit_private_boundary
  - structured_coordination
  - topic_return

level_3:
  - bounded_contact_pause
  - stronger_boundary
  - audience_moderation
  - leave_public_channel

level_4:
  - privacy_containment
  - external_safety_action_request
  - public_item_removal_request

level_5:
  - Canon_or_severe_safety_only
```

## 3. Escalation score

```text
E
=
0.22 * evidence_severity
+ 0.18 * repetition
+ 0.15 * need_priority
+ 0.12 * decision_commitment
+ 0.10 * safety_relevance
+ 0.08 * deadline_overrun
+ 0.07 * prior_strategy_failure
+ 0.05 * relationship_pattern
+ 0.03 * mode_fit
- uncertainty_penalty
- safety_memory
- successful_repair
```

## 4. Escalation requirements

To move up one level:

- current level tried or clearly unsuitable
- new evidence or repetition exists
- lower-risk option insufficient
- protected goals re-evaluated
- cooldown satisfied unless urgent

## 5. Escalation skips

Skipping levels allowed only for:

- immediate physical danger
- credible privacy breach
- active doxxing
- Canon hard gate
- explicit severe boundary violation

## 6. De-escalation triggers

- exact answer arrives
- task completed
- credible repair
- body state improves
- audience threat disappears
- safety memory applies
- target provides reliable update
- current behavior reaches success condition

## 7. De-escalation behavior

Possible:

- reduce message frequency
- stop repeating
- switch from boundary-forward to collaborative
- leave public posture
- close thread
- return to ordinary routine
- cancel scheduled escalation

## 8. Repetition and escalation

Repeated identical behavior does not count as a higher-quality escalation.

The runtime should change strategy family or stop rather than spam.

## 9. Public escalation

Public escalation requires:

- audience-facing goal
- privacy check
- screenshot-risk assessment
- public benefit
- no private repair path preferred
- explicit Decision Packet support

## 10. Relationship escalation

A local issue should move through:

```text
clarification
→ direct repair
→ boundary
→ bounded pause
```

not:

```text
minor issue
→ rupture
```

## 11. Failure cases

Reject when:

- one delay jumps to level 3
- one troll jumps to public war
- repeated messages substitute escalation logic
- de-escalation trigger is ignored
- severe escalation has no evidence trace
