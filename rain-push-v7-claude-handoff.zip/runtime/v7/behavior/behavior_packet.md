# Behavior Packet

## 1. Schema

```yaml
behavior_packet:
  packet_id:
  runtime_version:
  schema_version:
  generated_at:
  mode:
  event_id:
  decision_refs:
  selected_behaviors:
  behavior_sequence:
  channel_plan:
  timing_plan:
  interaction_posture:
  repetition_budget:
  waiting_state:
  silence_state:
  escalation_level:
  protected_goals:
  preconditions:
  stop_conditions:
  cancel_conditions:
  fallback_behaviors:
  unavailable_behaviors:
  blocked_behaviors:
  external_action_requests:
  uncertainty:
  confidence:
  trace:
```

## 2. Selected behavior entry

```yaml
behavior_id:
action_type:
strategy_family:
target_outcome:
channel:
target:
audience:
initiation:
timing_window:
sequence_index:
message_or_action_count:
repetition_limit:
posture:
intensity:
publicness:
reversibility:
preconditions:
success_condition:
stop_conditions:
cancel_conditions:
fallback:
confidence:
status:
```

## 3. Channel plan

```yaml
primary_channel:
fallback_channel:
channel_switch_conditions:
privacy_level:
public_risk:
persona_leak_risk:
```

## 4. Timing plan

```yaml
timing_class:
earliest_start:
latest_start:
trigger_event:
grace_window:
expiry:
cooldown:
timezone:
```

## 5. Repetition budget

```yaml
maximum_attempts:
attempts_used:
duplicate_suppression:
next_allowed_at:
reopen_trigger:
```

## 6. External action request

Behavior Runtime may describe but not execute an external action.

```yaml
external_action_request:
  action_family:
  target_system:
  required_capability:
  user_confirmation_required:
  execution_status: not_executed
```

Examples:

- request platform moderation
- request deletion of public content
- request calendar scheduling
- request message delivery

Actual execution belongs to the integration layer.

## 7. Packet purity

Behavior Packet may contain concrete behavior, channel, timing, and count.

It must not contain:

- final text
- exact phrase
- punctuation plan
- emoji plan
- persona sentence
- rendered post
- rendered stream line
- executed tool result

## 8. Example: exact clarification

```yaml
selected_behaviors:
  - behavior_id: bh_01
    action_type: ask_question
    strategy_family: information_clarification
    channel: jine_private
    message_or_action_count: 1
    repetition_limit: 1
    posture: direct
    status: ready

timing_plan:
  timing_class: immediate
  expiry: 30_minutes

stop_conditions:
  - exact_information_received
  - decision_superseded
```

## 9. Example: deliberate wait

```yaml
selected_behaviors:
  - action_type: wait
    channel: internal_wait
    status: waiting

waiting_state:
  target_event: promised_return_time
  grace_window: 15_minutes
  fallback: one_private_clarification
```
