# Timing and Scheduler

## 1. Purpose

Choose when a behavior should begin, how long it remains valid, and what event cancels or reschedules it.

## 2. Timing classes

```yaml
immediate:
short_delay:
scheduled_window:
wait_until_event:
after_channel_transition:
after_acknowledgment:
after_body_regulation:
no_schedule:
```

## 3. Timing schema

```yaml
timing:
  class:
  earliest_start:
  latest_start:
  expected_duration:
  trigger_event:
  grace_window:
  expiry:
  cooldown:
  timezone:
  confidence:
```

## 4. Immediate

Appropriate when:

- safety or privacy risk active
- exact deadline passed
- body need urgent
- current information is sufficient
- delay would materially increase harm

Immediate does not mean impulsive.

## 5. Short delay

Appropriate when:

- emotion pressure high but not urgent
- public posting needs cooldown
- private message can benefit from brief regulation
- the target is temporarily unavailable

Default ranges:

```yaml
private_low_risk: 2_to_15_minutes
public_post_cooldown: 15_to_60_minutes
post_stream_private_transition: 5_to_30_minutes
```

These are defaults, not fixed rules.

## 6. Scheduled window

Appropriate when:

- task coordination is needed
- stream preparation has a deadline
- future planning requires shared availability
- a nonurgent repair needs a better channel

## 7. Wait until event

Required fields:

```yaml
trigger_event:
grace_window:
stop_condition:
reconsideration_trigger:
```

Examples:

- wait until promised return time
- wait until stream ends
- wait until new metric arrives
- wait until body state improves

## 8. Deadline logic

```yaml
before_due:
  prefer_wait_or_prepare
at_due:
  allow_low_cost_check
after_due:
  allow_clarification
repeated_overdue:
  allow_repair_or_boundary
```

## 9. Cooldown

Cooldown prevents:

- repeated private messages
- rapid public posting
- escalating moderation actions
- repeated requests after a clear answer
- emotional whiplash across channels

## 10. Expiry

A scheduled behavior expires when:

- need already satisfied
- decision superseded
- topic changed
- target unavailable beyond window
- risk profile changed
- channel closed

## 11. Time-of-day modifiers

Deep night may:

- delay nonurgent public posting
- favor private low-demand behavior
- increase body-rest priority
- preserve Canon callback timing

Time alone cannot create severe behavior.

## 12. Determinism

Timing must be deterministic given:

- current time bucket
- timezone
- policy
- seed
- event deadlines

## 13. Failure cases

Reject when:

- no expiry
- wait has no trigger
- exact timing is invented without policy
- immediate escalation ignores cooldown
- body danger is delayed without reason
- public posting ignores screenshot persistence
