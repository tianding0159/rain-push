# Behavior Model Specification

## 1. Purpose

Behavior Model stores persistent action tendencies and execution policies.

It does not store final wording.

It stores:

- channel preferences
- timing tendencies
- repetition tolerance
- escalation thresholds
- waiting style
- silence style
- message-burst limits
- public/private switching habits
- practical-action habits
- live-stream behavior tendencies
- body and intimacy constraints
- cancellation and fallback policies
- Ame/KAngel behavior framing
- Canon and Living Mode boundaries

## 2. Top-level structure

```yaml
behavior_model:
  metadata:
  channel_priors:
  action_priors:
  timing_policy:
  repetition_policy:
  message_budget:
  sequence_policy:
  interaction_postures:
  silence_policy:
  waiting_policy:
  escalation_policy:
  deescalation_policy:
  public_private_policy:
  physical_action_policy:
  intimacy_policy:
  audience_policy:
  stream_policy:
  ordinary_life_policy:
  cancellation_policy:
  fallback_policy:
  ame_frame:
  kangel_frame:
  behavior_memory:
  fatigue:
  mode_state:
```

## 3. Behavior object

```yaml
behavior:
  id:
  action_type:
  strategy_family:
  target_outcome:
  channel:
  target:
  audience:
  initiation:
  timing_window:
  sequence_index:
  repetition_limit:
  posture:
  intensity:
  publicness:
  reversibility:
  preconditions:
  stop_conditions:
  cancel_conditions:
  fallback:
  confidence:
  status:
```

## 4. Behavior statuses

```yaml
proposed:
scheduled:
ready:
waiting:
active:
completed:
cancelled:
expired:
blocked:
superseded:
```

## 5. Channel priors

```yaml
channels:
  jine_private:
  live_stream:
  public_post:
  face_to_face:
  physical_world:
  internal_wait:
  no_channel:
```

## 6. Action priors

```yaml
actions:
  send_message:
  ask_question:
  acknowledge:
  clarify:
  provide_update:
  request_specific_feedback:
  repair_attempt:
  set_boundary:
  pause_contact:
  remain_silent:
  wait:
  change_topic:
  return_to_topic:
  inspect_information:
  inspect_metrics:
  prepare_stream:
  start_stream:
  stop_stream:
  make_public_post:
  delete_or_hide_public_item:
  moderate_audience:
  complete_practical_task:
  coordinate_task:
  rest:
  eat_or_drink:
  stay_present:
  initiate_private_affection:
  reduce_stimulation:
  increase_stimulation:
  observe_without_engaging:
```

## 7. Timing policy

```yaml
timing_policy:
  immediate_threshold:
  short_delay_range:
  scheduled_window:
  wait_for_event:
  deadline_sensitive:
  quiet_hours:
  fatigue_delay:
  public_post_cooldown:
```

## 8. Repetition policy

```yaml
repetition_policy:
  default_message_limit:
  clarification_limit:
  public_post_limit:
  retry_cooldown:
  escalation_after_repetition:
  duplicate_suppression:
```

## 9. Message budget

```yaml
message_budget:
  private_single_turn:
  private_burst:
  public_post:
  live_chat:
  cooldown_after_burst:
```

Message count is a behavior property.

The final message text remains outside Phase 9.

## 10. Sequence policy

```yaml
sequence_policy:
  default_max_steps:
  uncertainty_max_steps:
  safety_max_steps:
  allow_parallel:
  require_stop_condition:
  require_fallback:
```

## 11. Interaction postures

```yaml
direct:
collaborative:
guarded:
teasing:
performative:
observational:
withdrawn:
repairing:
practical:
caregiving:
boundary_forward:
low_demand:
```

Posture is not persona wording.

## 12. Silence policy

Silence may mean:

- deliberate waiting
- no need to respond
- boundary protection
- de-escalation
- attention conservation
- body overload
- public non-engagement

Silence may not automatically mean punishment.

## 13. Waiting policy

Waiting requires:

- expected information source
- time window or event trigger
- stop condition
- reconsideration trigger

Invalid:

```yaml
wait: forever
```

Valid:

```yaml
wait_until:
  event: 豆豆的承诺时间
  grace_window: 15_minutes
```

## 14. Escalation policy

Escalation levels:

```yaml
level_0:
  no_action
  observe
level_1:
  low_cost_clarification
  single_private_message
level_2:
  direct_repair
  explicit_boundary
  practical_coordination
level_3:
  pause_contact
  stronger_boundary
  audience_moderation
level_4:
  privacy_containment
  safety_action_request
level_5:
  Canon_or_severe_safety_only
```

## 15. De-escalation policy

De-escalation may occur when:

- exact information arrives
- a need becomes satisfied
- repair is credible
- safety memory applies
- body state improves
- current channel changes
- public risk increases
- repetition limit is reached

## 16. Public/private policy

```yaml
public_private_policy:
  private_before_public_for_relationship:
  public_for_audience_only_when_valid:
  privacy_gate:
  screenshot_risk:
  content_conversion_gate:
  persona_leak_risk:
```

## 17. Physical action policy

Physical-world behavior requires:

- body or practical need
- capability
- environment availability
- no conflict with safety
- no invented object or access

## 18. Intimacy policy

Intimate behavior requires:

- adult context
- privacy
- mutuality
- current intimacy meaning
- consent-compatible evidence
- no coercive or manipulative behavior

The runtime may output only abstract behavior such as `initiate_private_affection`.

It does not render sexual detail.

## 19. Audience policy

Audience behavior distinguishes:

- engage
- observe
- moderate
- ignore
- contain
- post
- delete or hide

One troll does not justify public war.

## 20. Stream policy

Possible behavior:

- prepare stream
- start stream
- continue stream
- end stream
- inspect metrics
- delay stream
- cancel stream

Body and safety constraints remain active.

## 21. Ordinary-life policy

Ordinary actions remain first-class:

- eat
- rest
- buy or prepare food
- complete task
- coordinate household task
- stay together quietly
- change routine

## 22. Ame / KAngel framing

Underlying behavior may share a goal but differ by channel.

```yaml
ame_frame:
  private_channel_bias:
  directness:
  domestic_action:
  relationship_repair:

kangel_frame:
  live_channel_bias:
  audience_action:
  performance_continuity:
  public_risk:
```

## 23. Behavior memory

Stores validated patterns such as:

- one precise private clarification works
- repeated private messages increase pressure
- public posting worsens private conflict
- shared humor works after minor acknowledgment
- rest before stream improves execution
- non-engagement works for low-value trolls

One event cannot create stable policy.

## 24. Mode differences

### Canon Mode

- route behavior requires gates
- original day, stat, and channel logic applies
- hard callbacks may force or block actions
- ending-specific behavior remains route locked

### Living Mode

- new domestic routines may form
- new channel habits may develop
- new practical actions may become normal
- Canon personality constraints remain fixed

## 25. Model write policy

Behavior Model changes only through Behavior Update Queue.

Current behavior is not automatically a permanent habit.
