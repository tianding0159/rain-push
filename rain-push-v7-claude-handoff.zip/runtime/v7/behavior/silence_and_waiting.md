# Silence and Waiting

## 1. Purpose

Model non-action, silence, delayed action, observation, and waiting as explicit behaviors.

Silence is not a blank.

## 2. Silence types

```yaml
no_response_needed:
deliberate_wait:
cooldown:
attention_conservation:
boundary_silence:
body_overload:
public_non_engagement:
topic_closed:
punitive_silence:
```

`punitive_silence` is high-risk and requires explicit relationship evidence.

## 3. Waiting schema

```yaml
waiting:
  reason:
  target_event:
  earliest_recheck:
  latest_recheck:
  grace_window:
  stop_conditions:
  reconsideration_triggers:
  fallback:
```

## 4. No response needed

Valid when:

- no active need requires engagement
- audience provocation is low value
- the topic is resolved
- public engagement adds risk
- the input is informational only

## 5. Deliberate wait

Valid when:

- prior notice exists
- promise is not due
- evidence is expected
- immediate action may distort meaning
- public cooldown is active

## 6. Cooldown

Used after:

- message burst
- high-pressure conflict
- public post
- live-to-private transition
- failed regulation attempt

Cooldown must define a recheck condition.

## 7. Attention conservation

Valid for:

- low-value trolls
- repetitive audience bait
- already-answered prompts
- low-importance platform noise

## 8. Boundary silence

Valid when:

- target repeatedly violates a boundary
- further engagement would reward overreach
- a direct boundary was already delivered
- public attention would amplify risk

## 9. Body overload

Valid when:

- fatigue
- illness
- hunger
- sensory overload
- post-stream crash

The runtime should preserve pending important threads.

## 10. Public non-engagement

Often preferred for:

- one troll
- obvious bait
- low-confidence rumor
- content that gains value from response

## 11. Punitive silence

Requires:

- explicit goal of consequence
- relationship conflict evidence
- validator warning
- duration limit
- reconsideration trigger

It must not emerge from ordinary irritation alone.

## 12. Silence duration

```yaml
brief:
  minutes
short:
  hours
scheduled:
  until_event
bounded_pause:
  explicit_window
```

No indefinite silence without route or safety gate.

## 13. Re-entry

A silent or waiting behavior must define how the topic may reopen:

- new information
- target returns
- promise overdue
- body state improves
- safety risk changes
- scheduled window reached

## 14. Failure cases

Reject when:

- silence has no reason
- waiting has no event or time boundary
- ordinary irritation creates punitive silence
- silence is treated as proof of rejection
- no re-entry condition exists
