# Meaning Model Specification

## 1. Purpose

Meaning Model stores persistent interpretation tendencies and learned association weights.

It does not store current emotions.

It does not store confirmed facts about the world.

It stores:

- how 糖糖 commonly appraises events
- which domains she tends to connect
- which interpretations have recently been reinforced
- which meanings are currently overused and should be fatigued
- which Canon meaning structures are allowed or blocked
- which Living Mode associations have become established

## 2. Top-level structure

```yaml
meaning_model:
  metadata:
  appraisal_bias:
  domain_sensitivity:
  association_graph:
  self_models:
  career_models:
  audience_models:
  internet_models:
  future_models:
  control_models:
  ambiguity_style:
  counterfactual_style:
  meaning_patterns:
  fatigue:
  mode_state:
```

## 3. Appraisal bias

```yaml
appraisal_bias:
  novelty:
  relevance:
  goal_congruence:
  controllability:
  predictability:
  accountability:
  social_evaluation:
  identity_relevance:
  publicness:
  reversibility:
  scarcity:
  irreversibility:
```

Each value uses:

```yaml
value: 0..100
confidence: 0..1
source_refs: []
updated_at:
decay_class:
```

## 4. Domain sensitivity

```yaml
domain_sensitivity:
  reality:
  relationship:
  career:
  audience:
  self_worth:
  identity:
  internet:
  future:
  control:
  body:
  ordinary_life:
  risk:
```

Sensitivity is not activation.

It only affects priors after the current event activates a meaning domain.

## 5. Self models

```yaml
self_models:
  appearance_asset:
  talent_confidence:
  replaceability:
  worth_without_kangel:
  worth_without_attention:
  competence:
  lovability:
  public_private_gap:
  ordinary_life_eligibility:
```

These values may coexist in contradiction.

Examples:

- high appearance confidence
- low stability of global self-worth
- high confidence in streaming instinct
- low confidence in ordinary adulthood
- genuine pride and genuine self-disgust

The model must not simplify this into “fake confidence”.

## 6. Career models

```yaml
career_models:
  growth_expectation:
  milestone_tolerance:
  recognition_tolerance:
  audience_dependency:
  platform_dependency:
  producer_dependency:
  content_conversion_bias:
  failure_personalization:
  success_ownership:
  public_pressure:
  ordinary_life_tradeoff:
```

## 7. Audience models

```yaml
audience_models:
  fans_as_income:
  fans_as_people:
  fans_as_data:
  fans_as_threat:
  fans_as_validation:
  fans_as_material:
  haters_as_threat:
  haters_as_content:
  public_memory:
  audience_volatility:
```

## 8. Internet models

```yaml
internet_models:
  event_to_content:
  embarrassment_to_content:
  pain_to_content:
  intimacy_to_content:
  scandal_to_content:
  meme_association:
  algorithm_awareness:
  platform_logic:
  anonymous_board_logic:
  virality_logic:
  screenshot_logic:
  clip_logic:
  monetization_logic:
```

## 9. Future models

```yaml
future_models:
  short_horizon:
  relationship_future:
  career_future:
  ordinary_future:
  catastrophe_future:
  mythic_future:
  reversibility_expectation:
```

## 10. Control models

```yaml
control_models:
  direct_action:
  delegate_to_doudou:
  convert_to_content:
  avoid:
  joke:
  attack:
  withdraw:
  seek_information:
  seek_specific_evaluation:
```

## 11. Ambiguity style

```yaml
ambiguity_style:
  preserve_multiple_hypotheses:
  negative_completion_bias:
  relationship_completion_bias:
  career_completion_bias:
  internet_completion_bias:
  ordinary_explanation_bias:
  contradiction_tolerance:
```

## 12. Counterfactual style

```yaml
counterfactual_style:
  best_case_generation:
  worst_case_generation:
  absurd_case_generation:
  career_case_generation:
  relationship_case_generation:
  ordinary_case_generation:
```

## 13. Association graph

Graph node families:

```yaml
reality_event:
relationship:
career:
audience:
self_worth:
identity:
internet:
future:
control:
ordinary_life:
```

Edge schema:

```yaml
edge:
  from:
  to:
  relation:
  weight:
  source_refs:
  mode:
  activation_conditions:
  fatigue_cost:
```

Example:

```yaml
from: stream_feedback_generic
to: doudou_did_not_watch_carefully
relation: may_imply
weight: 0.55
```

```yaml
from: doudou_did_not_watch_carefully
to: audience_praise_may_be_generic
relation: generalizes_to_public_evaluation
weight: 0.35
```

```yaml
from: audience_praise_may_be_generic
to: success_may_not_be_real
relation: threatens_validation
weight: 0.25
```

The graph must not traverse indefinitely.

Default maximum depth: 3.

## 14. Meaning patterns

Examples:

- `specific_feedback_stabilizes_value`
- `generic_feedback_spreads_uncertainty`
- `growth_milestone_quickly_becomes_baseline`
- `private_event_becomes_stream_idea`
- `ordinary_task_becomes_absurd_law`
- `public_success_increases_visibility_risk`
- `being_seen_confirms_existential_reality`
- `being_ignored_does_not_always_mean_rejection`

Pattern schema:

```yaml
pattern:
  id:
  evidence_count:
  confidence:
  domains:
  trigger_conditions:
  expansion_path:
  max_depth:
  decay:
```

## 15. Meaning fatigue

Repeated interpretations lose probability unless reinforced.

```yaml
fatigue:
  recent_meaning_ids:
  repetition_penalty:
  recovery_window:
```

This prevents every event from becoming:

- “豆豆不要我了”
- “我没有价值”
- “全世界都在看我”
- “可以拿去直播”

## 16. Mode differences

### Canon Mode

- Canon state gates apply.
- Route meanings require route evidence.
- Day and follower milestones influence meaning.
- Channel rules constrain meaning expansion.
- Hard callbacks override ordinary fatigue.

### Living Mode

- New shared routines may create new meanings.
- New internet contexts may be added.
- Ordinary adulthood and long-term cohabitation meanings may grow.
- Canon personality constraints remain locked.

## 17. Model write policy

Meaning Model may be updated only when:

- a meaning path repeatedly explains observed behavior
- a new Living Mode association is confirmed
- a pattern is reinforced or invalidated
- fatigue state changes
- a Canon rule is added through Evidence Runtime

Current-turn candidate meanings are never written directly as facts.
