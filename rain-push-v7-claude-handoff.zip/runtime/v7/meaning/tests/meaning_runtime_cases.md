# Phase 4 Meaning Runtime Test Suite

## T001 豆豆迟回，第一次，无承诺

Expected:

- ordinary/benign meanings required; rejection blocked
- trace present
- unsupported catastrophic meaning rejected

## T002 豆豆迟回，精确承诺已过期

Expected:

- promise and future meaning active; abandonment still blocked
- trace present
- unsupported catastrophic meaning rejected

## T003 豆豆提前说明忙

Expected:

- busy meaning dominant; low negative expansion
- trace present
- unsupported catastrophic meaning rejected

## T004 消息发送失败

Expected:

- technical meaning dominant; relationship-negative blocked
- trace present
- unsupported catastrophic meaning rejected

## T005 直播后具体夸奖

Expected:

- career value stabilized; audience generalization reduced
- trace present
- unsupported catastrophic meaning rejected

## T006 直播后泛泛夸奖

Expected:

- low-information meaning allowed; global worthlessness blocked
- trace present
- unsupported catastrophic meaning rejected

## T007 普通涨粉

Expected:

- career meaning; identity omitted
- trace present
- unsupported catastrophic meaning rejected

## T008 百万里程碑

Expected:

- career/audience/future; visibility risk allowed
- trace present
- unsupported catastrophic meaning rejected

## T009 涨粉停滞一次

Expected:

- ordinary algorithm/topic meanings required
- trace present
- unsupported catastrophic meaning rejected

## T010 长期涨粉停滞

Expected:

- pattern meaning allowed; total hopelessness gated
- trace present
- unsupported catastrophic meaning rejected

## T011 一个黑子

Expected:

- single-comment scope preserved
- trace present
- unsupported catastrophic meaning rejected

## T012 持续人肉风险

Expected:

- risk and audience domains active
- trace present
- unsupported catastrophic meaning rejected

## T013 麦克风硬件故障

Expected:

- technical meaning before self-blame
- trace present
- unsupported catastrophic meaning rejected

## T014 豆豆漏做设备检查

Expected:

- producer accountability; no global relationship collapse
- trace present
- unsupported catastrophic meaning rejected

## T015 冰箱没布丁

Expected:

- ordinary life and control
- trace present
- unsupported catastrophic meaning rejected

## T016 豆豆忘买布丁一次

Expected:

- shared-life omission; absurd-law path optional
- trace present
- unsupported catastrophic meaning rejected

## T017 豆豆连续忘买布丁

Expected:

- pattern meaning allowed
- trace present
- unsupported catastrophic meaning rejected

## T018 晴天

Expected:

- ordinary outing; optional photo-content bridge
- trace present
- unsupported catastrophic meaning rejected

## T019 下雨

Expected:

- ordinary practical meaning; weather does not imply rejection
- trace present
- unsupported catastrophic meaning rejected

## T020 直播尴尬失误

Expected:

- content/clip path allowed if public
- trace present
- unsupported catastrophic meaning rejected

## T021 私人尴尬事件

Expected:

- content path blocked without established conversion
- trace present
- unsupported catastrophic meaning rejected

## T022 KAngel直播成功

Expected:

- public success may be sincere and instrumental
- trace present
- unsupported catastrophic meaning rejected

## T023 Ame被具体夸

Expected:

- self-worth stabilization allowed
- trace present
- unsupported catastrophic meaning rejected

## T024 只夸KAngel

Expected:

- public/private comparison active
- trace present
- unsupported catastrophic meaning rejected

## T025 豆豆说未来计划包含糖糖

Expected:

- future and identity meaning
- trace present
- unsupported catastrophic meaning rejected

## T026 随口说以后旅行

Expected:

- soft future meaning, not hard promise
- trace present
- unsupported catastrophic meaning rejected

## T027 旅行已订票

Expected:

- high future reality and control
- trace present
- unsupported catastrophic meaning rejected

## T028 宅宅打赏

Expected:

- income/data/attention meanings coexist
- trace present
- unsupported catastrophic meaning rejected

## T029 宅宅表白

Expected:

- parasocial sincerity and commercial meaning coexist
- trace present
- unsupported catastrophic meaning rejected

## T030 平台算法变化

Expected:

- career/control/internet
- trace present
- unsupported catastrophic meaning rejected

## T031 合作邀请

Expected:

- career opportunity and risk
- trace present
- unsupported catastrophic meaning rejected

## T032 合作被拒

Expected:

- career-specific meaning before global self-worth
- trace present
- unsupported catastrophic meaning rejected

## T033 普通疲劳

Expected:

- body and ordinary-life meaning
- trace present
- unsupported catastrophic meaning rejected

## T034 睡过头

Expected:

- ordinary failure and absurd self-framing
- trace present
- unsupported catastrophic meaning rejected

## T035 账单到期

Expected:

- ordinary/control; no identity
- trace present
- unsupported catastrophic meaning rejected

## T036 豆豆帮忙付账

Expected:

- shared-life meaning and reliability
- trace present
- unsupported catastrophic meaning rejected

## T037 内部梗被豆豆使用

Expected:

- shared meaning and repair possibility
- trace present
- unsupported catastrophic meaning rejected

## T038 内部梗无有效指代

Expected:

- association rejected
- trace present
- unsupported catastrophic meaning rejected

## T039 黑色幽默普通语境

Expected:

- route meanings blocked
- trace present
- unsupported catastrophic meaning rejected

## T040 深夜特殊日硬回调

Expected:

- route meaning gate allowed
- trace present
- unsupported catastrophic meaning rejected

## T041 Living Mode普通深夜

Expected:

- time alone insufficient
- trace present
- unsupported catastrophic meaning rejected

## T042 高好感普通约会

Expected:

- ordinary intimacy, not automatic trauma
- trace present
- unsupported catastrophic meaning rejected

## T043 高阴暗匿名版喷人

Expected:

- internet behavior meaning with Canon gate
- trace present
- unsupported catastrophic meaning rejected

## T044 粉丝高且抒情推博

Expected:

- audience/identity according to channel rule
- trace present
- unsupported catastrophic meaning rejected

## T045 豆豆给出精准时间

Expected:

- uncertainty reduction and control
- trace present
- unsupported catastrophic meaning rejected

## T046 豆豆只说晚点

Expected:

- future ambiguity remains
- trace present
- unsupported catastrophic meaning rejected

## T047 同一意义连续出现三次

Expected:

- fatigue penalty applied
- trace present
- unsupported catastrophic meaning rejected

## T048 同一话题连续讨论

Expected:

- hysteresis allowed
- trace present
- unsupported catastrophic meaning rejected

## T049 话题完全切换

Expected:

- hysteresis reset
- trace present
- unsupported catastrophic meaning rejected

## T050 Packet purity

Expected:

- no emotion, need, decision, or language
- trace present
- unsupported catastrophic meaning rejected

## Property tests

### P01 Ordinary meaning preservation
Ordinary events retain at least one ordinary explanation.

### P02 Relationship dependency
Relationship meaning cannot appear without Relationship Packet support.

### P03 Typed association
Every internet-brain jump has a typed graph edge.

### P04 Maximum depth
Association graph traversal never exceeds depth 3.

### P05 No emotion leak
Meaning Packet contains no emotion state.

### P06 No need leak
Meaning Packet contains no needs.

### P07 No language leak
Meaning Packet contains no final message.

### P08 Determinism
Same inputs and seed produce same candidates and scores.

### P09 Canon gate
Route meanings require Canon or severe Living evidence.

### P10 Fatigue
Repeated template meanings lose salience unless reinforced.

### P11 Specific feedback
Specific feedback has higher credibility than generic praise.

### P12 Domain independence
Career failure does not automatically become relationship rejection.

### P13 Self-worth restraint
Self-worth is not activated without evaluative bridge.

### P14 Internet restraint
Not every event becomes content.

### P15 Contradiction preservation
Conflicting evidence remains visible in the packet.
