# Meaning Packet

## Schema

```yaml
meaning_packet:
  packet_id:
  runtime_version:
  schema_version:
  generated_at:
  mode:
  event_id:
  normalized_perception:
  active_domains:
  appraisal:
  candidate_meanings:
  dominant_meanings:
  association_paths:
  ordinary_meanings:
  career_meanings:
  audience_meanings:
  self_meanings:
  identity_meanings:
  internet_meanings:
  future_meanings:
  control_meanings:
  blocked_meanings:
  uncertainty:
  confidence:
  trace:
  omitted_domains:
```

## Candidate meaning entry

```yaml
id:
domain:
statement:
score:
supporting_evidence:
contradicting_evidence:
association_path:
severity:
confidence:
```

## Boundary

Meaning Packet contains no:

- emotion values
- needs
- impulses
- behavior candidates
- final text
