# Meaning Domain Activation

## Domain registry

```yaml
reality:
relationship:
career:
audience:
self_worth:
identity:
internet:
future:
control:
ordinary_life:
body:
risk:
```

## Activation input

```yaml
normalized_perception:
relationship_packet:
knowledge_packet:
continuity_packet:
meaning_model:
```

## Activation rules

### Reality

Activate when:

- event changes an observable state
- an action succeeds or fails
- a resource appears or disappears
- a schedule changes
- a technical condition changes

### Relationship

Activate only from Relationship Packet.

Meaning Runtime may not independently invent relationship activation.

### Career

Activate when:

- stream
- followers
- sponsorship
- collaboration
- platform
- production
- public recognition
- moderation
- channel growth

### Audience

Activate when:

- comments
- viewers
- followers
- haters
- public reaction
- recognition
- clipping
- virality
- parasocial behavior

### Self-worth

Activate when:

- explicit evaluation
- comparison
- success or failure tied to self
- Ame / KAngel value contrast
- appearance or competence judgment
- repeated lack of recognition

Do not activate for every neutral event.

### Identity

Activate when:

- Ame / KAngel boundary
- public/private self
- “we” or future identity
- mythic angel framing
- existential reality
- major milestone
- route-supported dissolution

### Internet

Activate when:

- event can plausibly map to content, meme, platform logic, virality, anonymous board, screenshot, clip, monetization
- current context already contains an internet bridge

### Future

Activate when:

- promise
- plan
- forecast
- trajectory
- milestone
- irreversible consequence

### Control

Activate when:

- event contains an actionable problem
- uncertainty can be reduced
- a task can be delegated
- content conversion is available
- avoidance or attack is considered

### Ordinary life

Activate by default for:

- food
- sleep
- shopping
- chores
- travel
- home
- money
- leisure
- weather

### Body

Activate for:

- sleep debt
- hunger
- illness
- appearance
- physical intimacy
- bodily discomfort

### Risk

Activate for:

- privacy
- stalking
- platform sanction
- financial danger
- medical danger
- route-critical evidence

## Activation budget

Default maximum active meaning domains: 7.

At least one of these must remain available for ordinary events:

- reality
- ordinary_life
- control

This prevents automatic crisis abstraction.

## Block rules

Block self-worth when:

- event has no evaluative bridge
- meaning would require unsupported generalization

Block identity when:

- no identity or milestone evidence exists

Block risk when:

- only dark wording is present
- no actual risk cue exists

Block internet when:

- no plausible content/platform bridge exists
- event is purely private and non-transferable
