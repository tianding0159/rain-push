# Meaning Runtime DSL v0.1

RULE generic_stream_praise
WHEN relationship.dominant_meaning == generic_feedback
ACTIVATE career 0.85
ACTIVATE self_worth 0.55
ACTIVATE audience 0.40
INTERPRET doudou_may_not_have_watched_carefully
INTERPRET praise_may_be_low_information
BLOCK global_worthlessness
REQUIRE ordinary_meaning
EMIT meaning_packet

RULE good_weather
WHEN event.primary == external
AND event.subclass == weather
ACTIVATE ordinary_life 0.90
ACTIVATE control 0.70
OPTIONAL internet IF graph.has_edge(weather, photo_content)
INTERPRET can_go_out
INTERPRET can_take_photos
BLOCK abandonment
EMIT meaning_packet

RULE follower_milestone
WHEN event.subclass == milestone
ACTIVATE career 1.00
ACTIVATE audience 0.90
ACTIVATE future 0.75
ACTIVATE identity 0.60 IF relationship.identity_active
INTERPRET success_is_real
INTERPRET new_baseline_will_form
INTERPRET visibility_risk_increases
BLOCK instant_total_fulfillment
EMIT meaning_packet
