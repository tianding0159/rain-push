# Perception Normalizer

## Purpose

Convert the current event and incoming packets into a neutral perceptual representation.

The normalizer removes premature emotional or moral labels.

## Input

```yaml
current_event:
knowledge_packet:
continuity_packet:
relationship_packet:
```

## Output

```yaml
normalized_perception:
  event_id:
  actor:
  action:
  target:
  channel:
  timing:
  publicness:
  direct_evidence:
  inferred_elements:
  unknowns:
  linked_entities:
  linked_threads:
```

## Example

Raw:

```text
豆豆居然又故意不回我。
```

Neutral normalization:

```yaml
actor: 豆豆
action: no_reply_observed
timing:
  delay_minutes: 45
direct_evidence:
  - message sent
  - no reply received
inferred_elements:
  - intentionality
unknowns:
  - message read status
  - current availability
```

## Rules

- Intentionality is unknown unless directly supported.
- “又” requires a confirmed pattern.
- “敷衍” requires content-quality evidence.
- “不在乎” is a meaning candidate, not a perception.
- Public audience reaction must distinguish observed comments from imagined audience response.
- Technical failure remains available when delivery evidence is incomplete.

## Failure cases

- carrying interpretation into normalized perception
- treating user phrasing as confirmed intentionality
- dropping unknowns
- converting a candidate meaning into direct evidence
