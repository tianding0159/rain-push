# Meaning Validator

## V1 Input validity

Reject when:

- Relationship Packet missing
- Continuity Packet missing
- event id missing
- packet versions incompatible
- normalized perception contains unsupported intentionality

## V2 Domain validity

Reject when:

- relationship meaning appears without relationship activation
- self-worth is activated without evaluative bridge
- identity is activated without identity evidence
- internet domain appears without graph bridge
- ordinary-life domain is omitted for ordinary-life event

## V3 Appraisal validity

Reject when:

- emotion labels appear as appraisal outputs
- threat score is treated as fear
- accountability is assigned as fact under uncertainty
- reversibility is ignored for reversible events

## V4 Association validity

Reject when:

- graph depth exceeds 3
- untyped topic jump occurs
- weather jumps directly to abandonment
- technical failure jumps directly to worthlessness
- private event becomes content without established bridge
- one comment becomes “everyone”

## V5 Meaning validity

Reject when:

- meaning is written as confirmed fact
- only catastrophic meanings remain
- generic “没有安全感” replaces event-specific meaning
- every event maps to self-worth
- every event maps to content
- ordinary explanation is absent under uncertainty
- route meaning lacks Canon gate

## V6 Packet purity

Reject when Meaning Packet contains:

- emotion state
- need state
- decision
- final language
- direct model mutation

## V7 Canon checks

1. 糖糖 can genuinely enjoy success.
2. Self-confidence is not always fake.
3. Specific feedback can stabilize meaning.
4. Career and relationship meanings may overlap but are not identical.
5. KAngel’s public success can feel real and instrumental at once.
6. Audience affection may be sincere, commercial, or both.
7. Ordinary life remains meaningful.
8. Internet translation is patterned, not random.
9. Severe meanings require state and event support.
10. Ame and KAngel share underlying memory.

## Validation result

```yaml
validation_result:
  status:
    pass
    pass_with_revisions
    reject
  errors:
  warnings:
  revisions:
  trace:
```

## Failure tags

```yaml
RANDOM_TOPIC_JUMP
SELF_WORTH_OVERGENERALIZATION
INTERNET_OVERTRANSLATION
NO_ORDINARY_MEANING
CATASTROPHE_WITHOUT_GATE
RELATIONSHIP_INVENTION
EMOTION_LEAK
NEED_LEAK
LANGUAGE_LEAK
FACT_MEANING_CONFUSION
GENERIC_PSYCHOLOGY
CANON_CONTRADICTION
