# Phase 4: Meaning Runtime

## Status

- Version: `7.0-phase4`
- Runtime name: `Meaning Runtime`
- Partner display name: `豆豆`
- Depends on:
  - Knowledge Packet
  - Continuity Packet
  - Relationship Packet
  - Current Event
- Produces:
  - Meaning Packet
  - Meaning Update Queue
- Does not produce:
  - emotion
  - need
  - thought text
  - decision
  - final language

## Single responsibility

Meaning Runtime answers:

> 当前事件对糖糖的现实、事业、自我价值、网络身份、豆豆关系与未来预期，分别可能意味着什么？

Relationship Runtime determines how the event is interpreted inside the relationship with 豆豆.

Meaning Runtime expands beyond the relationship and computes broader personal meaning:

- reality meaning
- career meaning
- audience meaning
- self-worth meaning
- identity meaning
- internet meaning
- future meaning
- control meaning

## Core distinction

```text
Event:
豆豆没有回复。

Relationship Runtime:
豆豆可能在忙、忘了、睡着了、回避问题。

Meaning Runtime:
如果豆豆没认真读，是否说明这件事不值得被认真看？
如果制作人都说不出直播哪里好，观众的夸奖是否也只是随口？
如果今天只有自己在意，是否说明这次直播没有价值？
```

Meaning is not emotion.

The output may later lead to anxiety, irritation, pride, shame, relief, or no strong emotion. Phase 4 does not decide that.

## Pipeline

```text
Current Event
+ Knowledge Packet
+ Continuity Packet
+ Relationship Packet
        |
        v
Perception Normalizer
        |
        v
Meaning Domain Activation
        |
        v
Appraisal Engine
        |
        v
Internet Association Graph
        |
        v
Self / Career / Audience Translation
        |
        v
Counterfactual Engine
        |
        v
Meaning Salience
        |
        v
Meaning Packet
        |
        +--> Meaning Update Queue
        |
        v
Validator
```

## Architectural invariants

1. Meaning is an interpretation layer, not a fact layer.
2. Meaning cannot create relationship evidence not present in Relationship Packet.
3. Meaning cannot produce emotion, need, or final language.
4. A small event may remain small.
5. Internet-brain associations must have a traceable bridge.
6. Self-worth interpretation is conditional, not universal.
7. Career interpretation is not automatically relationship interpretation.
8. Ordinary life meanings must remain available.
9. Catastrophic meanings require severity and evidence gates.
10. Same inputs and seed produce the same Meaning Packet.
