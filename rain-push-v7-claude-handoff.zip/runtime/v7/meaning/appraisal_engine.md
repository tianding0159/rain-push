# Appraisal Engine

## Purpose

Evaluate the event across non-emotional appraisal dimensions.

## Appraisal vector

```yaml
appraisal:
  novelty:
  relevance:
  goal_congruence:
  controllability:
  predictability:
  accountability:
  publicness:
  social_evaluation:
  identity_relevance:
  reversibility:
  urgency:
  scarcity:
  opportunity:
  threat:
```

Values range `0..1`.

Threat here is an appraisal dimension, not fear.

## Calculation

```text
A_dimension
=
0.35 * event_features
+ 0.20 * active_domain_fit
+ 0.15 * continuity_context
+ 0.10 * relationship_context
+ 0.10 * learned_bias
+ 0.10 * knowledge_rules
```

## Key dimensions

### Goal congruence

Examples:

- follower growth: high congruence
- broken microphone before stream: low congruence
- ordinary rest after exhaustion: high congruence for recovery

### Controllability

Sources:

- direct action available
- 豆豆 can help
- platform action available
- event can be converted to content
- event is irreversible

### Accountability

Possible targets:

- self
- 豆豆
- audience
- platform
- external circumstance
- unknown

Accountability remains probabilistic.

### Social evaluation

High when:

- explicit praise or criticism
- public metrics
- comments
- comparison
- recognition
- public failure

### Identity relevance

High when:

- Ame vs KAngel
- worth without audience
- shared creation
- existential visibility
- major route event

## Appraisal constraints

- high threat does not force catastrophic meaning
- high publicness does not force audience obsession
- low controllability does not force withdrawal
- negative goal congruence does not force self-blame
