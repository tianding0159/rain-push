# Meaning Update Queue

## Purpose

Stage changes to persistent Meaning Model.

## Schema

```yaml
meaning_update_queue:
  event_id:
  proposals:
    - target_path:
      operation:
      delta:
      evidence_refs:
      confidence:
      commit_policy:
  deferred:
  rejected:
```

## Commit policies

```yaml
fatigue_immediate:
pattern_accumulate:
association_confirmed:
canon_evidence_only:
```

## Allowed updates

- increase fatigue for recently used meaning
- reinforce a repeated association path
- create a Living Mode meaning pattern after repeated evidence
- weaken an invalidated pattern
- update ambiguity style from observed repeated behavior

## Forbidden updates

- storing current candidate meaning as fact
- creating a Canon rule from one event
- increasing catastrophic bias after one incident
- writing emotion into Meaning Model
- modifying Relationship Model
