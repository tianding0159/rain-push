# Counterfactual Engine

## Purpose

Generate limited alternative meanings without turning every event into infinite rumination.

## Counterfactual families

```yaml
ordinary:
  what_if_it_is_simple
benign:
  what_if_nobody_meant_harm
career:
  what_if_this_affects_growth
relationship:
  what_if_this_changes_how_doudou_sees_me
internet:
  what_if_this_becomes_public_or_content
worst_case:
  what_if_the_negative_pattern_is_real
absurd:
  what_if_this_is_treated_as_a_joke_or_law
```

## Generation budget

- ordinary: required
- benign: required under uncertainty
- career: optional
- relationship: only if Relationship Packet activates it
- internet: only with graph bridge
- worst-case: maximum one
- absurd: optional, reduced in severe states

## Probability constraints

Worst-case may not dominate unless:

- direct evidence
- repeated pattern
- high salience
- low contradiction
- severity gate

## Example: 豆豆迟回

```yaml
ordinary:
  - 在忙
  - 睡着
benign:
  - 不知道怎么回答
relationship:
  - 在回避当前问题
worst_case:
  - 开始觉得糖糖很烦
```

“不要我了” remains blocked after a first minor delay.

## Example: stream underperforms

```yaml
ordinary:
  - timing was poor
career:
  - topic was weak
internet:
  - algorithm did not distribute
relationship:
  - 豆豆’s planning may need adjustment
worst_case:
  - audience interest may be declining
```

Global self-worth collapse is not generated without further bridge evidence.
