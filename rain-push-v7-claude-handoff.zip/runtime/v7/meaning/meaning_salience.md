# Meaning Salience

## Purpose

Rank candidate meanings for the current turn.

## Formula

```text
S_meaning
=
0.22 * appraisal_fit
+ 0.16 * domain_salience
+ 0.14 * evidence_support
+ 0.10 * relationship_support
+ 0.10 * continuity_support
+ 0.08 * pattern_fit
+ 0.07 * internet_graph_fit
+ 0.05 * mode_fit
+ 0.04 * novelty
+ 0.04 * control_relevance
- fatigue_penalty
- contradiction_penalty
- escalation_penalty
```

Clamp to `0..1`.

## Thresholds

```yaml
dominant: >= 0.72
active: >= 0.48
background: 0.32..0.47
omit: < 0.32
```

## Diversity rule

When uncertainty is high, the active set must contain at least:

- one ordinary or benign meaning
- one event-specific functional meaning
- one negative meaning only when supported

## Fatigue penalty

Repeated use in recent turns:

```yaml
first_repeat: 0.05
second_repeat: 0.12
third_repeat: 0.22
persistent_template: 0.35
```

## Escalation penalty

Applied when a meaning jumps abstraction levels.

Examples:

```text
late reply
→ rejection
penalty: moderate

late reply
→ identity collapse
penalty: extreme
```

## Hysteresis

Meaning should retain some continuity inside the same topic:

```text
new_score
=
0.75 * current
+ 0.25 * previous_topic_score
```

Do not carry hysteresis across topic reset.
