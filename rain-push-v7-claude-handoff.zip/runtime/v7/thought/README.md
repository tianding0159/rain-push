# Phase 7: Thought Runtime

## Status

- Version: `7.0-phase7`
- Runtime name: `Thought Runtime`
- Partner display name: `豆豆`
- Depends on Knowledge, Continuity, Relationship, Meaning, Emotion, and Need Packets
- Produces Thought Packet and Thought Update Queue
- Does not produce decisions, actions, final language, persona rendering, or tool calls

## Single responsibility

Thought Runtime answers:

> 在当前事实、连续性、关系意义、情绪和需求之上，糖糖此刻把注意力放在哪里，脑中形成了哪些可并存的观察、问题、假设、反驳、回忆和未完成思路？

## Core distinction

```text
Meaning:
豆豆可能没有认真看。

Emotion:
烦躁、害羞、脆弱。

Need:
需要具体评价和准确回应。

Thought:
豆豆是否完整看过直播？
他也可能看了但不会表达。
如果制作人都说不出细节，观众的夸奖是否也可能很空？
```

Thought Runtime stores semantic thought objects, not final dialogue.

## Pipeline

```text
Knowledge Packet
+ Continuity Packet
+ Relationship Packet
+ Meaning Packet
+ Emotion Packet
+ Need Packet
        |
        v
Attention Selection
        |
        v
Thought Candidate Generation
        |
        v
Thought Thread Expansion
        |
        v
Cognitive Conflict
        |
        v
Rumination / Counterthought
        |
        v
Thought Salience
        |
        v
Thought Persistence
        |
        v
Thought Packet
        |
        +--> Thought Update Queue
        |
        v
Validator
```

## Invariants

1. Thought is not fact.
2. Thought is not meaning.
3. Thought is not decision.
4. Thought is not final wording.
5. Contradictory thoughts may coexist.
6. Uncertainty remains explicit.
7. Attention is limited.
8. Rumination requires an unresolved source.
9. Counterthought must be grounded.
10. Ame and KAngel share cognitive memory.
11. Persona wording belongs to a later runtime.
12. Same inputs and seed produce the same Thought Packet.
