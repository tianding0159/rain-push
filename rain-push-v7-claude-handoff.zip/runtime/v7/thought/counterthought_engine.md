# Counterthought Engine

## 1. Purpose

Generate grounded thoughts that challenge, narrow, or contextualize high-salience thoughts.

Counterthought is not forced positivity.

## 2. Sources

```yaml
contradictory_evidence:
safety_memory:
ordinary_explanation:
domain_locality:
specific_history:
causal_alternative:
time_scale:
mode_constraint:
```

## 3. Counterthought types

```yaml
rebuttal:
qualification:
alternative_cause:
scope_limit:
time_limit:
evidence_gap:
safety_callback:
ordinary_reframe:
```

## 4. Examples

### Negative thought

```text
豆豆从来没认真看直播
```

Counterthought:

```text
上次他准确指出了中段设备问题，所以“从来没有”证据不足
```

### Global career thought

```text
这一场失败说明直播不行
```

Counterthought:

```text
当前失败包含明确硬件因素，不能直接归因于内容或能力
```

### Audience thought

```text
一个黑子说明大家都讨厌我
```

Counterthought:

```text
当前证据只支持一个负面账号，不支持“大家”
```

### Identity thought

```text
大家只喜欢KAngel，Ame不存在
```

Counterthought:

```text
豆豆近期记住了Ame的私人细节，私下可见性仍有证据
```

## 5. Effectiveness

```text
E_counter
=
0.25 * evidence_strength
+ 0.20 * target_specificity
+ 0.15 * source_credibility
+ 0.12 * domain_match
+ 0.10 * recency
+ 0.08 * safety_memory
+ 0.05 * ordinary_fit
+ 0.05 * need_fit
```

## 6. Generic reassurance penalty

Low effectiveness:

- everything is fine
- do not think too much
- you are amazing
- everyone loves you

unless the current need is low-level comfort rather than specificity.

## 7. Counterthought limits

Counterthought may:

- reduce confidence
- narrow scope
- add an alternative
- delay certainty

It may not:

- erase emotion
- declare safety without evidence
- close need without satisfier
- choose action
- generate final language

## 8. Failure cases

Reject when:

- counterthought is generic positivity
- contradictory evidence is invented
- negative thought is erased rather than weighted
- counterthought contains advice or action
- route evidence is dismissed by ordinary reassurance
