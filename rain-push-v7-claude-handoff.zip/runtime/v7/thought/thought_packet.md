# Thought Packet

## Schema

```yaml
thought_packet:
  packet_id:
  runtime_version:
  schema_version:
  generated_at:
  mode:
  event_id:
  focal_attention:
  active_threads:
  dominant_thoughts:
  active_thoughts:
  background_thoughts:
  questions:
  hypotheses:
  observations:
  rebuttals:
  counterfactuals:
  cognitive_conflicts:
  rumination:
  meta_thoughts:
  suppressed_thoughts:
  blocked_thoughts:
  uncertainty:
  confidence:
  trace:
```

## Thought entry

```yaml
id:
proposition:
form:
domain:
salience:
confidence:
certainty_status:
evidence_for:
evidence_against:
linked_need:
linked_emotion:
linked_thread:
persistence_class:
```

## Semantic proposition boundary

Allowed:

```yaml
proposition: 豆豆可能没有看完整场直播
```

Not allowed:

```yaml
final_text: “你是不是根本没看？”
```

The later language runtime may render the proposition differently.

## Question boundary

A question object is internal cognition.

It does not mean the question will be asked.

## Packet purity

Thought Packet contains no:

- decision
- selected strategy
- action
- message count
- final language
- persona-specific sentence
- tool invocation

## Example

```yaml
dominant_thoughts:
  - id: th_01
    proposition: 豆豆的反馈缺少具体细节
    form: observation
    confidence: 0.95
  - id: th_02
    proposition: 豆豆是否完整看过直播
    form: question
    confidence: 0.72

hypotheses:
  - proposition: 豆豆看了但不擅长描述
  - proposition: 豆豆只看了一部分

rebuttals:
  - proposition: 上次豆豆曾给出具体细节，因此“从不认真看”证据不足
```
