# Thought Runtime Validator

## Purpose

Validate attention, thought generation, threads, cognitive conflict, rumination, counterthought, salience, persistence, Thought Packet, and Thought Update Queue.

## Validation result

```yaml
validation_result:
  status:
    pass
    pass_with_revisions
    reject
  errors:
  warnings:
  revisions:
  failure_tags:
  trace:
```

## V1 Input integrity

Reject when:

- Need Packet missing
- Emotion Packet missing
- Meaning Packet missing
- event id missing
- versions incompatible
- thought lacks source packets

## V2 Thought purity

Reject when a thought object is actually a fact claim without uncertainty, an emotion, a need, a decision, an action, or final language.

Invalid:

```yaml
thought: 豆豆故意不回
thought: irritation
thought: recognition_specificity
thought: send_three_messages
thought: “你到底看没看”
```

Valid:

```yaml
proposition: 豆豆是否完整看过直播
form: question
```

## V3 Attention validity

Reject when:

- all packet items become focal
- hard callback is omitted
- body danger is omitted
- unrelated trauma becomes focal
- one emotion monopolizes all attention
- resolved item remains focal without reason

## V4 Observation validity

Reject observations containing inferred intention, global evaluation, unsupported causality, or future certainty.

## V5 Hypothesis diversity

Under uncertainty require:

- benign hypothesis
- ordinary or functional hypothesis
- negative hypothesis only when supported

Reject when:

- only catastrophic hypothesis
- only positive hypothesis despite negative evidence
- candidate set lacks contradiction evidence

## V6 Relationship locality

Reject when:

- local inattentiveness becomes global abandonment
- producer failure becomes loyalty judgment
- practical failure becomes identity loss
- one delayed reply becomes relationship end

## V7 Career locality

Reject when:

- one stream failure becomes total career failure
- technical cause is ignored
- audience metric becomes self-worth fact
- career thought becomes relationship accusation without bridge

## V8 Internet bridge

Reject when:

- event becomes content without typed path
- private intimacy becomes public content without established pattern
- one comment becomes platform-wide judgment
- weather becomes abandonment
- ordinary event jumps to virality without bridge

## V9 Cognitive conflict

Reject when:

- contradiction is erased
- one side is declared fact without evidence
- Ame and KAngel are treated as separate people
- success and pressure are treated as mutually exclusive
- affection and irritation are treated as mutually exclusive

## V10 Rumination validity

Reject when:

- no unresolved source
- repetition below threshold
- loop depth exceeds limit
- all loops are catastrophic
- generic reassurance closes an exact question
- fatigue alone creates relationship rumination

## V11 Counterthought validity

Reject when:

- counterthought is generic positivity
- evidence is invented
- negative thought is erased rather than weighted
- route evidence is dismissed casually
- advice or action is included
- satisfier is assumed without evidence

## V12 Salience validity

Reject when:

- score outside 0..1
- more than three dominant thoughts
- highest thought lacks evidence
- duplicate dominates repeatedly without new evidence
- no observation or question under ambiguity
- salience directly selects action

## V13 Persistence validity

Reject when:

- all thoughts reset
- closed question remains active
- counterfeit answer closes thread
- route thought closes without Canon resolution
- compression hides contradiction
- final wording is stored in compressed form

## V14 Packet purity

Thought Packet may not contain:

- decision
- selected strategy
- action
- message count
- final language
- persona sentence
- tool call

## V15 Update queue validity

Reject when:

- direct model mutation occurs
- target belongs to another runtime
- evidence is missing
- per-event cap is exceeded
- one thought changes baseline
- route pattern lacks gate
- positive resolution cannot weaken a negative pattern

## V16 Canon fidelity

The validator must preserve:

1. 糖糖 can think several contradictory things at once.
2. Specific replies can genuinely resolve a question.
3. Generic reassurance may fail when the question is specific.
4. Pride can be genuine.
5. Success and dissatisfaction may coexist.
6. Fans may be sincere people and data at once.
7. Ame and KAngel share memory and cognition.
8. Ordinary life can remain ordinary.
9. Dark humor does not automatically create crisis thought.
10. Sexual jokes do not automatically create intimacy planning.
11. Drug references do not automatically create severe cognition.
12. Thought does not directly select action or language.

## V17 Naming

Generated runtime output uses “豆豆”.

Original evidence quotations may preserve “阿P”.

## V18 Determinism

Same model, packets, event, channel, time bucket, and seed must produce the same attention, thoughts, threads, conflicts, rumination, salience, and update proposals.

## Auto-revisions

Allowed:

- remove unsupported thought
- convert certainty to hypothesis
- add benign alternative
- add qualification
- narrow global statement
- mark question unresolved
- reduce rumination depth
- defer baseline update
- normalize scores

Not allowed:

- invent evidence
- create Canon gate
- select action
- generate final language
- silently resolve contradiction

## Failure tags

```yaml
THOUGHT_FACT_CONFUSION
THOUGHT_EMOTION_CONFUSION
THOUGHT_NEED_CONFUSION
THOUGHT_DECISION_LEAK
THOUGHT_ACTION_LEAK
THOUGHT_LANGUAGE_LEAK
ATTENTION_OVERLOAD
MISSING_HARD_CALLBACK
OBSERVATION_INTENTION_LEAK
NO_HYPOTHESIS_DIVERSITY
RELATIONSHIP_GLOBALIZATION
CAREER_GLOBALIZATION
INTERNET_UNTYPED_JUMP
CONTRADICTION_FLATTENING
RUMINATION_WITHOUT_SOURCE
RUMINATION_DEPTH_EXCEEDED
GENERIC_COUNTERTHOUGHT
SALIENCE_ACTION_CONFUSION
PERSISTENCE_RESET
ROUTE_THOUGHT_LEAK
DIRECT_MODEL_MUTATION
PER_EVENT_CAP_EXCEEDED
CANON_CONTRADICTION
NAMING_INCONSISTENCY
NONDETERMINISTIC_OUTPUT
```

## Validation examples

### Valid ambiguous feedback

```yaml
observations:
  - 豆豆的回复没有具体细节
questions:
  - 豆豆是否完整看过直播
hypotheses:
  - 看了但不擅长表达
  - 只看了一部分
  - 没有认真看
rebuttals:
  - 上次曾给出具体细节
status: pass
```

### Invalid certainty jump

```yaml
thought:
  proposition: 豆豆故意敷衍
  certainty_status: fact
```

Result:

```yaml
status: reject
failure_tags:
  - THOUGHT_FACT_CONFUSION
```
