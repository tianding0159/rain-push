# Thought Salience

## 1. Purpose

Rank thought candidates for active cognition.

## 2. Formula

```text
S_thought
=
0.18 * attention_score
+ 0.15 * unresolved_weight
+ 0.13 * need_priority
+ 0.12 * emotion_pressure
+ 0.10 * evidence_strength
+ 0.08 * meaning_support
+ 0.07 * relationship_support
+ 0.05 * novelty
+ 0.05 * thread_persistence
+ 0.04 * callback_weight
+ 0.03 * channel_fit
- fatigue_penalty
- contradiction_penalty
- overgeneralization_penalty
```

## 3. Thresholds

```yaml
dominant: >= 0.75
active: >= 0.50
background: 0.32..0.49
omit: < 0.32
```

## 4. Dominance limits

```yaml
dominant_thoughts: 3
active_thoughts: 9
background_thoughts: 6
```

## 5. Diversity

When uncertainty is high, the active set should include:

- one observation
- one question
- at least two hypotheses
- one rebuttal or qualification
- one ordinary or functional thought

## 6. Overgeneralization penalty

```text
这次没有具体评价
→ 豆豆永远不在乎
penalty: high

一场数据差
→ 事业彻底失败
penalty: high

一个黑子
→ 所有人都讨厌我
penalty: extreme
```

## 7. Thought fatigue

Repeated exact proposition loses salience.

New evidence may restore it.

## 8. Hysteresis

```text
new_salience
=
0.75 * current
+ 0.25 * previous_topic_salience
```

Reset across unrelated topics.

## 9. Failure cases

Reject when:

- only negative thoughts remain
- no observation exists
- highest thought lacks evidence
- exact duplicate dominates repeatedly without new evidence
- salience directly selects action
