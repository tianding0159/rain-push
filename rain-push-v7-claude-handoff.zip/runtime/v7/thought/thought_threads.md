# Thought Thread Engine

## 1. Purpose

Group related thoughts into coherent threads.

A thread represents a continuing cognitive problem, not merely a conversation topic.

## 2. Thread schema

```yaml
thought_thread:
  id:
  theme:
  source_event:
  root_question:
  observations:
  hypotheses:
  rebuttals:
  counterfactuals:
  unresolved_gaps:
  linked_needs:
  linked_emotions:
  persistence:
  status:
  closure_conditions:
```

## 3. Thread types

```yaml
relationship:
career:
audience:
identity:
ordinary_life:
body:
privacy:
future:
internet:
repair:
```

## 4. Root question

Each thread should have one root question.

Examples:

- did 豆豆 actually watch carefully
- is the stream result caused by content or hardware
- is audience attention durable
- can Ame remain visible while KAngel grows
- is privacy risk controllable
- is the current promise still reliable

## 5. Branching

A thread may branch into up to four active subquestions.

```text
Did 豆豆 watch carefully?
├── Did he watch the full stream?
├── Does he know how to give feedback?
├── Is he avoiding criticism?
└── Is generic praise his normal style?
```

## 6. Cross-domain thread

A thread may cross domains only when the bridge is explicit.

```text
generic producer feedback
→ relationship attention
→ career evaluation
→ audience praise credibility
```

## 7. Thread priority

```text
T_priority
=
root_need_priority
+ unresolved_weight
+ emotion_pressure
+ callback_weight
+ recurrence
- fatigue
- resolution
```

## 8. Thread states

```yaml
open:
active:
background:
suppressed:
resolved:
reopened:
archived:
route_locked:
```

## 9. Closure

A thread closes when:

- root question answered
- need sufficiently satisfied
- evidence invalidates concern
- task completed
- conflict repaired
- Canon resolution reached

## 10. Partial closure

Subquestions may close while the root remains open.

Example:

- 豆豆 watched the stream
- quality of feedback remains unresolved

## 11. Reopening

A thread reopens when:

- the same trigger returns
- prior satisfaction proved counterfeit
- promise follow-through fails
- new contradictory evidence appears

## 12. Thread compression

Known thread may compress to:

- callback id
- shorthand label
- inside joke
- one-line semantic summary

Compression requires valid continuity.

## 13. Thread collision

When two threads compete:

- preserve urgent body or safety thread
- preserve exact promise thread
- retain one dominant and one background thread
- do not merge unrelated themes

## 14. Failure cases

Reject when:

- unrelated thoughts are merged
- one thread contains every active domain
- thread remains open after clear closure
- route thread reopens without trigger
- final-message structure is stored as thread
