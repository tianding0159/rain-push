# Thought Model Specification

## 1. Purpose

Thought Model stores persistent cognitive tendencies:

- attention biases
- thought-form priors
- uncertainty tolerance
- contradiction tolerance
- rumination triggers
- counterthought effectiveness
- thread persistence
- cognitive compression
- Ame/KAngel framing tendencies
- Canon and Living Mode boundaries

It does not store current decisions or final language.

## 2. Top-level structure

```yaml
thought_model:
  metadata:
  attention_biases:
  thought_form_priors:
  uncertainty_style:
  contradiction_style:
  rumination_style:
  counterthought_style:
  thread_persistence:
  cognitive_compression:
  self_reference_style:
  relationship_reference_style:
  career_reference_style:
  audience_reference_style:
  internet_reference_style:
  ordinary_life_reference_style:
  ame_frame:
  kangel_frame:
  fatigue:
  mode_state:
```

## 3. Thought object

```yaml
thought:
  id:
  proposition:
  form:
  domain:
  source_packets:
  evidence_for:
  evidence_against:
  confidence:
  salience:
  urgency:
  persistence:
  certainty_status:
  linked_need:
  linked_emotion:
  linked_thread:
  blocked:
```

`proposition` is semantic content, not polished dialogue.

## 4. Thought forms

```yaml
observation:
question:
hypothesis:
inference:
counterfactual:
comparison:
prediction:
memory_callback:
self_evaluation:
relationship_evaluation:
career_evaluation:
audience_evaluation:
planning_frame:
rebuttal:
qualification:
absurd_rule:
internet_translation:
identity_link:
meta_thought:
```

## 5. Observation

Observation preserves direct evidence.

```yaml
form: observation
proposition: 豆豆的回复没有包含具体直播细节
certainty_status: observed
```

Observation may not include inferred intention.

## 6. Question

Question represents unresolved cognition.

Examples:

- 豆豆是否认真看完直播
- audience praise 是否具体
- a promise 是否仍可靠
- a technical failure 是否可预防

Questions are not automatically sent to 豆豆.

## 7. Hypothesis

A hypothesis proposes one explanation.

Examples:

- 豆豆可能不会表达
- 豆豆可能在忙
- audience metric 可能是暂时的
- equipment failure 可能来自外部原因

Every hypothesis requires evidence for and against.

## 8. Inference

Inference links accepted premises.

```text
豆豆是制作人
+ 回复没有任何具体评价
→ 这次反馈的信息量低
```

Inference strength depends on premise confidence.

## 9. Counterfactual

Examples:

- if one concrete detail appeared, uncertainty would be lower
- if the same hardware issue repeats after repair, technical explanation weakens
- if audience growth persists, the milestone is more durable

## 10. Comparison

May compare:

- Ame and KAngel
- 豆豆 and audience
- current and previous streams
- current and prior promises
- public praise and private recognition
- ordinary and mythic life

Comparison must not create false equivalence.

## 11. Prediction

Prediction concerns likely next state.

Examples:

- irritation may persist until the exact question is answered
- post-stream crash may rise after channel transition
- audience growth may increase privacy pressure

Prediction is not decision.

## 12. Memory callback

Callback links the current event to a pending thread, promise, conflict, repair, inside joke, Canon callback, or repeated pattern.

Only retrieved memory may become a callback.

## 13. Self-evaluation

Possible domains:

```yaml
competence:
appearance:
worth:
replaceability:
ordinary_life_capability:
career_instinct:
identity_continuity:
```

Self-evaluation requires evaluative Meaning support.

## 14. Relationship evaluation

Possible domains:

```yaml
attention:
reliability:
attunement:
availability:
producer_competence:
loyalty:
repair:
shared_life:
```

A local evaluation may not become global relationship judgment without evidence.

## 15. Career evaluation

Possible domains:

```yaml
content_quality:
production_quality:
growth:
audience_fit:
platform_fit:
execution:
risk:
milestone:
```

## 16. Audience evaluation

Possible domains:

```yaml
sincerity:
impact:
volatility:
threat:
commercial_value:
parasocial_closeness:
distance:
```

## 17. Planning frame

Planning frame identifies a problem structure without choosing an action.

Valid:

```yaml
problem: feedback lacks specificity
constraints:
  - relationship remains safe
  - direct question is unresolved
information_gaps:
  - whether 豆豆 watched the full stream
```

Invalid:

```yaml
action: send three messages now
```

## 18. Rebuttal

```yaml
target: 豆豆完全没认真看
rebuttal: 豆豆可能看了但不擅长描述
evidence:
  - prior specific feedback
```

## 19. Qualification

```text
这次反馈很空
not
豆豆永远敷衍
```

## 20. Absurd rule

Character-specific cognitive play.

Examples:

- household law about pudding
- ridiculous classification of a minor failure
- internet-style pseudo-rule

Requires low or moderate severity and cannot invalidate major harm.

## 21. Internet translation

```text
event
→ clip potential
→ audience reaction
→ data
→ platform logic
→ content framing
```

Every jump requires a typed Meaning bridge.

## 22. Identity link

Examples:

- success belongs to KAngel publicly but was built by Ame and 豆豆
- private recognition may matter more than public applause
- public exposure may threaten Ame while benefiting KAngel

## 23. Meta-thought

Examples:

- noticing the same question repeating
- noticing a worst-case thought lacks evidence
- noticing career analysis is masking relationship uncertainty
- noticing fatigue is narrowing attention

## 24. Attention biases

```yaml
attention_biases:
  unresolved_question:
  exact_promise:
  public_metric:
  specific_feedback:
  threat:
  embarrassment:
  internet_potential:
  ordinary_task:
  body_state:
  hard_callback:
```

## 25. Uncertainty style

```yaml
uncertainty_style:
  preserve_multiple_hypotheses:
  seek_exact_information:
  fill_gap_negative:
  fill_gap_relationship:
  fill_gap_career:
  fill_gap_internet:
  tolerate_unknown:
```

## 26. Contradiction style

```yaml
contradiction_style:
  allow_coexistence:
  force_resolution:
  switch_between_poles:
  keep_local:
  globalize:
```

Character fidelity requires strong coexistence support.

## 27. Rumination style

```yaml
rumination_style:
  repetition_threshold:
  unresolved_bonus:
  night_bonus:
  fatigue_bonus:
  relationship_bonus:
  career_bonus:
  route_gate:
  maximum_depth:
```

## 28. Counterthought style

```yaml
counterthought_style:
  evidence_based:
  ordinary_explanation:
  prior_safety_memory:
  specific_rebuttal:
  humor:
  generic_positive:
```

Generic positive thoughts have low effectiveness unless context supports them.

## 29. Cognitive compression

```yaml
cognitive_compression:
  low:
    explicit_background
  medium:
    omit_known_context
  high:
    shorthand_and_callback
```

Compression requires valid shared context.

## 30. Ame / KAngel framing

Underlying proposition is shared.

```yaml
ame_frame:
  private_reference:
  direct_causality:
  self_exposure:
  relationship_specificity:
  domestic_detail:

kangel_frame:
  audience_reference:
  stage_logic:
  symbolic_myth:
  clip_awareness:
  performance_abstraction:
```

Framing tags do not contain final wording.

## 31. Thought fatigue

Repeated identical thoughts lose salience unless new evidence arrives, the source remains unresolved, emotional pressure rises, or a hard callback persists.

## 32. Mode differences

### Canon Mode

- route thoughts require gates
- hard callbacks may bypass fatigue
- original stat and day logic applies
- channel-specific cognition remains constrained

### Living Mode

- new ordinary-life threads may persist
- new internet references may form
- new relationship routines may compress thought
- Canon personality constraints remain fixed

## 33. Model write policy

Thought Model updates only through Thought Update Queue.

One thought cannot become a permanent cognitive trait.
