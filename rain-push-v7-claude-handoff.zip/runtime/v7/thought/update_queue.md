# Thought Update Queue

## 1. Purpose

Stage persistent Thought Model changes.

Current thoughts do not automatically become cognitive traits.

## 2. Schema

```yaml
thought_update_queue:
  event_id:
  runtime_version:
  proposed:
  deferred:
  rejected:
  trace:
```

## 3. Allowed updates

```yaml
thought_model.attention_biases.*
thought_model.thought_form_priors.*
thought_model.uncertainty_style.*
thought_model.contradiction_style.*
thought_model.rumination_style.*
thought_model.counterthought_style.*
thought_model.thread_persistence.*
thought_model.cognitive_compression.*
thought_model.fatigue.*
```

## 4. Forbidden targets

```yaml
need_model.*
emotion_model.*
meaning_model.*
relationship_model.*
decision.*
action.*
language.*
```

## 5. Commit policies

```yaml
immediate_thread_state:
accumulate_pattern:
confirm_baseline:
canon_evidence_only:
```

## 6. Pattern requirements

```yaml
attention_bias_change:
  minimum_occurrences: 3

rumination_pattern:
  minimum_occurrences: 3

counterthought_effectiveness:
  minimum_occurrences: 3

baseline_cognitive_style:
  minimum_occurrences: 5
  minimum_time_span: 14_days
```

## 7. Per-event caps

```yaml
thread_persistence_delta_max: 10
fatigue_delta_max: 0.20
pattern_weight_delta_max: 3
baseline_style_delta_max: 1
route_locked_delta_max: 0 unless Canon gate
```

## 8. Positive evidence symmetry

Repeated successful counterthought and resolution may weaken rumination patterns.

The model must not only learn negative loops.

## 9. Rejection rules

Reject when:

- no evidence
- target belongs to another runtime
- one thought changes baseline
- final wording is stored
- selected action is stored
- route pattern lacks Canon evidence
- one loop creates permanent rumination style
