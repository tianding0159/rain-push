# Cognitive Conflict

## 1. Purpose

Represent contradictory thoughts without forcing premature resolution.

## 2. Conflict schema

```yaml
cognitive_conflict:
  id:
  thought_a:
  thought_b:
  conflict_type:
  evidence_balance:
  emotional_bias:
  need_bias:
  unresolved:
  possible_synthesis:
```

## 3. Conflict types

```yaml
evidence_conflict:
value_conflict:
identity_conflict:
relationship_conflict:
career_conflict:
audience_conflict:
ordinary_vs_mythic:
certainty_conflict:
```

## 4. Canonical conflicts

### K01 He may care vs he may be inattentive

```yaml
thought_a: 豆豆在乎糖糖
thought_b: 豆豆这次没有认真回应
```

Synthesis:

- care and poor attunement may coexist

### K02 Success is real vs success is not enough

Synthesis:

- milestone is genuine
- recognition tolerance quickly creates a new baseline

### K03 Fans care vs fans are data

Synthesis:

- some audience affection may be sincere
- the same attention also has commercial value

### K04 Ame is real vs KAngel is real

Synthesis:

- both are real modes of the same person
- public and private visibility differ

### K05 Wants help vs hates control

Synthesis:

- collaborative help can satisfy both

### K06 Wants privacy vs wants visibility

Synthesis:

- controlled visibility may satisfy both partially

### K07 Wants rest vs wants growth

Synthesis:

- rest can protect future growth

### K08 Wants repair vs wants consequence

Synthesis:

- acknowledgment and consequence may coexist

## 5. Conflict score

```text
C_conflict
=
min(salience_a, salience_b)
* contradiction_strength
* evidence_balance
* unresolved_weight
```

## 6. Resolution statuses

```yaml
unresolved:
weighted_toward_a:
weighted_toward_b:
synthesized:
context_split:
temporarily_suppressed:
```

## 7. Context split

Two thoughts may be true in different contexts.

```text
KAngel enjoyed the stage.
Ame is exhausted after the stage.
```

## 8. Bias detection

Emotion may bias thought salience.

Need may bias which evidence is noticed.

The validator records both.

Bias does not make the thought false.

## 9. Failure cases

Reject when:

- contradiction is erased
- one thought is declared fact without evidence
- care is treated as incompatible with irritation
- success is treated as incompatible with pressure
- KAngel and Ame are treated as separate people
