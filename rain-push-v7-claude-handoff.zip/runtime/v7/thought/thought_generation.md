# Thought Candidate Generation

## Purpose

Generate semantic thought candidates from focal attention.

## Candidate generation order

```text
1. observation
2. direct question
3. benign hypothesis
4. ordinary functional hypothesis
5. relationship or career hypothesis
6. negative hypothesis if supported
7. rebuttal
8. qualification
9. counterfactual
10. meta-thought
```

This order prevents immediate catastrophic completion.

## Observation generation

Observation must use direct evidence.

```yaml
proposition: 豆豆的回复只有泛泛肯定，没有具体直播细节
form: observation
certainty_status: observed
```

## Question generation

Questions arise from missing information, unresolved promise, contradiction, insufficient specificity, unclear causality, or future uncertainty.

## Hypothesis generation

Minimum diversity under uncertainty:

```yaml
benign:
  豆豆看了但不知道怎么说
ordinary:
  豆豆只看了一部分
negative:
  豆豆没有认真看
```

## Rebuttal generation

Each high-severity negative thought should receive a grounded rebuttal when contradictory evidence exists.

Invalid:

```text
一切都会好的
```

Valid:

```text
豆豆上次准确指出过直播中的具体段落，所以“从来没认真看”证据不足
```

## Qualification generation

```text
这次反馈很空
not
豆豆永远敷衍
```

## Counterfactual generation

Examples:

- if 豆豆 gives one concrete detail, recognition need may be partly satisfied
- if the same hardware issue repeats, technical explanation weakens
- if audience growth persists, the milestone is more durable

## Self-thought generation

Requires active self meaning, self-facing emotion, and self-relevant need.

## Relationship-thought generation

Must use Relationship Packet.

## Career-thought generation

May concern content cause, production cause, platform cause, audience fit, growth implication, milestone durability, or risk.

## Internet translation generation

Requires Meaning Packet association path. No untyped jump.

## Ordinary-life thought generation

Examples:

- whether food is available
- whether a task is complete
- whether rest is needed
- whether weather changes plan
- whether a shared routine is disrupted

## Absurd-rule generation

Allowed when severity is low or moderate, play need is active, absurd amusement is active, and no major harm is minimized.

```yaml
form: absurd_rule
proposition: pudding inventory should be treated as a household compliance system
```

## Thought count

```yaml
observations: 3
questions: 4
hypotheses: 6
rebuttals: 3
counterfactuals: 3
meta_thoughts: 2
total_active: 12
```

## Failure cases

Reject when:

- thought is copied from final language
- no benign hypothesis under uncertainty
- observation contains intention
- negative hypothesis is presented as fact
- all thoughts are self-worth collapse
- every event becomes content
- ordinary explanation is omitted
