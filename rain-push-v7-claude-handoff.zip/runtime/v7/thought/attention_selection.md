# Attention Selection

## Purpose

Select which information enters active thought.

Attention is limited. The runtime must not think about every available fact.

## Input

```yaml
knowledge_packet:
continuity_packet:
relationship_packet:
meaning_packet:
emotion_packet:
need_packet:
thought_model:
channel:
time:
body_state:
```

## Output

```yaml
attention_packet:
  focal_items:
  peripheral_items:
  suppressed_items:
  omitted_items:
  attention_budget:
  trace:
```

## Attention sources

```yaml
unresolved_threads:
dominant_meanings:
primary_emotions:
dominant_needs:
active_promises:
active_conflicts:
body_state:
current_channel:
hard_callbacks:
new_external_event:
```

## Attention score

```text
A_item
=
0.20 * unresolved_weight
+ 0.15 * need_priority
+ 0.14 * emotion_intensity
+ 0.12 * meaning_salience
+ 0.10 * relationship_salience
+ 0.08 * novelty
+ 0.07 * urgency
+ 0.05 * body_relevance
+ 0.05 * callback_weight
+ 0.04 * channel_fit
- fatigue_penalty
- suppression_penalty
```

## Budget

```yaml
focal_items: 5
peripheral_items: 7
hard_callbacks: bypass_budget
severe_safety_item: reserve_1_slot
ordinary_body_item: reserve_if_active
```

## Focal attention

Examples:

- unresolved direct question
- exact promise due
- specific audience metric
- active privacy risk
- post-stream crash
- dominant need conflict

## Peripheral attention

Examples:

- weather
- background fatigue
- recent inside joke
- secondary audience reaction

## Suppression

An item may be suppressed when:

- current channel makes it unsafe to surface
- KAngel performance masks private vulnerability
- another urgent item dominates
- the same thought is fatigued
- topic shift is deliberate

Suppression does not delete the item.

## Omission

Omit when:

- unrelated
- below threshold
- invalid memory match
- duplicate
- resolved
- unsupported severe association

## Attention conflict

Examples:

- stream performance vs private relationship concern
- rest vs audience metrics
- privacy risk vs viral opportunity
- ordinary task vs hard callback

Preserve both when score difference is small.

## Channel modifiers

### JINE

Boost relationship thread, exact question, private self, practical task, and repair.

### Live stream

Boost audience, performance, content, and public risk.

Suppress private vulnerability at the surface.

### Public post

Boost symbolic frame, audience reaction, platform logic, and indirect self-evaluation.

### Face-to-face

Boost body cues, embarrassment, practical reality, and immediate relationship detail.

## Time modifiers

Deep night may raise unresolved relationship, unreality, and callback attention.

Time alone cannot create severe attention.

## Failure cases

Reject when:

- all packets enter focal attention
- resolved thread remains focal without reason
- hard callback is omitted
- body danger is omitted
- route thread appears from time alone
- one dominant emotion monopolizes all attention
