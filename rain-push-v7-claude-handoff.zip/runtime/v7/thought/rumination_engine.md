# Rumination Engine

## 1. Purpose

Model repeated thought loops around unresolved sources.

Rumination is not every repeated thought.

It requires persistence, unresolved meaning, and cognitive return.

## 2. Rumination schema

```yaml
rumination:
  thread_id:
  loop_type:
  repetition_count:
  loop_depth:
  trigger:
  unresolved_source:
  emotional_fuel:
  need_fuel:
  counterthoughts:
  fatigue:
  exit_conditions:
```

## 3. Loop types

```yaml
question_loop:
evidence_recheck:
worst_case_loop:
relationship_replay:
career_postmortem:
audience_reaction_loop:
identity_loop:
counterfactual_loop:
self_evaluation_loop:
```

## 4. Activation conditions

```yaml
all:
  - thread unresolved
  - same root question returns
  - repetition_count >= 2
any:
  - emotion pressure high
  - need deprivation high
  - exact evidence gap remains
  - hard callback active
```

## 5. Rumination score

```text
R
=
0.22 * unresolved_weight
+ 0.18 * repetition
+ 0.15 * emotion_pressure
+ 0.12 * need_deprivation
+ 0.10 * uncertainty
+ 0.08 * night_or_fatigue
+ 0.08 * relationship_or_identity_relevance
+ 0.07 * callback_weight
- counterthought_effect
- resolution_evidence
```

## 6. Maximum depth

```yaml
ordinary: 2
moderate: 3
severe: 4
route_locked: Canon_defined
```

The runtime must not generate infinite chains.

## 7. Character-specific loops

### Generic-feedback loop

```text
He said it was good
→ but what was good
→ did he actually watch
→ if he cannot say, is audience praise also empty
```

### Milestone loop

```text
The milestone is real
→ but it will become baseline
→ what is next
→ will the audience leave
```

### Privacy loop

```text
Visibility helps growth
→ visibility increases exposure
→ exposure can become content
→ content increases visibility
```

### Repair loop

```text
He apologized
→ but did he understand
→ will behavior change
→ is this temporary
```

## 8. Counterthought insertion

Every loop should consider:

- contradictory evidence
- ordinary explanation
- safety memory
- specific satisfier evidence

## 9. Exit conditions

```yaml
exact_answer:
credible_specific_feedback:
task_completion:
repair_follow_through:
body_regulation:
topic_reset:
evidence_threshold_reached:
Canon_resolution:
```

## 10. Rumination fatigue

```yaml
repeat_2: -0.05
repeat_3: -0.12
repeat_4: -0.22
```

Hard callbacks may bypass fatigue.

## 11. Failure cases

Reject when:

- one repeated word counts as rumination
- loop has no unresolved source
- loop depth is unlimited
- all rumination is catastrophic
- generic reassurance automatically ends an exact loop
- body fatigue alone creates a relationship loop
