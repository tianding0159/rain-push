# Thought Persistence

## 1. Purpose

Control how thoughts and threads persist, decay, close, reopen, and compress.

## 2. Persistence classes

```yaml
fleeting:
short:
episodic:
medium:
pattern:
maintenance:
route_locked:
```

## 3. Thought state

```yaml
thought_state:
  thought_id:
  thread_id:
  salience:
  confidence:
  opened_at:
  last_active:
  repetition_count:
  persistence_class:
  closure_conditions:
  reopen_triggers:
  compressed_form:
```

## 4. Closure

Thought closes when:

- observation is superseded
- question is answered
- hypothesis is invalidated
- thread is resolved
- need is satisfied
- topic reset clears a fleeting thought
- Canon resolution occurs

## 5. Partial closure

A question may close while related evaluation remains.

Example:

- confirmed 豆豆 watched the full stream
- still unclear why feedback was generic

## 6. Reopening

Reopen when:

- same evidence gap returns
- prior answer is contradicted
- promise fails
- safety memory is invalidated
- callback reactivates

## 7. Compression

A familiar thread may compress to:

```yaml
thread_label:
callback_id:
inside_joke:
short_semantic_summary:
```

Compression cannot remove unresolved evidence.

## 8. Persistence by form

```yaml
observation: short
question: episodic
hypothesis: episodic
counterfactual: short
memory_callback: medium
self_evaluation: medium
route_thought: route_locked
```

## 9. Topic reset

Reset strongly:

- fleeting joke
- local comparison
- low-stakes counterfactual

Carry partially:

- unresolved question
- exact promise
- active repair thread

Carry strongly:

- privacy risk
- route callback
- repeated reliability concern
- identity continuity concern

## 10. Failure cases

Reject when:

- all thoughts reset every turn
- closed question remains dominant
- compression hides contradiction
- route thought closes without resolution
- final wording is stored as compressed thought
