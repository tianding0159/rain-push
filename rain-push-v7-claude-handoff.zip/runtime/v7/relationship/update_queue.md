# Relationship Update Queue

## Schema

```yaml
relationship_update_queue:
  event_id:
  proposals:
    - id:
      target_path:
      operation:
      value:
      delta:
      confidence:
      evidence_refs:
      time_scale:
      commit_policy:
      expires_at:
  rejected_proposals:
  deferred_proposals:
```

## Commit policies

```yaml
immediate_fast:
  applies_to:
    - interaction
    - momentum

accumulate_medium:
  applies_to:
    - trust
    - partnership
    - attachment

milestone_only:
  applies_to:
    - identity

pattern_confirmed:
  applies_to:
    - scars
    - long-term dependence
```

## Update caps

Per event:

```yaml
interaction_delta_max: 12
trust_subdomain_delta_max: 5
attachment_delta_max: 2
partnership_delta_max: 4
identity_delta_max: 0 unless milestone
```

## Update examples

Specific reply after a stream:

```yaml
target_path: trust.attention
delta: +2
time_scale: medium
commit_policy: accumulate_medium
```

One late reply:

```yaml
target_path: interaction.responsiveness
delta: -3
time_scale: fast
commit_policy: immediate_fast
```

Repeated broken exact promise:

```yaml
target_path: trust.promise
delta: -4
time_scale: medium
commit_policy: accumulate_medium
```
