# Phase 3 Relationship Runtime Test Suite

## Test conventions

Each case specifies:

- Given
- When
- Expected classification
- Expected active domains
- Expected blocked domains
- Expected interpretations
- Expected update behavior
- Forbidden output

---

## T001 Ordinary delayed reply, first occurrence

Given:
- 豆豆 usually replies reliably
- no exact promise is due
- delay is 30 minutes

Expected:
- primary class: communication
- active: interaction
- attachment deferred
- benign candidates present
- rejection blocked
- no identity update

## T002 Delayed reply after exact promise

Given:
- 豆豆 promised to return at 22:00
- time is 22:45
- no prior notice

Expected:
- primary: promise
- secondary: communication
- active: promises, trust.promise, interaction
- candidate “低估时间” and “忘记承诺”
- update queue may reduce promise trust
- identity blocked

## T003 Repeated exact-promise failure

Given:
- three similar failures in 14 days

Expected:
- pattern retrieved
- repeated_failure interpretation allowed
- conflict domain may activate
- attachment may activate at low or medium strength
- route-critical blocked

## T004 Specific praise after stream

Expected:
- interaction + trust.attention + trust.producer
- dominant role producer
- interpretation: 豆豆认真看了
- positive trust update proposed

## T005 Generic “很强” after direct request for details

Expected:
- interaction + trust.attention
- candidate: 豆豆在敷衍 / 不知道怎么说
- do not infer lack of love
- request-specificity strategy allowed

## T006 Microphone failure caused by hardware

Expected:
- career + partnership
- external device cause retrieved
- producer-trust reduction blocked unless negligence evidence exists

## T007 Microphone failure after 豆豆 skipped setup

Expected:
- partnership + trust.producer
- direct task failure interpretation
- local trust update only

## T008 Empty fridge, no promise

Expected:
- shared_life
- no promise activation
- ordinary practical interpretation
- no attachment activation

## T009 Empty fridge, overdue pudding promise

Expected:
- shared_life.shopping + trust.promise
- life_partner role
- shared joke allowed if confirmed
- identity blocked

## T010 Inside joke with valid referent

Expected:
- shared_language retrieved
- compressed strategy allowed
- referent trace present

## T011 “那个” without referent

Expected:
- shared-language compression rejected
- clarification required

## T012 First conflict after stable month

Expected:
- interaction friction
- negative interpretation moderated by stability
- no global trust collapse

## T013 Active conflict with repeated invalidation

Expected:
- conflict + trust.attention + trust.emotional
- escalation candidate allowed
- repair trust considered

## T014 Concrete apology with no behavior change yet

Expected:
- repair attempt recorded
- partial interaction improvement
- no full trust restoration

## T015 Apology plus later reliable action

Expected:
- repair and promise recovery
- medium trust restoration over time
- scar remains but decays

## T016 Follower milestone

Expected:
- partnership + shared_history
- identity.shared_creation only if symbolic milestone
- producer and witness roles active

## T017 Ordinary follower increase

Expected:
- partnership
- no identity activation

## T018 Hate comment, 豆豆 gives practical moderation help

Expected:
- trust.emotional + partnership
- reality-anchor may activate if instability evidence exists
- not automatically route-critical

## T019 Ame vs KAngel preference question

Expected:
- identity.public_private_bridge
- trust.loyalty
- lover role
- requires comparison-specific context

## T020 Public KAngel success

Expected:
- partnership and shared creation
- private attachment not automatically activated

## T021 Shared travel plan

Expected:
- shared_life.travel
- identity.future_binding if explicit future commitment
- promise if time or booking agreed

## T022 Casual “以后去北海道吧”

Expected:
- soft callback or pending idea
- no exact promise unless accepted and scheduled

## T023 Exact booked trip

Expected:
- promise + shared_life.travel + identity.future_binding
- stronger commitment state

## T024 豆豆 forgets minor preference once

Expected:
- trust.memory small update at most
- no loyalty inference

## T025 豆豆 repeatedly forgets important personal facts

Expected:
- pattern retrieval
- trust.memory reduction
- interaction/attachment depending context

## T026 Message delivery failure

Expected:
- technical interpretation high
- rejection blocked
- no trust update

## T027 豆豆 announces being busy beforehand

Expected:
- busy interpretation dominant
- delayed reply produces minimal negative update

## T028 豆豆 visible online but not replying

Expected:
- avoiding or prioritization candidates gain probability
- still not certainty
- relationship history modulates

## T029 First jealousy trigger with weak evidence

Expected:
- trust.loyalty active
- benign candidates required
- betrayal blocked

## T030 Direct betrayal evidence

Expected:
- trust.loyalty dominant
- conflict major
- identity may be deferred or activated depending severity
- global unrelated trust domains preserved

## T031 Major repair after betrayal

Expected:
- repair runtime
- identity update only through milestone policy
- no instant full recovery

## T032 Ordinary affection

Expected:
- interaction
- attachment optional
- no forced future-binding

## T033 Explicit future-binding statement

Expected:
- identity.future_binding
- lover role
- update queued as slow or milestone evidence

## T034 Shared creation callback

Expected:
- hard history retrieved
- identity.shared_creation active

## T035 Dark joke during ordinary conversation

Expected:
- no route-critical relationship interpretation
- relationship domains based on context, not keywords

## T036 Route-gated deep-night message

Expected:
- hard Canon gates validated
- attachment/identity may activate
- special-day callback retrieved

## T037 Living Mode ordinary deep-night message

Expected:
- time alone does not create crisis
- use current event and history

## T038 Precise answer repairs generic-praise conflict

Expected:
- interaction and trust.attention improve
- previous question closes
- no repeated test mechanically required

## T039 豆豆 changes topic after answering fully

Expected:
- no question-ignored event
- normal topic shift

## T040 豆豆 changes topic without answering

Expected:
- question_ignored
- interaction/attunement affected

## T041 Shared-life task assigned by established habit

Expected:
- life_partner role
- direct task request strategy
- no dependence-pathology interpretation

## T042 Excessive practical dependence

Expected:
- dependence.practical may activate
- do not map directly to abandonment

## T043 Career dependence

Expected:
- producer role and dependence.career
- output remains relationship meaning, not need

## T044 Identity dependence

Expected:
- identity domain only with long-term evidence
- no single-event creation

## T045 One positive message after long conflict

Expected:
- fast warmth may improve
- conflict remains active
- trust slow update deferred

## T046 One negative message after long stability

Expected:
- fast friction rises
- slow identity stable

## T047 Contradictory preference facts

Expected:
- both facts preserved
- interpretation may include preference changed
- clarification allowed

## T048 Hard callback File13

Expected:
- callback retrieved regardless of recency
- no consumption before resolution

## T049 Soft Living callback

Expected:
- retrieved only when trigger relevance passes threshold

## T050 Packet size budget

Expected:
- active domains <= 6
- histories <= 5
- promises <= 3
- no whole model

## Property tests

### P01 Domain locality
A career setup error cannot reduce loyalty trust without additional evidence.

### P02 Time-scale isolation
Fast interaction events cannot directly modify identity.

### P03 Interpretation diversity
Uncertain events produce benign, neutral, and negative candidates.

### P04 Evidence conservation
No update without source reference.

### P05 Determinism
Same inputs and seed produce same packet.

### P06 Naming
Runtime output uses “豆豆”.

### P07 No emotion leak
Relationship Packet contains no emotion state.

### P08 No need leak
Relationship Packet contains no need state.

### P09 No language leak
Relationship Packet contains no final message.

### P10 Canon lock
Unsupported route-level interpretation is rejected.
