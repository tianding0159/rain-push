# Interpretation Engine

## Purpose

Generate and rank candidate relationship meanings.

An interpretation answers:

> 这件事在糖糖与豆豆的关系里可能意味着什么？

It does not answer:

- what emotion results
- what need follows
- what message is sent

## Inputs

```yaml
event_classification:
domain_activation:
relationship_retrieval:
salience_scores:
knowledge_packet:
continuity_packet:
mode:
seed:
```

## Output

```yaml
interpretation_set:
  candidates:
    - id:
      meaning:
      probability:
      supporting_evidence:
      contradicting_evidence:
      active_domains:
      active_roles:
      severity:
  dominant:
  blocked:
  unresolved_uncertainty:
```

## Candidate families

### Communication meanings

- 豆豆正在忙
- 豆豆睡着了
- 豆豆忘记了
- 豆豆看到了但暂时没法回
- 豆豆没认真读
- 豆豆不知道怎么回
- 豆豆在回避这个问题
- 豆豆觉得这个话题不重要
- 豆豆开始觉得糖糖很烦
- 消息可能没有送达

### Promise meanings

- 豆豆只是晚了
- 豆豆低估了时间
- 豆豆忘记了承诺
- 豆豆没有把这件事放在心上
- 豆豆正在重新安排
- 豆豆经常只会口头答应
- 这次是意外，不代表长期模式

### Shared-life meanings

- 这是共同生活里的普通遗漏
- 责任分配不清
- 豆豆默认糖糖会自己处理
- 豆豆忘了共享习惯
- 这件事适合用内部梗处理
- 这是重复的生活摩擦

### Career meanings

- 豆豆的制作判断可靠
- 豆豆没有认真准备
- 失败来自外部条件
- 失败来自企划本身
- 豆豆仍然是共同制作人
- 糖糖需要更具体的职业评价
- 豆豆只是在安慰，没有真正分析

### Affection meanings

- 豆豆在具体看见 Ame
- 豆豆只在喜欢 KAngel
- 豆豆表达得笨拙但真实
- 豆豆在敷衍
- 豆豆愿意把未来放进“我们”
- 这只是普通亲密，不代表关系转折

### Conflict meanings

- 当前问题可以通过澄清解决
- 豆豆没有意识到伤害
- 豆豆正在防御
- 豆豆拒绝承认具体事实
- 相似失约正在形成模式
- 当前事件触发了旧伤，但并不等于旧事重演

## Probability model

For candidate `c`:

```text
logit(c)
=
prior(c)
+ evidence_support(c)
+ domain_fit(c)
+ pattern_fit(c)
+ role_fit(c)
+ mode_fit(c)
- contradiction(c)
- escalation_penalty(c)
```

Normalize with softmax.

## Priors

Priors depend on long-term model.

Example:

```yaml
if trust.promise >= 75:
  prior:
    accidental_delay: high
    deliberate_disregard: low

if repeated_broken_promises >= 3:
  prior:
    forgetting: medium
    disregard: increased
```

## Evidence support

Direct evidence outranks inference.

```yaml
direct_statement: 1.0
structured_event: 0.9
repeated_pattern: 0.8
recent_episode: 0.6
weak semantic association: 0.3
```

## Contradicting evidence

Examples:

- 豆豆提前说明会忙
- 当前承诺尚未到期
- 近期一直可靠
- 消息发送失败
- 豆豆正在处理共同任务

## Escalation ladder

Interpretations are severity-banded.

```yaml
ordinary:
  - busy
  - sleeping
  - forgot
  - misunderstood

tense:
  - avoided_question
  - did_not_take_seriously
  - repeated_failure

unstable:
  - emotionally_withdrawn
  - loyalty_doubt
  - relationship_threat

route_critical:
  - abandonment_certainty
  - irreversible_identity_loss
```

Route-critical candidates require:

- Canon gate or equivalent severe Living Mode evidence
- high-confidence repeated pattern
- active severe conflict or hard callback
- Validator approval

## Internet-brain relationship interpretation

Relationship meanings may include network and career mediation.

Examples:

```text
豆豆没有具体夸直播
→ 他是不是根本没认真看
→ 如果连制作人都说不出哪里好
→ 观众的夸奖是不是也只是随口
```

This chain is relationship interpretation plus career context. It is not yet emotion.

## Shared-language interpretation

If a valid inside joke exists, candidate meaning may include:

- 豆豆在用共同笑点修复
- 豆豆在轻描淡写
- 豆豆用熟悉格式确认“我们还正常”

Inside joke interpretation requires confirmed shared-language entry.

## Interpretation diversity

At least three plausible candidates when uncertainty is high:

- benign
- neutral/ordinary failure
- relationship-negative

Do not force one certainty without evidence.

## Dominant interpretation

Select dominant only if:

```yaml
top_probability >= 0.50
and
top_minus_second >= 0.12
```

Otherwise emit `ambiguous`.

## Blocked interpretations

Examples:

- “豆豆不要我了” blocked after one ordinary delayed reply
- “豆豆背叛了我” blocked without loyalty evidence
- “我们关系彻底结束” blocked outside severe conflict
- “豆豆只爱 KAngel” blocked without comparison evidence
- “豆豆在操控我” blocked without repeated control pattern

## Update implications

Interpretation may propose updates but cannot commit.

Example:

```yaml
proposed_update:
  target: trust.attention
  delta: -2
  confidence: 0.62
```

## Determinism

Same model, packets, event, rules, and seed must produce same candidate set and probabilities.

## Failure cases

- emitting emotion words as outputs
- treating candidate meaning as confirmed fact
- generating only negative candidates
- skipping benign alternatives without evidence
- escalating from one minor event
- interpreting all practical dependence as abandonment fear
- using generic attachment theory language instead of event-specific meaning
