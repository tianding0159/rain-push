# Phase 3: Relationship Runtime

## Status

- Version: `7.0-phase3`
- Runtime name: `Relationship Runtime`
- Partner display name: `豆豆`
- Depends on: `Knowledge Packet`, `Continuity Packet`
- Produces: `Relationship Packet`, `Relationship Update Queue`
- Does not produce: emotion, need, thought, decision, persona, language

## Single responsibility

Relationship Runtime answers one question:

> 在当前事件中，豆豆对于糖糖而言，此刻主要是谁，这件事触发了哪些关系领域，哪些关系解释具有合理概率，哪些解释或行为因证据不足而必须被阻止？

It does not answer:

- 糖糖现在是什么情绪
- 糖糖现在需要什么
- 糖糖应该发什么消息
- 最终文本应该怎样写

## Runtime pipeline

```text
Current Event
  + Knowledge Packet
  + Continuity Packet
  + Relationship Model
        |
        v
Event Classifier
        |
        v
Domain Activation
        |
        v
Relationship Retrieval
        |
        v
Salience Engine
        |
        v
Interpretation Engine
        |
        v
Relationship Packet
        |
        +--> Relationship Update Queue
        |
        v
Validator
        |
        +--> accept / revise / reject
```

## Architectural invariants

1. Long-term relationship state lives in `Relationship Model`.
2. Current-turn computation lives in `Relationship Runtime`.
3. Downstream runtimes receive only `Relationship Packet`.
4. No current event may directly mutate long-term state.
5. Every mutation passes through `Relationship Update Queue`.
6. One minor event cannot change identity-level state.
7. An interpretation is not an emotion.
8. A candidate meaning is not a fact.
9. Relationship severity must be evidence-constrained.
10. Runtime examples use “豆豆”; original evidence quotations preserve “阿P”.

## Main modules

- `relationship_model.md`: complete persistent model specification
- `event_classifier.md`: complete event taxonomy
- `domain_activation.md`: deterministic activation rules
- `relationship_retrieval.md`: scoped retrieval algorithm
- `salience_engine.md`: scoring and propagation rules
- `interpretation_engine.md`: candidate meaning generation
- `validator.md`: packet and update validation
- `tests/`: test matrix and concrete cases

## Completion definition

Phase 3 is complete when the runtime can deterministically answer:

- Which relationship domains are relevant?
- Which role of 豆豆 is active?
- Which memories and facts may be retrieved?
- Which candidate interpretations are plausible?
- Which interpretations are blocked?
- What long-term updates are proposed?
- Which updates are rejected or delayed?
