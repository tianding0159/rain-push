# Relationship Runtime DSL v0.1

RULE pudding_promise_overdue
WHEN event.primary == shared_life
AND event.subclass == inventory_change
IF pending.promise.item == pudding
AND pending.promise.status == overdue
ACTIVATE shared_life.shopping 0.95
ACTIVATE trust.promise 0.75
ACTIVATE interaction 0.55
BLOCK identity
RETRIEVE promise.current
RETRIEVE pattern.shopping
INTERPRET ordinary_omission
INTERPRET repeated_failure IF pattern.shopping.count >= 3
EMIT relationship_packet

RULE delayed_reply_once
WHEN event.subclass == reply_delayed
ACTIVATE interaction 0.80
DEFER attachment UNTIL repetition >= repeated
INTERPRET busy
INTERPRET sleeping
INTERPRET forgot
BLOCK rejection IF repetition == first
EMIT relationship_packet

RULE specific_stream_praise
WHEN event.subclass == specific_praise
AND event.context == stream
ACTIVATE interaction 0.85
ACTIVATE trust.attention 0.90
ACTIVATE trust.producer 0.65
ROLE producer 0.55
ROLE lover 0.30
INTERPRET doudou_watched_carefully
QUEUE trust.attention +2
EMIT relationship_packet
