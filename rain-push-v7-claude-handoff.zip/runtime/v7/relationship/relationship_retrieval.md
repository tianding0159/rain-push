# Relationship Retrieval

## Purpose

Retrieve the smallest relationship context required to interpret the current event.

## Inputs

```yaml
knowledge_packet:
continuity_packet:
event_classification:
domain_activation:
relationship_model:
mode:
```

## Output

```yaml
relationship_retrieval:
  model_fragments:
  linked_promises:
  linked_conflicts:
  linked_repairs:
  linked_history:
  shared_language:
  scars:
  patterns:
  omitted:
  trace:
```

## Retrieval priority

1. Active promise directly linked to event
2. Active conflict directly linked to event
3. Unresolved pending thread
4. Hard callback
5. Active domain values
6. Recent domain-specific episodes
7. Domain-specific pattern
8. Relevant scar
9. Shared language referent
10. Slow identity state only if activated

## Query construction

```text
query
=
event class
+ linked entities
+ active domains
+ actor
+ time window
+ unresolved thread ids
+ callback ids
```

## Domain-local retrieval

### interaction

Retrieve:

- last 10 meaningful exchanges
- unanswered questions
- average delay in relevant time window
- specificity and attunement observations

Do not retrieve:

- ancient conflicts without reactivation
- unrelated stream history

### attachment

Retrieve:

- recent availability pattern
- repeated reply deprivation
- separation-related scars
- current security baseline

Do not retrieve:

- all affectionate memories
- unrelated practical failures

### partnership

Retrieve:

- recent project or task history
- domain-specific trust
- responsibility assignment
- current shared goal

### identity

Retrieve only:

- active milestone
- major betrayal or repair
- explicit future-binding callback
- relevant shared-creation history

### shared language

Retrieve:

- referent map
- inside joke entry
- shorthand confidence
- last confirmed use

## Time windows

```yaml
interaction: 48_hours
attachment: 30_days_plus_patterns
partnership: project_lifetime
identity: full_history_but_triggered_only
promises: until_resolved_plus_recovery_window
conflicts: active_plus_similar_scars
shared_language: until_invalidated
```

## Retrieval scoring

```text
retrieval_score
=
0.30 * domain_match
+ 0.20 * semantic_match
+ 0.15 * unresolved_weight
+ 0.10 * recency
+ 0.10 * callback_priority
+ 0.10 * relationship_importance
+ 0.05 * source_confidence
```

Minimum inclusion threshold: `0.45`.

Hard callbacks bypass threshold.

## Conflict-aware retrieval

When facts conflict:

```yaml
conflict_set:
  - statement:
    source:
    confidence:
    timestamp:
```

Do not silently choose one unless a resolution rule exists.

## Compression

Return summaries, not raw transcripts, except:

- one short exact promise
- one unresolved direct question
- one callback keyword
- one short shared-language referent

## Retrieval caps

```yaml
max_model_fragments: 12
max_history_items: 5
max_promises: 3
max_conflicts: 2
max_scars: 2
max_patterns: 3
max_shared_language_items: 4
```

## Omission trace

Every omitted high-scoring item must record why:

```yaml
omitted:
  - id:
    score:
    reason:
```

## Failure cases

- retrieving whole model
- retrieving identity state for ordinary shopping
- retrieving unrelated trauma for a neutral task
- omitting an active exact promise
- including a scar without semantic similarity
- resolving an ambiguous “那个” without a valid referent
