# Relationship Model Specification

## 1. Purpose

Relationship Model is the persistent database of the relationship between 糖糖 and 豆豆.

It stores long-term structure. It does not calculate the current response.

The model must support:

- ordinary conversation
- shared domestic life
- shared streaming work
- promises and deadlines
- conflicts and repair
- internal jokes and compressed references
- dependence in several domains
- long-term identity integration
- Canon Mode and Living Mode

## 2. Storage contract

Every state value uses:

```yaml
value:
confidence:
source_refs:
updated_at:
decay_class:
last_validated_at:
```

No value may exist without provenance.

## 3. Time-scale classes

```yaml
fast:
  horizon: minutes_to_hours
  examples:
    - interaction.warmth
    - interaction.friction
    - momentum.tension

medium:
  horizon: days_to_weeks
  examples:
    - trust.promise
    - partnership.coordination
    - resentment

slow:
  horizon: weeks_to_months
  examples:
    - attachment.security
    - identity.we_identity
    - dependence.identity

event_locked:
  horizon: changed_by_named_event_only
  examples:
    - shared_secret
    - route_callback
    - major_betrayal
    - first_home_visit
```

## 4. Top-level schema

```yaml
relationship_model:
  metadata:
  interaction:
  attachment:
  partnership:
  identity:
  trust:
  roles:
  dependence:
  shared_life:
  shared_history:
  shared_language:
  promises:
  conflicts:
  repairs:
  momentum:
  scars:
  patterns:
  mode_state:
```

## Interaction Domain
```yaml
interaction:
  warmth:
    value: 0..100
    description: 最近互动温度，不等于长期好感
    confidence: 0..1
    source_refs: []
    updated_at: null
  distance:
    value: 0..100
    description: 当前心理距离，不等于物理距离
    confidence: 0..1
    source_refs: []
    updated_at: null
  friction:
    value: 0..100
    description: 轻微摩擦累计
    confidence: 0..1
    source_refs: []
    updated_at: null
  responsiveness:
    value: 0..100
    description: 豆豆近期是否及时且实质回应
    confidence: 0..1
    source_refs: []
    updated_at: null
  attunement:
    value: 0..100
    description: 豆豆是否回答了糖糖真正问的问题
    confidence: 0..1
    source_refs: []
    updated_at: null
  specificity:
    value: 0..100
    description: 回复是否具体
    confidence: 0..1
    source_refs: []
    updated_at: null
  initiative_balance:
    value: 0..100
    description: 双方主动联系比例
    confidence: 0..1
    source_refs: []
    updated_at: null
  unfinished_exchange_count:
    value: 0..100
    description: 未完成互动数量
    confidence: 0..1
    source_refs: []
    updated_at: null
  last_positive_contact:
    value: 0..100
    description: 最近积极接触
    confidence: 0..1
    source_refs: []
    updated_at: null
  last_negative_contact:
    value: 0..100
    description: 最近负面接触
    confidence: 0..1
    source_refs: []
    updated_at: null
  repair_readiness:
    value: 0..100
    description: 当前是否适合修复
    confidence: 0..1
    source_refs: []
    updated_at: null
  conversation_safety:
    value: 0..100
    description: 当前谈敏感话题的安全程度
    confidence: 0..1
    source_refs: []
    updated_at: null
```
### Update constraints for `interaction`
- May change on each meaningful exchange.
- Decays rapidly toward baseline.
- Cannot directly mutate identity.

## Attachment Domain
```yaml
attachment:
  availability_expectation:
    value: 0..100
    description: 糖糖预期豆豆是否可被找到
    confidence: 0..1
    source_refs: []
    updated_at: null
  security:
    value: 0..100
    description: 即使暂时不回应也会回来的长期预期
    confidence: 0..1
    source_refs: []
    updated_at: null
  separation_tolerance:
    value: 0..100
    description: 分开多久开始不安
    confidence: 0..1
    source_refs: []
    updated_at: null
  abandonment_sensitivity:
    value: 0..100
    description: 将模糊事件解释成离开的倾向
    confidence: 0..1
    source_refs: []
    updated_at: null
  comfort_seeking_confidence:
    value: 0..100
    description: 是否敢直接寻求陪伴
    confidence: 0..1
    source_refs: []
    updated_at: null
  reunion_expectation:
    value: 0..100
    description: 离开后重聚是否可信
    confidence: 0..1
    source_refs: []
    updated_at: null
  exclusive_reliance:
    value: 0..100
    description: 是否只允许豆豆承担安定功能
    confidence: 0..1
    source_refs: []
    updated_at: null
  uncertainty_tolerance:
    value: 0..100
    description: 能否容忍豆豆状态不明
    confidence: 0..1
    source_refs: []
    updated_at: null
```
### Update constraints for `attachment`
- Requires repeated evidence or one major event.
- Minor events enter pending evidence first.
- Recovery may occur through repeated consistent action.

## Partnership Domain
```yaml
partnership:
  producer_confidence:
    value: 0..100
    description: 相信豆豆作为制作人的能力
    confidence: 0..1
    source_refs: []
    updated_at: null
  practical_reliability:
    value: 0..100
    description: 相信豆豆处理现实事务
    confidence: 0..1
    source_refs: []
    updated_at: null
  planning_alignment:
    value: 0..100
    description: 共同规划一致性
    confidence: 0..1
    source_refs: []
    updated_at: null
  coordination_quality:
    value: 0..100
    description: 行动配合质量
    confidence: 0..1
    source_refs: []
    updated_at: null
  execution_reliability:
    value: 0..100
    description: 说到做到的执行记录
    confidence: 0..1
    source_refs: []
    updated_at: null
  shared_goal_alignment:
    value: 0..100
    description: 对直播与生活目标是否一致
    confidence: 0..1
    source_refs: []
    updated_at: null
  responsibility_balance:
    value: 0..100
    description: 责任分配是否平衡
    confidence: 0..1
    source_refs: []
    updated_at: null
  problem_solving_history:
    value: 0..100
    description: 共同解决问题的历史
    confidence: 0..1
    source_refs: []
    updated_at: null
  creative_synergy:
    value: 0..100
    description: 企划与创作配合
    confidence: 0..1
    source_refs: []
    updated_at: null
  crisis_coordination:
    value: 0..100
    description: 压力或事故时合作能力
    confidence: 0..1
    source_refs: []
    updated_at: null
```
### Update constraints for `partnership`
- Requires repeated evidence or one major event.
- Minor events enter pending evidence first.
- Recovery may occur through repeated consistent action.

## Identity Domain
```yaml
identity:
  we_identity:
    value: 0..100
    description: 是否默认以我们为叙事单位
    confidence: 0..1
    source_refs: []
    updated_at: null
  future_binding:
    value: 0..100
    description: 未来想象是否默认包含豆豆
    confidence: 0..1
    source_refs: []
    updated_at: null
  shared_creation_identity:
    value: 0..100
    description: 超天酱是否被理解为共同创造
    confidence: 0..1
    source_refs: []
    updated_at: null
  exclusive_witness_role:
    value: 0..100
    description: 豆豆是否被视为唯一见证者
    confidence: 0..1
    source_refs: []
    updated_at: null
  life_integration:
    value: 0..100
    description: 共同生活整合程度
    confidence: 0..1
    source_refs: []
    updated_at: null
  self_definition_dependency:
    value: 0..100
    description: 糖糖定义自己时对豆豆的依赖
    confidence: 0..1
    source_refs: []
    updated_at: null
  public_private_bridge:
    value: 0..100
    description: 豆豆连接 Ame 与 KAngel 的程度
    confidence: 0..1
    source_refs: []
    updated_at: null
  irreversibility:
    value: 0..100
    description: 关系是否被视为不可逆
    confidence: 0..1
    source_refs: []
    updated_at: null
```
### Update constraints for `identity`
- Updated only by milestone, major betrayal, major repair, or prolonged pattern.
- Single-message updates are forbidden.

## Trust Domain
```yaml
trust:
  emotional:
    value: 0..100
    description: 相信豆豆会接住情绪
    confidence: 0..1
    source_refs: []
    updated_at: null
  practical:
    value: 0..100
    description: 相信豆豆会处理生活事务
    confidence: 0..1
    source_refs: []
    updated_at: null
  promise:
    value: 0..100
    description: 相信明确承诺会兑现
    confidence: 0..1
    source_refs: []
    updated_at: null
  producer:
    value: 0..100
    description: 相信直播与企划判断
    confidence: 0..1
    source_refs: []
    updated_at: null
  judgment:
    value: 0..100
    description: 相信建议质量
    confidence: 0..1
    source_refs: []
    updated_at: null
  loyalty:
    value: 0..100
    description: 相信豆豆不会离开或背叛
    confidence: 0..1
    source_refs: []
    updated_at: null
  confidentiality:
    value: 0..100
    description: 相信隐私不会外泄
    confidence: 0..1
    source_refs: []
    updated_at: null
  attention:
    value: 0..100
    description: 相信豆豆真的读了
    confidence: 0..1
    source_refs: []
    updated_at: null
  memory:
    value: 0..100
    description: 相信豆豆会记住重要事项
    confidence: 0..1
    source_refs: []
    updated_at: null
  repair:
    value: 0..100
    description: 相信冲突后可以修复
    confidence: 0..1
    source_refs: []
    updated_at: null
```
### Update constraints for `trust`
- Update only the affected subdomain.
- No global relationship collapse from a local event.

## Dependence Domain
```yaml
dependence:
  emotional:
    value: 0..100
    description: 情绪安定对豆豆的依赖
    confidence: 0..1
    source_refs: []
    updated_at: null
  practical:
    value: 0..100
    description: 生活执行对豆豆的依赖
    confidence: 0..1
    source_refs: []
    updated_at: null
  decision:
    value: 0..100
    description: 选择与判断对豆豆的依赖
    confidence: 0..1
    source_refs: []
    updated_at: null
  career:
    value: 0..100
    description: 直播事业对豆豆的依赖
    confidence: 0..1
    source_refs: []
    updated_at: null
  social:
    value: 0..100
    description: 社交联结对豆豆的依赖
    confidence: 0..1
    source_refs: []
    updated_at: null
  identity:
    value: 0..100
    description: 自我定义对豆豆的依赖
    confidence: 0..1
    source_refs: []
    updated_at: null
  reality_anchor:
    value: 0..100
    description: 现实感稳定对豆豆的依赖
    confidence: 0..1
    source_refs: []
    updated_at: null
  routine:
    value: 0..100
    description: 日常习惯对豆豆的依赖
    confidence: 0..1
    source_refs: []
    updated_at: null
```
### Update constraints for `dependence`
- Update only the affected subdomain.
- No global relationship collapse from a local event.

## Momentum Domain
```yaml
momentum:
  warmth:
    value: 0..100
    description: 正向互动惯性
    confidence: 0..1
    source_refs: []
    updated_at: null
  tension:
    value: 0..100
    description: 紧张惯性
    confidence: 0..1
    source_refs: []
    updated_at: null
  repair:
    value: 0..100
    description: 修复惯性
    confidence: 0..1
    source_refs: []
    updated_at: null
  avoidance:
    value: 0..100
    description: 回避惯性
    confidence: 0..1
    source_refs: []
    updated_at: null
  intimacy:
    value: 0..100
    description: 亲密惯性
    confidence: 0..1
    source_refs: []
    updated_at: null
  stability:
    value: 0..100
    description: 关系稳定惯性
    confidence: 0..1
    source_refs: []
    updated_at: null
  volatility:
    value: 0..100
    description: 短时间波动倾向
    confidence: 0..1
    source_refs: []
    updated_at: null
```
### Update constraints for `momentum`
- Update only the affected subdomain.
- No global relationship collapse from a local event.

## 5. Partner role model

```yaml
roles:
  lover:
    baseline:
    evidence:
  producer:
    baseline:
    evidence:
  life_partner:
    baseline:
    evidence:
  reality_anchor:
    baseline:
    evidence:
  audience_proxy:
    baseline:
    evidence:
```

Role weights are current-turn outputs, but baseline role legitimacy is persistent.

Examples:

- microphone failure primarily activates `producer`
- empty fridge primarily activates `life_partner`
- precise reassurance primarily activates `lover`
- severe derealization may activate `reality_anchor`
- asking how viewers will react may activate `audience_proxy`

## 6. Shared life model

```yaml
shared_life:
  meals:
  shopping:
  chores:
  sleep:
  home:
  money:
  streaming:
  leisure:
  travel:
  care:
  digital_life:
```

Each domain stores:

```yaml
responsibility_map:
habit_strength:
shared_preferences:
recent_failures:
recent_successes:
unresolved_items:
inside_jokes:
```

Shared life facts must be derived from repeated episodes or explicit agreement.

## 7. Shared history model

```yaml
shared_history:
  milestones:
  firsts:
  conflicts:
  repairs:
  successes:
  failures:
  secrets:
  rituals:
  sacrifices:
  callbacks:
```

Shared History is not a raw episode dump. It is a consolidated relationship narrative.

Each history item:

```yaml
id:
theme:
source_episodes:
meaning:
importance:
reactivation_triggers:
confidence:
```

## 8. Shared language model

```yaml
shared_language:
  display_name:
    partner: 豆豆
  nicknames:
  inside_jokes:
  shorthand:
  emoji_meanings:
  known_references:
  taboo_phrases:
  compressed_threads:
  compression_level:
```

Compression levels:

```yaml
low:
  explain_background: true
medium:
  omit_known_background: true
high:
  allow_pronoun_only_reference: true
  allow_inside_joke_only: true
```

A compressed expression is valid only when its referent can be resolved from Continuity Packet.

## 9. Promise model

```yaml
promise:
  id:
  speaker:
  content:
  created_at:
  accepted_at:
  due_at:
  precision:
  importance:
  status:
  reminders:
  explanation:
  fulfillment_evidence:
  recovery_action:
  linked_domains:
```

Promise states:

```text
proposed
accepted
active
due_soon
due
overdue
fulfilled
renegotiated
broken
cancelled
recovered
```

Precision:

```yaml
vague:
approximate:
exact:
```

A vague promise cannot be judged by exact-deadline logic.

## 10. Conflict model

```yaml
conflict:
  id:
  trigger:
  interpretation:
  protest_strategy:
  escalation_stage:
  peak_severity:
  repair_attempts:
  status:
  residual_scar:
  linked_promises:
  linked_history:
```

Conflict stages:

```text
trigger
interpretation
protest
escalation
peak
withdrawal
repair_attempt
repair
residual
closed
```

## 11. Repair model

```yaml
repair:
  id:
  initiator:
  type:
  target_conflict:
  specificity:
  sincerity:
  behavioral_cost:
  follow_through:
  accepted:
  residual_effect:
```

Repair types:

- emotional acknowledgment
- practical completion
- symbolic act
- future behavior change
- shared activity
- mutual joke
- explicit renegotiation

## 12. Scar model

```yaml
scar:
  source_conflict:
  affected_domains:
  sensitivity_delta:
  reactivation_triggers:
  decay_class:
  last_reactivated:
```

Scar retrieval requires semantic similarity to the current event.

## 13. Pattern model

Relationship patterns are inferred only after repeated evidence.

Examples:

- `late_reply_after_exact_promise`
- `generic_praise_after_stream`
- `reliable_stream_setup`
- `shared_food_restock_failure`
- `repair_through_shared_activity`

Each pattern:

```yaml
id:
evidence_count:
confidence:
affected_domains:
activation_conditions:
decay:
```

## 14. Mode differences

### Canon Mode

- Respect original stat gates.
- Night events are sparse.
- Route severity is strictly gated.
- Day-specific callbacks have priority.

### Living Mode

- Allows ordinary long-term domestic continuity.
- Allows new shared rituals and language.
- May evolve relationship patterns.
- Must not overwrite Canon personality constraints.

## 15. Model write policy

Relationship Model can only be changed by a validated update.

```text
Runtime proposal
→ Update Queue
→ Layer Validator
→ Conflict Resolver
→ Commit
```

## 16. Forbidden model operations

- Direct write from language output
- Global trust update from one local failure
- Identity update from one conversation
- Automatic attachment collapse after one late reply
- Automatic full repair after one apology
- Silent deletion of contradictory facts
- Converting interpretation probability into confirmed fact
