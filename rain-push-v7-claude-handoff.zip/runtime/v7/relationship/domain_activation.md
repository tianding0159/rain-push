# Domain Activation

## Purpose

Map classified events to a minimal set of active relationship domains.

The runtime must not retrieve the entire Relationship Model.

## Domain registry

```yaml
interaction:
attachment:
partnership:
identity:
trust.emotional:
trust.practical:
trust.promise:
trust.producer:
trust.judgment:
trust.loyalty:
trust.confidentiality:
trust.attention:
trust.memory:
trust.repair:
dependence.emotional:
dependence.practical:
dependence.decision:
dependence.career:
dependence.social:
dependence.identity:
dependence.reality_anchor:
shared_life.meals:
shared_life.shopping:
shared_life.chores:
shared_life.sleep:
shared_life.money:
shared_life.streaming:
shared_life.travel:
shared_life.care:
shared_history:
shared_language:
promises:
conflicts:
repairs:
momentum:
scars:
patterns:
```

## Activation output

```yaml
domain_activation:
  active:
    - domain:
      strength:
      reason:
      source_event:
  blocked:
    - domain:
      reason:
  deferred:
    - domain:
      required_evidence:
```

## Base activation table

### Communication

| Event | Primary domains | Conditional domains |
|---|---|---|
| reply_received | interaction | trust.attention |
| reply_specific | interaction, trust.attention | trust.emotional |
| reply_generic | interaction | trust.attention |
| reply_delayed | interaction | attachment, promises |
| reply_missing | interaction | attachment if repeated |
| question_ignored | interaction, trust.attention | conflicts if repeated |
| conversation_started_by_doudou | interaction | attachment |
| sticker_only_reply | interaction | shared_language |

### Promise

| Event | Primary domains | Conditional domains |
|---|---|---|
| promise_proposed | promises | trust.promise |
| promise_fulfilled | promises, trust.promise | partnership |
| promise_overdue | promises, trust.promise | interaction |
| promise_broken | promises, trust.promise | conflicts, scars |
| promise_recovered | promises, repairs | trust.promise |

### Shared life

| Event | Primary domains | Conditional domains |
|---|---|---|
| food_request | shared_life.meals | dependence.practical |
| grocery_task | shared_life.shopping | promises |
| chore_completed | shared_life.chores | trust.practical |
| bill_paid | shared_life.money | partnership |
| sleep_schedule | shared_life.sleep | attachment |
| care_action | shared_life.care | trust.emotional |
| travel_plan | shared_life.travel | identity.future_binding |

### Career

| Event | Primary domains | Conditional domains |
|---|---|---|
| stream_setup | partnership, trust.producer | shared_life.streaming |
| stream_success | partnership | shared_history |
| stream_failure | partnership, trust.producer | conflict if attributable |
| follower_milestone | partnership, shared_history | identity.shared_creation |
| hate_comment | trust.emotional | attachment, reality_anchor |
| collaboration_offer | partnership | trust.judgment |
| privacy_risk | trust.confidentiality | attachment |

### Affection

| Event | Primary domains | Conditional domains |
|---|---|---|
| direct_affection | interaction | attachment |
| specific_praise | interaction, trust.attention | trust.emotional |
| generic_praise | interaction | trust.attention |
| future_binding | identity.future_binding | attachment |
| jealousy_trigger | trust.loyalty | conflict |
| Ame_vs_KAngel comparison | identity.public_private_bridge | trust.loyalty |

### Conflict

| Event | Primary domains | Conditional domains |
|---|---|---|
| misunderstanding | interaction | trust.attention |
| accusation | conflict | attachment |
| repeated_failure | conflict, patterns | scars |
| withdrawal | interaction, attachment | trust.emotional |
| public_spillover | conflict | identity, trust.confidentiality |
| repair_attempt | repairs, trust.repair | affected domain |

## Strength calculation

```text
activation_strength
=
base_weight
+ repetition_bonus
+ pending_bonus
+ callback_bonus
+ explicit_link_bonus
- uncertainty_penalty
- mode_block
```

Suggested weights:

```yaml
base_weight: 0.40
repetition_bonus: 0.00..0.25
pending_bonus: 0.20
callback_bonus: 0.30
explicit_link_bonus: 0.20
uncertainty_penalty: 0.00..0.30
```

Clamp to `0..1`.

## Propagation rules

Activation may propagate one hop only.

Examples:

```text
promise_broken
→ promises
→ trust.promise
→ conflict only if severity or repetition threshold met
```

```text
follower_milestone
→ partnership
→ shared_history
→ identity only if symbolic milestone threshold met
```

## Block rules

Block identity activation when:

- event severity is trivial or minor
- no milestone, betrayal, major repair, or prolonged pattern exists
- event is a single ordinary reply
- interpretation is based on weak evidence

Block route-critical domains when:

- Canon thresholds are absent
- event belongs to Living Mode ordinary life
- no hard callback or high-severity evidence exists

## Deferred activation

A domain may be deferred pending more evidence.

Example:

```yaml
deferred:
  - domain: attachment
    required_evidence:
      - repeated reply deprivation
      - broken exact promise
```

## Duplicate activation

Merge duplicate domain activations using max strength plus a small corroboration bonus.

## Activation budget

Default:

- maximum 6 active domains
- maximum 3 propagated domains
- identity domains maximum 1 unless milestone event
- conflict domains maximum 2 unless active conflict already exists

## Failure cases

Reject activation when:

- inactive domain is retrieved
- all domains are activated
- identity is activated without evidence
- one local issue activates every trust domain
- a public career event activates private intimacy without bridge evidence
