# Salience Engine

## Purpose

Rank active relationship domains and retrieved items for the current turn.

Salience is current-turn importance, not long-term importance.

## Domain salience formula

```text
S_domain
=
0.28 * event_relevance
+ 0.16 * activation_strength
+ 0.12 * unresolved_weight
+ 0.10 * repetition_weight
+ 0.10 * role_relevance
+ 0.08 * recency
+ 0.08 * callback_weight
+ 0.05 * source_confidence
+ 0.03 * mode_fit
```

Clamp to `0..1`.

## Item salience formula

```text
S_item
=
0.30 * domain_salience
+ 0.20 * semantic_match
+ 0.15 * direct_link
+ 0.12 * unresolved_weight
+ 0.08 * recency
+ 0.08 * importance
+ 0.07 * confidence
```

## Weight definitions

### event_relevance

- 1.00 direct event domain
- 0.70 explicit secondary class
- 0.45 propagated domain
- 0.20 weak contextual relation
- 0.00 unrelated

### unresolved_weight

- 1.00 exact overdue promise or unanswered direct question
- 0.75 active conflict
- 0.50 open task
- 0.20 resolved but recent
- 0.00 closed and irrelevant

### repetition_weight

- 0.00 first event
- 0.25 occasional
- 0.60 repeated
- 1.00 confirmed pattern

### role_relevance

Computed from event:

```yaml
lover:
producer:
life_partner:
reality_anchor:
audience_proxy:
```

### callback_weight

- 1.00 hard Canon callback
- 0.70 active soft callback
- 0.30 optional callback
- 0.00 none

## Severity modifier

```yaml
trivial: 0.75
minor: 0.90
moderate: 1.00
major: 1.10
route_critical: 1.20
```

Severity cannot create a domain that was not activated.

## Negative evidence

Salience must include evidence against escalation.

Examples:

- recent stable communication
- prior notice of being busy
- promise not yet due
- message unread status unknown
- technical delivery failure

Negative evidence reduces rejection-oriented interpretations.

## Thresholds

```yaml
dominant: >= 0.75
active: >= 0.50
background: 0.35..0.49
omit: < 0.35
```

Only dominant and active domains enter Relationship Packet by default.

## Dominance tie

If two domains differ by less than `0.08`, both remain co-dominant.

## Salience hysteresis

To avoid turn-by-turn flicker:

```text
new_salience
=
0.70 * current_score
+ 0.30 * previous_turn_score
```

Do not apply hysteresis across unrelated events.

## Example: 豆豆忘记买布丁

```yaml
shared_life.shopping:
  event_relevance: 1.0
  activation_strength: 0.9
  unresolved_weight: 0.8
  role_relevance: 0.9
  result: high

trust.promise:
  event_relevance: 0.8
  activation_strength: 0.7
  unresolved_weight: 0.9
  result: active

identity:
  event_relevance: 0.0
  result: omitted
```

## Example: specific stream praise

```yaml
interaction: dominant
trust.attention: dominant
trust.producer: active
attachment: background
identity: omitted
```

## Failure cases

- treating long-term importance as current salience
- using emotional intensity that has not yet been computed
- assigning high identity salience to ordinary life
- ignoring negative evidence
- letting every repeated event become route-critical
