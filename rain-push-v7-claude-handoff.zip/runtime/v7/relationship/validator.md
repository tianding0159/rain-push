# Relationship Validator

## Purpose

Validate Relationship Packet and Update Queue before downstream use or model commit.

## Validation layers

### V1 Input validity

Reject when:

- Knowledge Packet missing
- Continuity Packet missing
- event id missing
- actor cannot be resolved
- packet versions incompatible

### V2 Domain validity

Reject when:

- packet references inactive domain
- all domains are active
- identity domain activated by trivial event
- trust globally activated instead of subdomain
- route-critical domain lacks gate

### V3 Retrieval validity

Reject when:

- whole Relationship Model is included
- unrelated trauma is retrieved
- unresolved exact promise is omitted
- hard callback is omitted
- shared-language shorthand lacks referent
- scar is retrieved without semantic match

### V4 Salience validity

Reject when:

- salience uses emotion output not yet available
- identity salience is high for ordinary life
- negative evidence is ignored
- score exceeds bounds
- dominant domain score is below threshold

### V5 Interpretation validity

Reject when:

- interpretation is presented as fact
- only negative interpretations are produced under uncertainty
- rejection or abandonment is dominant after one minor event
- emotion or need is emitted
- generic “缺乏安全感” replaces concrete event meaning
- candidate contradicts hard knowledge
- severity exceeds event and model support

### V6 Update validity

Reject when:

- event writes directly to Model
- identity is updated without milestone
- one event modifies unrelated trust domains
- one apology fully clears a major conflict
- one failure creates permanent pattern
- update exceeds per-event cap
- proposal lacks evidence and confidence

### V7 Naming validity

Runtime examples and generated structures use “豆豆”.

Original evidence quotations may preserve “阿P”.

### V8 Mode validity

Canon Mode:

- respects stat gates
- respects special-day callbacks
- blocks unsupported Living Mode development

Living Mode:

- may create new routines
- may not override Canon personality constraints
- may not randomize route-level darkness

## Validation result

```yaml
validation_result:
  status:
    pass
    pass_with_revisions
    reject
  errors:
  warnings:
  revisions:
  trace:
```

## Auto-revisions

Allowed:

- remove low-salience inactive domain
- downgrade unsupported severity
- normalize probabilities
- defer medium/slow update
- add omitted contradictory evidence

Not allowed:

- invent missing evidence
- change event facts
- create a new promise
- infer a major betrayal
- rewrite Canon knowledge

## Canon-specific checks

1. Ame and KAngel share underlying relationship memory.
2. 豆豆 may be lover, producer, life partner, or anchor.
3. Precise responses can genuinely improve the relationship state.
4. Ordinary life must not be automatically crisis-coded.
5. Career conflict must not automatically become abandonment conflict.
6. Dark humor must not automatically become route danger.
7. High affection may increase future-binding and demands, not simple obedience.
8. Trust is domain-specific.
9. KAngel public performance cannot erase private shared history.
10. One local event cannot rewrite identity.

## Failure library tags

```yaml
GENERIC_YANDERE
OVER_ESCALATION
GLOBAL_TRUST_COLLAPSE
IDENTITY_JUMP
UNRELATED_TRAUMA
AI_THERAPY_LANGUAGE
NO_BENIGN_INTERPRETATION
MISSING_PROMISE
INVALID_SHARED_LANGUAGE
EMOTION_LEAK
NEED_LEAK
LANGUAGE_LEAK
```
