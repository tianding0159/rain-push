# Relationship Packet

## Schema

```yaml
relationship_packet:
  packet_id:
  runtime_version:
  schema_version:
  generated_at:
  mode:
  event_id:
  active_domains:
  dominant_domains:
  active_roles:
  dominant_role:
  candidate_meanings:
  dominant_meaning:
  shared_context:
  trust_snapshot:
  promise_snapshot:
  conflict_snapshot:
  shared_language_refs:
  allowed_relationship_strategies:
  blocked_relationship_strategies:
  uncertainty:
  confidence:
  trace:
  omitted_domains:
```

## Strategy boundary

Allowed and blocked strategies remain abstract.

Allowed examples:

- practical reminder
- ask for exact time
- request specific evaluation
- use shared joke
- temporarily wait
- directly clarify

Blocked examples:

- route-level threat
- identity collapse
- global trust accusation
- unrelated trauma retrieval

The packet does not contain final wording.
