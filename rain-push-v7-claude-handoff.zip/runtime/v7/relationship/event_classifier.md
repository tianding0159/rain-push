# Event Classifier

## Purpose

Classify the current event into relationship-relevant event classes without producing emotion or interpretation.

## Input

```yaml
event:
  id:
  actor:
  target:
  channel:
  timestamp:
  content:
  structured_action:
  linked_entities:
  linked_threads:
```

## Output

```yaml
event_classification:
  primary_class:
  secondary_classes:
  attributes:
  confidence:
  evidence_refs:
```

## Primary classes

### 1. communication

Subclasses:

- reply_received
- reply_delayed
- reply_missing
- reply_generic
- reply_specific
- question_ignored
- topic_changed
- conversation_started_by_ame
- conversation_started_by_doudou
- message_read
- message_unread
- call_answered
- call_missed
- sticker_only_reply
- emoji_only_reply

### 2. promise

Subclasses:

- promise_proposed
- promise_accepted
- promise_due_soon
- promise_fulfilled
- promise_overdue
- promise_broken
- promise_renegotiated
- promise_cancelled
- promise_recovered

### 3. shared_life

Subclasses:

- food_request
- grocery_task
- inventory_change
- chore_assignment
- chore_completed
- chore_ignored
- bill_arrived
- bill_paid
- sleep_schedule
- shared_meal
- travel_plan
- care_action
- home_equipment_issue

### 4. career

Subclasses:

- stream_planning
- stream_setup
- stream_success
- stream_failure
- follower_growth
- follower_stagnation
- collaboration_offer
- sponsorship
- hate_comment
- moderation
- public_recognition
- privacy_risk
- monetization
- milestone

### 5. affection

Subclasses:

- direct_affection
- specific_praise
- generic_praise
- physical_intimacy
- future_binding
- jealousy_trigger
- preference_comparison
- ame_vs_kangel_comparison
- reassurance_request

### 6. care

Subclasses:

- practical_help
- emotional_support
- health_check
- food_preparation
- rest_encouragement
- safety_intervention
- accompaniment
- grounding

### 7. conflict

Subclasses:

- misunderstanding
- accusation
- invalidation
- broken_boundary
- repeated_failure
- sarcasm
- withdrawal
- threat
- public_spillover
- repair_attempt

### 8. identity

Subclasses:

- shared_creation
- we_statement
- future_plan
- exclusive_witness
- public_private_bridge
- identity_comparison
- role_confirmation
- major_betrayal
- major_repair

### 9. callback

Subclasses:

- callback_created
- callback_triggered
- callback_resolved
- callback_failed
- canon_hard_callback
- living_soft_callback

### 10. external

Subclasses:

- weather
- holiday
- news
- platform_change
- device_failure
- financial_change
- location_change
- schedule_change

## Event attributes

```yaml
attributes:
  intentionality:
    accidental
    negligent
    deliberate
    unknown
  severity:
    trivial
    minor
    moderate
    major
    route_critical
  repetition:
    first
    occasional
    repeated
    pattern
  timing_precision:
    none
    vague
    approximate
    exact
  publicness:
    private
    semi_public
    public
  reversibility:
    easy
    moderate
    difficult
    irreversible
  evidence_strength:
    direct
    strong
    weak
    inferred
```

## Classification precedence

1. Hard callback
2. Safety or route-critical event
3. Explicit promise state transition
4. Explicit conflict action
5. Shared-life or career action
6. Communication surface
7. External context

An event may have one primary class and up to four secondary classes.

## Deterministic rules

```yaml
- when:
    structured_action: exact_promise_missed
  emit:
    primary_class: promise
    secondary_classes: [communication, conflict]

- when:
    structured_action: specific_stream_feedback
  emit:
    primary_class: career
    secondary_classes: [communication, affection]

- when:
    structured_action: pudding_missing
  emit:
    primary_class: shared_life
    secondary_classes: [promise_if_linked]

- when:
    structured_action: no_reply
  emit:
    primary_class: communication
    secondary_classes:
      - promise_if_due
      - attachment_if_repeated
```

## Prohibited classification shortcuts

- `reply_missing` does not automatically equal rejection.
- `generic_praise` does not automatically equal dislike.
- `stream_failure` does not automatically equal relationship conflict.
- `dark language` does not automatically equal route-critical.
- `sex joke` does not automatically equal intimacy event.
- `KAngel public language` does not automatically equal false emotion.

## Failure cases

Reject classification when:

- event content is empty and no structured action exists
- actor is unknown and actor identity matters
- a promise class is assigned without a linked promise
- route-critical is assigned without Canon or safety evidence
- identity event is assigned to a trivial single exchange
