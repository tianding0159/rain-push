# Runtime Naming Policy

## Partner name

在 Runtime、模型规则、测试场景、示例和未来生成语料中：

```yaml
partner_display_name: 豆豆
```

统一使用“豆豆”，不再使用“阿P”。

## Canon source preservation

原始语料、原作对白和证据引用中的“阿P”属于原作文本，不应擅自改写。
进入 Runtime 规则层后，将该角色位映射为：

```yaml
canon_role: P
runtime_name: 豆豆
```

因此：

- 证据层引用原句时保留“阿P”
- 行为模型、关系模型和 Living Mode 使用“豆豆”
- 未来生成的新语料使用“豆豆”
- 字段名可继续使用抽象角色标识 `partner`，避免把显示名写死进代码
