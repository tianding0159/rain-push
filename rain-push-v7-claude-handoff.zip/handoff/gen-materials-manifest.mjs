// Regenerates materials_manifest.json — the file-level SHA-256 inventory of the
// handoff package. Paths are relative to the package root (the handoff/ workspace,
// which is the zip root). The manifest excludes itself. Categories are preserved
// from the previous manifest; new files are categorized by a small rule set.
// Run from the package root: node handoff/gen-materials-manifest.mjs
import { readFileSync, writeFileSync, statSync, readdirSync } from "node:fs";
import { createHash } from "node:crypto";
import { join, relative, extname } from "node:path";
import { fileURLToPath } from "node:url";

const here = fileURLToPath(new URL(".", import.meta.url)); // .../handoff/handoff/
const packageRoot = join(here, ".."); // .../handoff  (zip root)
const manifestPath = join(here, "materials_manifest.json");
const manifestRel = relative(packageRoot, manifestPath).replaceAll("\\", "/");

const prev = JSON.parse(readFileSync(manifestPath, "utf8"));
const prevCategory = new Map(prev.files.map((f) => [f.path, f.category]));

// Category rules for files not present in the previous manifest.
function categorize(relPath) {
  if (prevCategory.has(relPath)) return prevCategory.get(relPath);
  if (relPath.startsWith("runtime/v7/engine/parity/")) return "phase12_documentation";
  if (relPath.startsWith("runtime/v7/engine/tests/")) return "phase12_executable_tests";
  if (relPath.startsWith("runtime/v7/engine/src/")) return "phase12_executable_engine";
  if (relPath.startsWith("handoff/")) return "claude_handoff";
  return "runtime_root";
}

function walk(dir, acc = []) {
  for (const name of readdirSync(dir)) {
    const abs = join(dir, name);
    const st = statSync(abs);
    if (st.isDirectory()) walk(abs, acc);
    else acc.push(abs);
  }
  return acc;
}

const all = walk(packageRoot)
  .map((abs) => relative(packageRoot, abs).replaceAll("\\", "/"))
  .filter((rel) => rel !== manifestRel) // manifest excludes itself
  .sort();

const files = [];
let totalBytes = 0;
const categoryCounts = {};
for (const rel of all) {
  const abs = join(packageRoot, rel);
  const buf = readFileSync(abs);
  const bytes = buf.length;
  const lines = buf.toString("utf8").split("\n").length;
  const sha256 = createHash("sha256").update(buf).digest("hex");
  const category = categorize(rel);
  files.push({ path: rel, category, extension: extname(rel), bytes, lines, sha256 });
  totalBytes += bytes;
  categoryCounts[category] = (categoryCounts[category] || 0) + 1;
}

// deterministic category ordering
const orderedCounts = {};
for (const k of Object.keys(categoryCounts).sort()) orderedCounts[k] = categoryCounts[k];

const out = {
  manifest_version: prev.manifest_version,
  project: prev.project,
  package: prev.package,
  self_hash_policy: prev.self_hash_policy,
  file_count_excluding_manifest: files.length,
  file_count_including_manifest: files.length + 1,
  total_bytes_excluding_manifest: totalBytes,
  category_counts: orderedCounts,
  files,
};

writeFileSync(manifestPath, JSON.stringify(out, null, 2) + "\n");
console.log(
  `wrote ${manifestRel}: ${files.length} files (excl manifest), ${totalBytes} bytes`,
);
for (const [k, v] of Object.entries(orderedCounts)) console.log(`  ${k}: ${v}`);
