# Direct Bootstrap Prompt for Claude

Paste the following into Claude together with this archive:

---

You are taking over development of `rain-push v7`.

The archive is a cumulative Phase 1–12 Ame / KAngel character-runtime project. It contains the complete written architecture, schemas, DSL examples, validators, tests, and a runnable zero-dependency Node.js reference engine.

Start by reading:

1. `CLAUDE.md`
2. `START_HERE_CLAUDE.md`
3. `handoff/PROJECT_CONCEPT.md`
4. `handoff/CURRENT_IMPLEMENTATION.md`
5. `handoff/DECISION_LOG.md`
6. `handoff/NEXT_ACTIONS.md`
7. `handoff/KNOWN_LIMITATIONS.md`
8. `runtime/v7/engine/README.md`

Then run:

```bash
cd runtime/v7/engine
npm test
```

The expected baseline is:

```text
166 pass
0 fail
```

Do not make changes before reporting the real baseline result.

Your first development task is **Hardening Sprint 1: Spec–Engine Parity Audit**.

Do not invent Phase 13.

Build a requirement-level parity map connecting every Phase 1–11 specification to:

- schema field
- DSL rule
- JavaScript implementation
- validator
- executable test

Classify every requirement as:

- implemented
- partial
- specification-only
- tested
- untested
- blocked

Create:

```text
runtime/v7/engine/parity/
├── parity-matrix.json
├── parity-matrix.md
├── high-risk-gaps.md
├── schema-field-map.json
└── runtime-contract-map.json
```

Add automated tests for high-risk invariants:

- public/private leakage
- execution claims
- route leakage
- cross-runtime mutation
- fact/hypothesis collapse
- local/global escalation
- message-budget violations
- no-surface violations
- consent and intimacy boundaries
- deterministic replay

Preserve these invariants:

- generated partner naming uses `豆豆`
- Ame and KAngel are two surfaces of one person
- local events remain local unless evidence supports escalation
- ordinary life remains first-class
- generic reassurance does not counterfeit specific feedback
- dark humor does not automatically become crisis
- sexual jokes do not automatically become intimacy
- drug references do not automatically become severe state or operational instruction
- public and private information remain separated
- Language Packet never proves external execution
- `executionStatus` stays `not_executed` until a real confirmed handler succeeds

The current executable engine is a narrow deterministic reference implementation. Do not claim it has full natural-language coverage.

At the end:

1. list every changed file
2. run the complete test suite
3. report pass/fail counts honestly
4. update changelogs and status
5. regenerate `handoff/materials_manifest.json`
6. package the complete cumulative repository

Do not delete Phase materials or replace the architecture with one large prompt.

---
