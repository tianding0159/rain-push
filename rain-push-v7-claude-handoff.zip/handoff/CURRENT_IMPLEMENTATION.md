# Current Implementation

## 1. Cumulative repository

All Phase 1–12 materials are under:

```text
runtime/v7/
```

Phase folders contain specifications, schemas, DSL rules, examples, validators, and tests.

Executable engine:

```text
runtime/v7/engine/
```

## 2. Executable stack

Runtime order:

```text
knowledge
continuity
relationship
meaning
emotion
need
thought
decision
behavior
expression
language
```

Main entry point:

```text
runtime/v7/engine/src/orchestrator.js
```

Public exports:

```text
runtime/v7/engine/src/index.js
```

CLI:

```text
runtime/v7/engine/src/cli.js
```

## 3. Engine features

Implemented:

- RuntimeEvent validation
- typed signal detection
- fixed runtime registry
- versioned Packets
- deterministic Packet IDs and hashes
- deterministic pipeline hash
- cross-packet validation
- update proposal collection
- update ownership and delta validation
- transactional commit after pipeline validation
- memory state store
- JSON-file state store
- bounded history
- Runtime Bus
- structured loggers
- replay engine
- dry-run execution boundary
- CLI
- JavaScript API
- executable scenarios and properties

## 4. Built-in scenario families

First-class rule paths currently include:

- generic stream feedback
- specific feedback
- prior notice
- overdue promise
- unknown return time
- forgotten pudding
- pudding callback
- post-stream fatigue
- live-to-private transition
- stream success
- million followers
- one low-value troll
- audience attack
- privacy exposure
- control overreach
- hunger
- illness
- dark humor
- sexual joke
- drug reference

## 5. Current rendered reference outputs

```text
generic vague feedback
→ 具体哪里好

overdue return time
→ 所以你到底几点回来

plain pudding omission
→ 布丁没了

pudding callback
→ 布丁库存管理又不合格

post-stream fatigue
→ 我先躺会儿，数据晚点看

million followers
→ 大家看到了吗！今天真的冲上去了！

privacy exposure
→ 涉及隐私的内容全部停传。

autonomy boundary
→ 别替我决定，我自己选。
```

These are reference outputs for typed scenarios, not universal templates.

## 6. Tests

Run:

```bash
cd runtime/v7/engine
npm test
```

Expected baseline:

```text
166 pass
0 fail
```

Breakdown:

- 16 baseline integration tests
- 100 executable scenario tests
- 50 executable property tests

## 7. State

State shape includes:

- engine version
- revision
- per-runtime counters
- pattern containers
- memory containers
- bounded event history
- pending rejected updates
- last Packet hashes

Current learning is intentionally conservative.

Most executable updates are scenario counters, not a complete adaptive policy learner.

## 8. Execution

The runtime generates final text.

It does not deliver it.

Execution is isolated under:

```text
runtime/v7/engine/src/execution/execution-boundary.js
```

Default mode is dry-run.

## 9. Implementation style

The engine is:

- deterministic
- inspectable
- rule-based
- intentionally narrow
- zero-dependency
- suitable as a reference baseline

It is not:

- a complete Canon simulator
- a general LLM
- a full DSL interpreter
- a production notification service
- a weather-data client
- an autonomous sender
