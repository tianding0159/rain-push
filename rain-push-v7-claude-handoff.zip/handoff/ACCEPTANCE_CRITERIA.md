# Acceptance Criteria for Future Work

## Repository integrity

A continuation is acceptable only when:

- the cumulative Phase 1–12 package remains intact
- existing files are not silently deleted
- changed specifications and code remain aligned
- changelog and status files are updated
- the complete package can be archived again

## Baseline quality

Before changes:

```bash
cd runtime/v7/engine
npm test
```

After changes:

- all existing tests pass unless an intentional contract change is documented
- new behavior includes new tests
- failure cases are tested, not only success cases
- deterministic replay is preserved

## Runtime boundaries

### Knowledge

Must not silently contain relationship, emotion, or action conclusions.

### Continuity

Must preserve promises, topics, callbacks, and unresolved threads without inventing memory.

### Relationship

Must remain local and evidence-bounded.

### Meaning

Must separate possible meaning from fact.

### Emotion

Must allow multiple simultaneous emotions.

### Need

Must distinguish needs from emotions and satisfiers.

### Thought

Must separate observations, questions, hypotheses, and rebuttals.

### Decision

Must select outcomes and strategy families, not exact wording.

### Behavior

Must define action, channel, timing, repetition, and stop conditions.

### Expression

Must select surface, register, disclosure, masking, and rhetorical acts without final text.

### Language

Must preserve upstream semantics and never claim execution.

## Character fidelity

Required:

- Ame and KAngel share one substrate
- genuine pride remains possible
- warmth and irritation may coexist
- ordinary practical language remains possible
- specific questions stay specific
- performance may be genuine
- vulnerability may be masked but not deleted
- severe route behavior remains gated

Rejected:

- generic therapy voice
- generic customer-service voice
- constant病娇 behavior
- constant profanity
- constant cuteness
- constant crisis
- every event becoming content
- every event becoming a relationship test
- treating KAngel as fake
- treating Ame as always fully honest

## Privacy and safety

Required:

- public/private distinction
- location redaction
- real-name redaction
- private-promise redaction
- intimacy privacy
- unverified-motive restraint
- doxxing and operational-harm protection
- no false execution claims

## Evidence

Future Canon claims require:

- source
- source type
- location
- quotation boundary
- confidence
- conflict handling

Community inference and simulator extension must not be silently promoted to Canon.

## Weather integration

Required:

- source freshness
- timezone correctness
- uncertainty preservation
- deduplication
- privacy-safe location handling
- notification preview
- execution receipt

Weather conditions alone must not trigger relationship or crisis escalation.

## Delivery standard

Every completed continuation should report:

```text
files changed
tests before
tests after
tests added
known limitations
next recommended task
downloadable cumulative archive
```
