# Architectural Decision Log

## D001 State before language

Final text is the last stage, not the main state container.

Reason: surface imitation without internal state creates dramatic but incoherent responses.

## D002 Evidence and interpretation are separate

Evidence Runtime stores sourced claims and confidence.

Meaning, Emotion, Need, and Thought Runtimes may interpret them, but may not rewrite the evidence.

## D003 Locality before escalation

A local failure remains local unless repeated evidence supports a broader pattern.

Examples:

- one delayed reply is not relationship abandonment
- one weak stream is not career collapse
- one troll is not the entire audience
- one forgotten pudding is not betrayal

## D004 Specific satisfaction

Specific needs require matching satisfiers.

Examples:

- recognition specificity needs concrete feedback
- uncertainty reduction needs bounded information
- practical completion needs task completion
- privacy needs exposure containment

Generic affection or reassurance must not counterfeit another need.

## D005 Ame and KAngel share one mind

They are surfaces, not agents.

Memory, emotion, needs, thought, and decisions are shared.

## D006 Performance can be genuine

KAngel theatricality may amplify genuine pride, affection, excitement, anger, or fear.

Performance is not automatically deception.

## D007 Ordinary life is first-class

Food, sleep, weather, practical tasks, and quiet presence are modeled directly.

Ordinary events must not be forced into relationship, identity, or crisis frames.

## D008 Contradiction is allowed

The runtime may preserve:

- affection and irritation
- pride and pressure
- privacy and audience ambition
- closeness and autonomy
- rest and career growth
- performance high and fatigue

The validator should block false flattening.

## D009 Waiting and silence are explicit behaviors

They require reasons, boundaries, stop conditions, and re-entry triggers.

Silence is not automatically punishment.

## D010 Public and private remain separated

Public language has:

- persistence
- screenshot risk
- context collapse
- privacy redaction

Private repair should not become audience content without an explicit bridge.

## D011 Adult and dark context is interpreted, not keyword-triggered

Dark humor, sexual jokes, and drug references are context-sensitive.

They do not automatically activate crisis, intimacy, or severe body behavior.

## D012 Each runtime owns its state

Update Queues may write only to their own model namespace.

Cross-runtime direct mutation is rejected.

## D013 Determinism

The same event, state, version, time bucket, and seed should produce the same Packets and final output.

Reason: reproducibility, replay, testing, and safe refactoring.

## D014 Final language is not execution

Language Packet can contain final text.

It cannot claim that the text was sent, posted, spoken, deleted, scheduled, or delivered.

External effects require `ExecutionBoundary`.

## D015 Zero-dependency reference engine

Phase 12 uses Node.js ESM with no external npm dependencies.

Reason:

- portable baseline
- easy auditing
- offline tests
- reduced handoff friction

This is a reference constraint, not a permanent ban on production dependencies.

## D016 Typed signals before broad heuristics

Production integrations should emit structured context and signals.

Text heuristics are fallback aids, not the canonical event classifier.

## D017 No new Phase after Phase 12 by default

The conceptual architecture is complete.

Further work should be described as:

- hardening
- parity
- expansion
- integration
- evaluation
- deployment

rather than inventing Phase 13 without a genuinely new responsibility boundary.
