# Materials and Provenance

## 1. What is included

This handoff package contains all project materials used to build the current cumulative runtime:

### Architecture and status

- root runtime overview
- Phase status files
- naming policy
- runtime bus notes
- final completion status

### Phase 1: Evidence / Knowledge

- evidence policy
- evidence schema
- confidence model
- extractor specification
- fact builder
- Canon validator
- Knowledge Model
- Knowledge Runtime
- Knowledge Packet
- pipeline documentation

### Phase 2: Continuity

- continuity model
- runtime
- packet
- update queue
- validator
- schema
- tests

### Phase 3–11

Each Phase includes combinations of:

- README
- model specification
- domain definitions
- activation or selection logic
- Packet specification
- Update Queue
- Validator
- YAML schemas
- DSL rules
- examples
- scenario tests
- property tests
- changelog
- status file

### Phase 12

- executable Node.js engine
- eleven runtime modules
- orchestrator
- registry
- signal detector
- Packet hashing
- validators
- state stores
- update-queue commit engine
- Runtime Bus
- logging adapters
- replay engine
- execution boundary
- CLI
- examples
- executable tests
- test report
- architecture and integration documentation

### Claude handoff materials

- project concept
- decision log
- current implementation
- known limitations
- next actions
- acceptance criteria
- machine-readable project context
- complete file manifest
- direct bootstrap prompt

## 2. File-level provenance

`materials_manifest.json` records for every included file:

- relative path
- file extension
- size
- line count for text files
- SHA-256 hash
- inferred project category

Use this manifest to detect missing or altered materials.

## 3. External material status

No web pages, remote repositories, images, audio files, font files, or binary model weights were needed to create the Phase 12 reference engine.

The current package is self-contained for:

- reading specifications
- running the reference engine
- running tests
- continuing implementation

## 4. Original dialogue corpus status

A complete official copyrighted dialogue corpus is not included.

The repository contains:

```text
runtime/v7/corpus/annotation_contract.md
```

This defines how future corpus material should be annotated.

Any future dialogue corpus should be provided or collected separately and must preserve:

- source provenance
- quotation boundaries
- file and line references
- Canon status
- confidence
- copyright constraints

Do not infer that a corpus exists merely because the architecture supports one.

## 5. Generated material status

Most files in this package are project specifications, schemas, examples, tests, and reference implementation code created during the Phase 1–12 design process.

They describe intended runtime behavior.

The executable engine does not yet implement every written requirement.

## 6. Source-of-truth hierarchy

Until rule-source unification is completed:

1. architectural invariants and Phase boundary documents
2. executable tests
3. JavaScript reference implementation
4. YAML schemas
5. DSL examples
6. illustrative output examples

When these conflict:

- do not silently choose one
- document the conflict
- add it to the parity audit
- preserve existing behavior until a versioned decision is made

## 7. Sensitive material

The package should not include:

- user credentials
- personal addresses
- API tokens
- private messages not needed for the runtime
- unredacted execution logs
- private health records
- full copyrighted dialogue dumps without permission

## 8. Integrity

The handoff archive should be regenerated after changes.

The manifest should be regenerated last so its hashes describe the final content.
