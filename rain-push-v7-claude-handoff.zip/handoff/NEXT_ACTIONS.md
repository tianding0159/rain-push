# Next Actions

## Recommended immediate task

Do not create a new conceptual Phase.

Begin with:

# Hardening Sprint 1: Spec–Engine Parity Audit

The Phase 1–11 written architecture is substantially broader than the Phase 12 JavaScript implementation.

The first continuation must identify that gap precisely before adding more behavior.

## Sprint 1 objective

Create a machine-readable parity map connecting:

```text
Phase specification requirement
→ schema field
→ DSL rule
→ JavaScript implementation
→ validator
→ executable test
```

Every requirement should receive one status:

```yaml
implemented:
partial:
specification_only:
tested:
untested:
blocked:
```

## Sprint 1 deliverables

Create:

```text
runtime/v7/engine/parity/
├── parity-matrix.json
├── parity-matrix.md
├── high-risk-gaps.md
├── schema-field-map.json
└── runtime-contract-map.json
```

Add tests:

```text
runtime/v7/engine/tests/
├── parity-contract.test.js
├── packet-contract.test.js
└── spec-coverage.test.js
```

Update:

```text
runtime/v7/engine/TEST_REPORT.md
runtime/v7/engine/CHANGELOG.md
runtime/v7/PHASE12_STATUS.md
handoff/materials_manifest.json
```

## Sprint 1 process

### Step 1: establish baseline

```bash
cd runtime/v7/engine
npm test
```

Expected:

```text
166 pass
0 fail
```

### Step 2: inventory requirements

Read every relevant specification file in:

```text
runtime/v7/evidence/
runtime/v7/engines/continuity/
runtime/v7/relationship/
runtime/v7/meaning/
runtime/v7/emotion/
runtime/v7/need/
runtime/v7/thought/
runtime/v7/decision/
runtime/v7/behavior/
runtime/v7/expression/
runtime/v7/language/
```

Extract requirements, not prose summaries.

Each requirement should include:

- phase
- source file
- heading
- requirement text
- severity
- runtime owner
- expected Packet field
- expected validator behavior
- expected test

### Step 3: map implementation

Map each requirement to:

- JavaScript file
- exported function
- relevant branch or rule
- Packet field
- test file
- test name

Do not mark a requirement implemented merely because a concept with the same name exists.

### Step 4: prioritize gaps

High-risk first:

1. public/private leakage
2. execution claims
3. route leakage into Living Mode
4. cross-runtime mutation
5. fact-to-hypothesis collapse
6. local-to-global escalation
7. message-budget violation
8. no-surface output violation
9. consent and intimacy boundary
10. deterministic replay

### Step 5: add executable contract tests

The first code changes should be validators and tests, not new dialogue.

### Step 6: report

Provide:

- baseline before changes
- files changed
- new parity statistics
- tests added
- pass/fail result
- remaining high-risk gaps

## Sprint 1 acceptance criteria

- baseline tests still pass
- parity map covers every Phase folder
- every high-risk invariant has an executable test
- no undocumented engine behavior is introduced
- no external execution is connected
- no private source corpus is invented
- deterministic hashes remain stable unless an intentional version bump is documented

---

# Hardening Sprint 2: Schema and Type Safety

Start only after Sprint 1.

## Goal

Make Packet contracts enforceable and reduce document–code drift.

## Recommended work

- migrate engine source to TypeScript or add strict JSDoc type checking
- generate JSON Schema from a canonical contract source
- validate every Packet at runtime
- validate Update Queue targets and enums
- add schema migration versioning
- add failing fixtures for malformed Packets
- preserve zero-network testability

## Acceptance criteria

- compile or type-check command exists
- all Packets pass generated schemas
- invalid enum and missing field tests fail correctly
- existing 166 tests remain green or are deliberately versioned

---

# Hardening Sprint 3: Rule Source Unification

## Goal

Stop maintaining separate DSL, Markdown, and JavaScript behavior manually.

## Recommended architecture

```text
canonical rule definition
→ validator
→ generated runtime rule table
→ generated documentation fragment
→ generated conformance fixtures
```

Possible canonical formats:

- YAML rule objects
- typed TypeScript rule definitions
- a small compiled DSL

Do not build a complex parser before the parity audit identifies real needs.

## Initial target

Compile three rule families first:

1. generic stream feedback
2. prior-notice waiting and overdue promises
3. pudding ordinary-life behavior

These cover:

- specificity
- waiting
- deadlines
- ordinary life
- play
- anti-escalation

---

# Expansion Sprint 4: Evidence and Corpus Pipeline

## Goal

Turn Phase 1 evidence policy into an actual ingestion workflow.

## Required properties

- source ID
- source type
- location pointer
- quotation boundaries
- confidence
- Canon / guide / community / simulator classification
- conflict resolution
- copyright-aware storage
- no unsourced claim silently becoming Canon

## Important limitation

The current package does not include a full official dialogue corpus.

Do not fabricate one.

Any user-provided corpus should remain separately traceable.

---

# Expansion Sprint 5: Weather Product Adapter

## Goal

Connect the character core to the actual rain and weather product.

## Proposed event types

```yaml
weather_forecast_received:
rain_expected_today:
rain_expected_morning:
rain_starting_soon:
rain_ended:
temperature_drop:
severe_weather_alert:
forecast_changed:
location_changed:
notification_window_open:
```

## Weather adapter responsibilities

- fetch or receive forecast data outside the character runtime
- attach source and freshness
- normalize timezone
- detect rain windows
- avoid duplicate pushes
- create typed RuntimeEvents
- keep weather facts separate from character interpretation

## Example event

```json
{
  "eventId": "weather-rain-morning-001",
  "timestamp": "2026-08-07T07:30:00+08:00",
  "mode": "living",
  "channel": "public_post",
  "actor": "system",
  "signals": ["rain_expected_morning"],
  "context": {
    "scenario": "weather_notification",
    "weather": {
      "condition": "rain",
      "probability": 0.82,
      "start": "2026-08-07T09:00:00+08:00",
      "end": "2026-08-07T13:00:00+08:00",
      "source": "external_weather_adapter",
      "fetchedAt": "2026-08-07T07:25:00+08:00"
    }
  }
}
```

## Weather-specific invariants

- rain does not imply abandonment
- severe weather safety may override persona flourish
- stale forecasts may not trigger confident language
- notification language must preserve exact forecast uncertainty
- no notification is sent without an execution handler
- user location and privacy remain outside public character output

---

# Expansion Sprint 6: Constrained LLM Renderer

## Goal

Increase language variety without giving the model authority over state, decisions, privacy, or execution.

## Recommended boundary

```text
Phase 1–10 deterministic Packets
→ constrained LLM candidates
→ Phase 11 semantic and privacy validator
→ deterministic candidate selection
→ Language Packet
```

The LLM may vary:

- wording
- sentence rhythm
- mild persona markers
- compression

The LLM may not vary:

- facts
- target outcome
- Behavior
- message count
- disclosure level
- public/private boundary
- execution status

## Required protections

- structured prompt from Packets
- JSON output
- candidate count limit
- semantic coverage check
- privacy redaction
- repetition check
- deterministic fallback
- no network dependency in baseline tests

---

# Production Sprint 7: Persistence, API, and Delivery

## Goal

Deploy safely.

## Recommended components

- SQLite or PostgreSQL state adapter
- schema migrations
- transaction boundaries
- REST or local API
- weather scheduler
- notification preview UI
- user confirmation path
- push-notification execution adapter
- execution receipts
- encrypted secrets
- monitoring and replay dashboard

## Non-negotiable production rule

```text
rendered language
≠
delivery receipt
```

Delivery state must come from the execution adapter, never from Language Runtime.
