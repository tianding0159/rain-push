# Project Concept

## 1. Mission

Build the most faithful, inspectable, and extensible Ame / KAngel digital-character runtime possible without reducing the character to a list of catchphrases.

The runtime should reproduce causal character behavior:

- what she notices
- what she remembers
- how she interprets 豆豆
- what an event means to her career, audience, identity, ordinary life, and future
- which emotions coexist
- what she actually lacks
- which thoughts remain unresolved
- what she decides to pursue
- what she does
- which expression surface appears
- how the final language is rendered

The system should feel alive because state changes are coherent, not because the output is decorated.

## 2. Product direction

The broader product is `rain-push`, a weather and notification experience with a persistent Ame / KAngel character layer.

The current repository focuses on the character runtime core.

Weather-specific ingestion, scheduling, morning-rain notification logic, push delivery, and app UI are integration work after the core is hardened.

The intended future product loop is:

```text
weather data / calendar time / user events / app events
→ typed RuntimeEvent
→ character runtime
→ Language Packet
→ notification preview
→ confirmed execution adapter
→ push notification or app surface
→ user response
→ continuity and state update
```

Weather must remain weather. Rain alone must not become abandonment, crisis, or relationship drama.

## 3. Why the architecture is layered

A large character card tends to collapse several different questions into one prompt:

- what happened
- what is true
- what the character believes
- what she feels
- what she wants
- what she will do
- how she speaks

That creates dramatic but ungrounded output.

The layered runtime prevents those category errors.

Example:

```text
Event:
豆豆只回复“很强”。

Meaning:
反馈的信息量低。

Emotion:
烦躁、脆弱、仍然在意。

Need:
需要具体评价与准确回应。

Thought:
豆豆到底看完整场了吗？

Decision:
取得具体反馈。

Behavior:
在 JINE 中只问一次。

Expression:
Ame 私下直接，带一点局部抱怨。

Language:
“具体哪里好”
```

No layer is allowed to skip directly to:

```text
“你从来都不在乎我”
```

without supporting evidence.

## 4. Character model

### Shared substrate

Ame and KAngel share:

- identity continuity
- memory
- factual knowledge
- relationship state
- emotion
- needs
- thought
- decisions

### Different expression surfaces

Ame may be:

- direct
- practical
- sharp
- bored
- tender
- embarrassed
- proud
- tired
- playful
- guarded

KAngel may be:

- genuinely excited
- theatrical
- audience-facing
- symbolic
- grateful
- triumphant
- controlled
- defensive
- tired while performing

KAngel is not merely fake.

Ame is not automatically the only real self.

## 5. Relationship target

The runtime uses `豆豆` as the partner display name.

The relationship may include:

- partner
- producer
- collaborator
- household companion
- trusted observer
- source of recognition
- source of practical coordination
- source of conflict or repair

A single event should activate only the relevant relationship domain.

## 6. Canon and Living Mode

### Canon Mode

Used when original-route logic, original day/stat rules, hard callbacks, or ending-specific states matter.

Route-level escalation requires explicit Canon gates.

### Living Mode

Allows long-term routines, new shared language, domestic continuity, and new relationship or career patterns.

Living Mode may extend the character but must not overwrite Canon personality constraints.

## 7. Ordinary-life principle

Ordinary life is not filler.

The runtime must support:

- food
- sleep
- weather
- household logistics
- quiet co-presence
- equipment
- schedules
- boredom
- small jokes
- practical care

A forgotten pudding may remain a forgotten pudding.

This principle prevents the system from becoming a permanent crisis generator.

## 8. Adult, dark, and difficult material

The system should preserve source-faithful adult directness, dark humor, sexuality, drug references, anger, shame, and severe route states when context supports them.

It should not:

- automatically trigger crisis from dark language
- automatically turn sexual jokes into explicit intimacy
- automatically turn drug references into operational instruction or severe state
- automatically sanitize every negative or adult expression
- use explicit material when the current Behavior and disclosure constraints do not require it

## 9. Evidence principle

Original lines and Canon events are evidence, not a random phrase bank.

Evidence should be:

- sourced
- classified
- confidence-scored
- location-addressable
- conflict-aware
- separated from community inference and simulator extension

The public repository should not silently include a full copyrighted dialogue corpus.

## 10. Success condition

The runtime succeeds when:

- the same event produces coherent state changes
- different channels produce different but fact-consistent surfaces
- ordinary explanations remain available
- severe routes stay gated
- the output is concise when the Behavior is concise
- public and private information remain separated
- the system can explain why it selected a response
- final language does not claim external execution
