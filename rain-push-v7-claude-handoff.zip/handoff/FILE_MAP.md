# File Map

## Root handoff

```text
CLAUDE.md
START_HERE_CLAUDE.md
handoff/
```

## Main project

```text
runtime/v7/
```

## Phase mapping

```text
Phase 1
  runtime/v7/evidence/

Phase 2
  runtime/v7/engines/continuity/
  runtime/v7/schemas/
  runtime/v7/tests/

Phase 3
  runtime/v7/relationship/

Phase 4
  runtime/v7/meaning/

Phase 5
  runtime/v7/emotion/

Phase 6
  runtime/v7/need/

Phase 7
  runtime/v7/thought/

Phase 8
  runtime/v7/decision/

Phase 9
  runtime/v7/behavior/

Phase 10
  runtime/v7/expression/

Phase 11
  runtime/v7/language/

Phase 12
  runtime/v7/engine/
```

## Important status files

```text
runtime/v7/FINAL_RUNTIME_STATUS.md
runtime/v7/PHASE2_STATUS.md
runtime/v7/PHASE3_STATUS.md
runtime/v7/PHASE4_STATUS.md
runtime/v7/PHASE5_STATUS.md
runtime/v7/PHASE6_STATUS.md
runtime/v7/PHASE7_STATUS.md
runtime/v7/PHASE8_STATUS.md
runtime/v7/PHASE9_STATUS.md
runtime/v7/PHASE10_STATUS.md
runtime/v7/PHASE11_STATUS.md
runtime/v7/PHASE12_STATUS.md
```

## Engine entry points

```text
runtime/v7/engine/src/index.js
runtime/v7/engine/src/orchestrator.js
runtime/v7/engine/src/cli.js
runtime/v7/engine/src/registry.js
```

## Engine tests

```text
runtime/v7/engine/tests/
```

## Machine-readable handoff

```text
handoff/project_context.json
handoff/materials_manifest.json
```
