# Known Limitations

## 1. Specification–implementation gap

Phase 1–11 specifications are broader than the executable Phase 12 engine.

Many documented domains, scores, gates, validators, and update policies are specification-only or partially represented.

This is the largest current gap.

## 2. Hardcoded rules

Executable behavior is currently implemented through JavaScript conditions.

The Markdown and DSL files are not compiled into runtime rules.

Consequences:

- duplicate sources of truth
- manual drift risk
- slower expansion
- harder automated parity checks

## 3. Partial schema enforcement

Packet shape is validated, but the engine does not yet enforce every YAML schema field and enum.

There is no generated JSON Schema pipeline.

## 4. JavaScript, not full TypeScript implementation

A `types.d.ts` contract exists, but runtime code is JavaScript.

Static compile-time coverage is therefore limited.

## 5. Narrow event classifier

Typed context works best.

Text heuristics are intentionally small and should not be treated as comprehensive language understanding.

## 6. Limited adaptive learning

Update Queues commit scenario counters.

The broader pattern learning described in earlier phases is not fully implemented.

## 7. No production database

Available stores:

- memory
- JSON file

Missing:

- schema migrations
- transactional database adapter
- concurrency control
- multi-device synchronization
- backup and recovery

## 8. No full evidence corpus

The package includes evidence policies and schemas, not a complete copyrighted Canon dialogue corpus.

A future corpus must be added with provenance and copyright care.

## 9. No external weather adapter

The project does not yet ingest live weather forecasts.

It also does not yet implement:

- morning rain detection
- notification windows
- location handling
- forecast freshness
- weather-source provenance
- push-notification execution

## 10. No real external execution

Messaging, posting, moderation, scheduling, and push delivery are not connected.

The execution boundary is present, but handlers are not.

## 11. No constrained LLM adapter

The reference engine renders fixed rule outputs.

A future LLM renderer could expand language variety, but it must remain constrained by Packets and validators.

## 12. Limited multilingual support

The architecture is language-agnostic in principle, but current final outputs are primarily Chinese.

## 13. Evaluation is mostly conformance-based

Current tests verify architecture and selected outputs.

Missing:

- human character-fidelity ratings
- Canon expert review
- diversity evaluation
- long-session drift evaluation
- adversarial privacy evaluation
- latency and throughput benchmarks
- weather-product user testing

## 14. No UI or app shell

The package is a runtime core and reference engine, not a complete app.
