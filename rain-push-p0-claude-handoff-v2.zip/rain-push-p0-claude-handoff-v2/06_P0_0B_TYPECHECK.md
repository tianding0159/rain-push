# P0-0B: JSDoc/checkJs Type Hardening

This is separate from source promotion because the current strict checkJs baseline is not green.

A probe against the available engine source produced 179 errors across 25 files. Do not hide that debt.

## Requirements

- keep `.js` and ESM
- add exact dev-dependency versions for TypeScript and Node typings
- align `@types/node` major with CI Node major
- use `allowJs`, `checkJs`, `strict`, `noEmit`
- typecheck the full canonical engine `src/`
- add a separate blocking CI job
- preserve zero-dependency offline runtime execution
- preserve existing tests and deterministic outputs

## Forbidden shortcuts

- no `@ts-nocheck`
- no project-wide `checkJs: false`
- no `continue-on-error`
- no `|| true`
- no broad `any` aliases that erase packet contracts
- no full TypeScript migration
- no behavior changes disguised as type fixes

## Review strategy

Commit in small logical groups:

1. shared RuntimeEvent/Packet/context types
2. orchestrator, packet and registry
3. state/update queue/execution
4. runtime modules
5. CLI/logging/replay

Each commit must keep tests green.

## Stop

Open PR and stop for review.
