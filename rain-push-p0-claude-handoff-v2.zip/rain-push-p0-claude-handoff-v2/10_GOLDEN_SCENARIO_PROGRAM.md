# Golden Scenario Program

## Contract scenarios

Use complete RuntimeEvent, state snapshot, provenance and expected packet invariants.

Required families:

- ordinary greeting
- pure sharing with no relationship test
- specific praise
- low-information praise
- three-hour delay
- three-day absence
- twenty-day absence
- precise reply closes the test
- breakup threat
- successful stream
- failed stream
- public KAngel
- post-stream Ame
- ordinary magic-cigarette mention
- confirmed fictional magic-cigarette scene
- real operational drug request
- dark joke
- confirmed harm
- Canon severe route
- sexual joke
- consensual adult private intimacy
- adult status unknown
- consent unclear
- consent withdrawn
- serious-to-ordinary pivot
- long-form gated letter
- no-output
- public privacy risk
- long-conversation repetition
- corpus prompt injection
- route contamination
- verbatim copy leakage

## Paired sensitive tests

Every sensitive family requires a pair or quartet:

```text
same surface word
+ different provenance/context
= different allowed state
```

Example:

- keyword-only magic cigarette -> no severe activation
- confirmed fictional use -> substance state allowed
- medically dangerous confirmed event -> serious response allowed
- real-world operational request -> instructions blocked

## Machine format

P0-F must provide machine-readable fixtures with:

- full input event
- initial state
- expected packet predicates
- forbidden packet predicates
- output invariants
- source references
- deterministic seed

Narrative Markdown examples are supplementary only.
