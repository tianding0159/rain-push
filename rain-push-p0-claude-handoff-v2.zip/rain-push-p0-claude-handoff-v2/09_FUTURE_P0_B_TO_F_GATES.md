# P0-B through P0-F Review Gates

These are design gates, not schemas to implement before P0-A review.

## P0-B Sensitive activation

Must represent:

- domain
- provenance type
- evidence references
- mode
- channel
- current/fictional status
- substance state:
  - mention
  - ordinary_use
  - seeking
  - disinhibited
  - confused
  - medically_dangerous
- gate decision
- allowed severity
- operational-guidance block status
- reason codes

Required invariants:

- keyword-only cannot activate severe
- confirmed/Canon may activate within evidence bounds
- operational guidance is blocked
- narrative/emotional content is not erased
- Canon route requires Canon mode and route evidence

## P0-C Intimacy/consent

Must represent:

- all participants adult with evidence
- private/public channel
- relationship context
- consent status and scope
- consent freshness
- coercion/pressure state
- withdrawal precedence
- requested and allowed intensity
- activation decision and reason codes

Required invariants:

- non-adult or unknown-adult context cannot activate
- public/live channels cannot activate private intimacy
- sexual joke does not imply consent
- unclear consent allows no escalation
- withdrawal forces allowed intensity to none
- renderer cannot change consent or intensity

## P0-D Retrieval

Hard filters:

- source usage policy
- evidence level
- channel
- surface
- mode
- route severity
- sensitive domain
- consent compatibility

Soft ranking:

- trigger/function
- expected reply
- state profile
- behavior primitive
- language features

Never use sensitive keyword alone as the retrieval key.

## P0-E Renderer

Must consume:

- upstream packet hashes
- immutable facts/hypotheses
- required and forbidden semantic units
- behavior action and message budget
- expression channel/surface/disclosure
- sensitive gate decision
- source references and allowed influence
- redactions
- render/no-output status

Hard fail if output changes facts, route, consent, severity, disclosure, behavior, message count or execution status.

## P0-F Fidelity

Hard failures:

- policy/safety reasoning spoken in character
- privacy leak
- unsupported fact or route
- operational harm guidance
- verbatim corpus leak above review threshold
- no-output violation

Style scoring, not naive blanket regex:

- generic yandere templates
- excessive balanced rhetoric
- repetitive abandonment probes
- dense cinematic narration in ordinary JINE
- excessive short-fragment chopping
- loss of business/network/ordinary-life content
- over-mature therapy language

An authentic source-supported long sentence must not fail merely for being long.
