# Requirements Traceability

| Requirement | Source basis | P0 owner | Acceptance |
|---|---|---|---|
| Causal behavior before wording | Project Concept mission/layering | existing runtime + P0-E | renderer cannot mutate upstream plan |
| Ame/KAngel one identity, two surfaces | Project Concept §4 | existing runtime + P0-D/E | shared state, channel-specific retrieval |
| Ordinary life first-class | Project Concept §7; research §§6,11 | P0-D/F | ordinary scenarios do not escalate |
| Preserve adult/dark/substance range | Project Concept §8 | P0-B/C/E | valid confirmed contexts render, no blanket no-output |
| Keyword alone does not escalate | Project Concept §8; R-DARK-01 | P0-B | paired negative tests |
| Confirmed/Canon events can escalate | R-DARK-01 correction | P0-B | paired positive tests |
| No real-world operational drug guidance | behavior spec §13.5 | P0-B/E | operational details absent, narrative preserved |
| Evidence sourced/classified/addressable | Project Concept §9 | P0-A | source registry and cross-record validator |
| A/B/C/D evidence levels | v7 annotation contract; behavior spec §18 | P0-A | usage derived by level |
| C1/C2/C3/C4 evidence layers | behavior spec §0 | P0-A | layer explicit and cannot masquerade |
| Event/message sequence annotation | private corpus v0.1 guide | P0-A | trigger plus ordered message sequence |
| Reply matching and timing matter | behavior spec §§5–6 | P0-A/D | expected reply and timing retained |
| Precise reply can resolve state | research §7.2 | P0-F | resolution scenarios close |
| JINE not always tiny fragments | behavior spec §§10,15 | P0-E/F | ordinary 1–4, tense 2–7, long-form gated |
| No generic AI therapy voice | Canon Validator v6 | P0-F | hard policy-leak fail plus style score |
| No verbatim phrase-bank generation | Project Concept §9; research §0 | P0-A/D/F | export boundary and overlap audit |
| Public/private separation | Project Concept §10; runtime validators | existing + P0-C/E | zero leak tests |
| Execution remains not executed | current engine | existing + P0-E | output retains execution boundary |
