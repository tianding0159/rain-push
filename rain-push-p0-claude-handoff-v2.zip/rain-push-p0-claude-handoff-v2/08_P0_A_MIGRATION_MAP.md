# P0-A Migration Map

| Existing private v0.1 | Existing v7 contract | P0-A v2 |
|---|---|---|
| `id` | `id` | `id` |
| `source.kind` | `source.type` | registry `kind` |
| `source.reference` | `source.reference` | registry `reference` + `locator` |
| `source.canon_confidence` | `source.confidence` | registry confidence + record `evidenceLevel` |
| `speaker` | implicit | message `speaker` |
| `channel: jine` | `channel` | `jine_private` |
| `time` | `canon_time` | context `timeWindow` |
| state bands | `canon_state` | context `canonState` |
| trigger array | `event_trigger` | event `trigger` |
| message order/text/delay | `text` | ordered `messages[]` |
| `annotations.goal` | `functional_need` | behavior `functionalNeed` |
| `expected_response` | `expected_reply_class` | behavior `expectedReplyClass` |
| `behavior_primitives` | same | behavior `primitives` |
| `escalation_pattern` | timing/state effect | behavior `escalationPattern` |
| `persona_surface` | same | context `personaSurface` |
| missing | `p_role` | behavior `pRole` |
| missing | `reply_timing_sensitivity` | behavior `replyTimingSensitivity` |
| missing | `route_severity` | route `severity` |
| missing | `context_required` | context `contextRequired` |

Migration must preserve unknowns. It must not invent channel, day, state or route values.
