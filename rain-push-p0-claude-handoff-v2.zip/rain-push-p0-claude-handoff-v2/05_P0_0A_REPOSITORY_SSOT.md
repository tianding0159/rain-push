# P0-0A: Reviewable Engine Source SSOT

## Base verification

Before extraction:

1. verify `main` commit against `02_SOURCE_LOCK.json`
2. verify root ZIP Git blob and size
3. inspect the current ZIP's internal `materials_manifest.json`
4. record the current test result
5. stop if any mismatch is unexplained

## Migration

Promote the complete current ZIP engine into:

```text
runtime/v7/engine/
  src/
  tests/
  parity/
  examples/
  package.json
  docs already present in the ZIP
```

Do not overwrite newer review-surface files blindly. Compare same-path files and report differences.

## Generated artifact contract

Create a deterministic build script.

Required determinism:

- paths sorted bytewise
- `/` path separators
- fixed ZIP timestamp
- normalized permissions
- no host-specific absolute paths
- stable compression configuration
- SHA-256 for every file
- manifest generated from repository source
- generated archive round-trips to identical file hashes

The committed manifest must include its format version and source commit. The archive itself may be committed or published as a workflow artifact, but there must be only one source of truth.

## Tests

- repository-source `npm test`
- fresh generated ZIP `npm test`
- source/ZIP file-hash parity
- no unexpected file additions or omissions
- clean working tree after regeneration

## Prohibited

- no runtime behavior changes
- no dialogue changes
- no schema redesign
- no JSDoc/type cleanup in this PR
- no dependency changes except build tooling strictly required for deterministic packaging

## Stop

Open PR and stop for review.
