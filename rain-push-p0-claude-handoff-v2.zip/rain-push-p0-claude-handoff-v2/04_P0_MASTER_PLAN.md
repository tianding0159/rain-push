# P0 Master Plan v2

## Product outcome

The P0 is complete only when the runtime can:

1. preserve existing causal and safety contracts
2. distinguish keyword-only sensitive mentions from confirmed or Canon-routed events
3. permit supported adult, dark, intimate and fictional substance content
4. block real-world operational harm guidance without erasing narrative
5. ground language generation in traceable source evidence
6. render channel-appropriate Ame/KAngel language without generic AI drift
7. prove these properties through deterministic tests and user blind evaluation

## Workstreams

### P0-0A: reviewable source SSOT

Move the full current engine source out of ZIP-only opacity. ZIP becomes generated.

### P0-0B: type hardening

Add JSDoc/checkJs in a separate behavior-neutral PR. Typecheck is a separate required CI job.

### P0-A: evidence and corpus contract

Unify the existing v7 annotation contract and private corpus event model. Build source registry, private/public schemas, importer boundary and cross-record validators.

### P0-B: bidirectional sensitive activation

Implement negative keyword gates and positive confirmed/current/harm/Canon gates. Add substance-state distinctions from the behavior specification.

### P0-C: adult intimacy and consent

Add a first-class context and activation decision. Public channels, non-adult contexts, unclear consent and withdrawal cannot activate intimacy.

### P0-D: structural retrieval

Retrieve by channel, surface, mode, event function, state, reply class, route severity and evidence policy. Keyword is never the sole retrieval key.

### P0-E: constrained renderer

Render from an immutable, hash-bound plan. The renderer may vary language only.

### P0-F: fidelity evaluation

Use deterministic contract tests, retrieval audits, copy-leak detection, long-conversation tests and blinded user evaluation.

## Stage gates

P0-D cannot start until:

- all 1051 lines have source classification or explicit unknown status
- duplicates and fragments are identified
- evidence levels are assigned
- route-severe lines are isolated
- private/public export tests pass

P0-E cannot start until:

- P0-B and P0-C positive/negative gates pass
- retrieval results preserve source references and allowed influence
- no public artifact contains private corpus text

P0 is not complete until user blind evaluation passes.

## CI

Required independent jobs:

- `engine-tests-offline`
- `source-zip-parity`
- `typecheck`
- `schema-contracts`
- `corpus-export-guard`
- `sensitive-gate-contracts`
- `fidelity-contracts`

No blocking CI job may call an external LLM.
