# START HERE: P0 Fidelity and Bidirectional Activation v2

Read every file in this package before changing the repository.

## Source lock

Implementation must begin from the current GitHub repository, not from any locally attached older v7 ZIP.

Expected starting revision at handoff creation:

- repository: `tianding0159/rain-push`
- base branch: `main`
- commit: `30685cc42c91ad66a9887d5c38d5a7abaf22a819`
- root ZIP blob: `b2c74c3b79055a741f40a7041ee3bca44efb526d`
- root ZIP size: `528131`

If `main` has moved, stop, inspect the new commits, and produce a compatibility report before coding. Do not silently apply this plan to a different base.

## Authority order

1. Current repository executable behavior and tests
2. Existing v7 Project Concept and runtime contracts
3. Existing `runtime/v7/corpus/annotation_contract.md`
4. User-provided 1051-line research specification
5. This handoff's P0 refinements
6. New implementation choices

When sources conflict, preserve the higher authority and document the conflict.

## Mandatory PR order

1. **P0-0A**: promote current full engine source from the current GitHub ZIP into reviewable repository source; generate ZIP from source
2. Stop for review
3. **P0-0B**: add JSDoc/checkJs and a separate blocking typecheck job
4. Stop for review
5. **P0-A**: implement corpus source registry, private/public corpus contracts, importer boundary and validators
6. Stop for review

Do not implement P0-B through P0-F before P0-A is approved.

## Non-goals

- no dialogue rewrite
- no full TypeScript migration
- no private 1051-line corpus in Git or CI artifacts
- no blanket suppression of adult, dark, sexual or substance-related narrative
- no real-world drug-use instructions
- no free-form LLM deciding facts, behavior, severity, route, disclosure or consent
- no single giant PR
