# P0 Review Checklist v2

## Source integrity

- [ ] Base commit and ZIP blob verified
- [ ] Current GitHub ZIP, not stale local copy, used
- [ ] Source differences documented
- [ ] No silent conflict resolution

## P0-0A

- [ ] full source visible
- [ ] deterministic build defined precisely
- [ ] SHA-256 manifest
- [ ] source and ZIP tests green
- [ ] source/ZIP hash parity
- [ ] no runtime behavior change

## P0-0B

- [ ] separate PR
- [ ] full `src/` checkJs strict and green
- [ ] separate blocking job
- [ ] no suppressions or blanket `any`
- [ ] runtime remains zero-dependency
- [ ] no output behavior change

## P0-A

- [ ] existing v7 fields preserved or migrated explicitly
- [ ] event/message sequence retained
- [ ] C1–C4 explicit
- [ ] A–D explicit
- [ ] eligibility derived from source registry
- [ ] `jine_private` enum compatible
- [ ] private/public schemas separate
- [ ] suspected-AI quarantined
- [ ] community/synthetic cannot drive behavior
- [ ] public export contains no private verbatim text
- [ ] conflicts and duplicates explicit
- [ ] retrieval references traceable

## Future gates

- [ ] sensitive positive and negative directions paired
- [ ] substance states distinguish mention through medical danger
- [ ] intimacy requires adults/private/consent
- [ ] withdrawal wins
- [ ] renderer is hash-bound and cannot mutate decisions
- [ ] style lint is evidence-aware, not naive sanitization
- [ ] machine-readable golden fixtures
- [ ] blind user evaluation passed
