# P0-A: Corpus Provenance and Annotation Contract

## Preserve existing semantics

P0-A extends rather than replaces:

- `runtime/v7/corpus/annotation_contract.md`
- C1/C2/C3/C4 evidence layers from the runtime behavior specification
- A/B/C/D evidence levels
- the private corpus v0.1 event/message-sequence unit
- current runtime channel enum `jine_private`

## Data model

A sample is an event-level unit:

```text
source
+ context/state
+ trigger
+ prior partner input if known
+ ordered Ame/KAngel message sequence
+ functional goal
+ expected reply
+ timing sensitivity
+ escalation/withdrawal pattern
+ state effect
+ route severity
+ language features
+ uncertainty
```

Do not flatten every message into an independent phrase record.

## Source registry

Eligibility is derived from the source registry. Corpus records do not self-declare that they may influence behavior.

Required source dimensions:

- source kind
- C1/C2/C3/C4 layer
- reference and locator
- confidence
- review status
- storage policy
- behavior policy
- language policy
- production enablement

## Private/public split

### Private record

May contain user-provided text and verbatim flags. Must remain outside Git and CI artifacts.

### Public derived record

May contain:

- hashes
- non-verbatim summaries
- structural labels
- derived language features
- synthetic test messages

It must not contain original private corpus text.

## Cross-record validator

JSON Schema alone is insufficient. Add executable validation that:

- resolves `sourceRef`
- derives allowed usage
- prevents C/D or disallowed sources from behavior influence
- prevents suspected-AI and synthetic records from production behavior
- prevents public export of private verbatim text
- requires Canon-severe retrieval to use a Canon-compatible source, mode and route
- preserves source references in retrieval output
- detects duplicate IDs and content hashes
- records unresolved conflicts instead of picking a winner silently

## Migration

Provide a migration tool or documented transform from:

- `ame_jine_private_corpus/annotations/schema.json`
- `runtime/v7/corpus/annotation_contract.md`

No private text is required to run migration tests. Use synthetic fixtures.

## Tests

At minimum:

1. schema meta-validation
2. valid C1/A private event
3. valid C3/C language-only event
4. D excluded from generation
5. suspected-AI quarantined
6. community cannot drive behavior
7. guide can influence mechanics only
8. unknown context cannot drive Canon-severe retrieval
9. public export rejects verbatim original text
10. source reference survives retrieval
11. duplicate source/record detection
12. private path absent from Git and workflow artifacts
13. deterministic import/export
14. current channel enums remain compatible

## Stop

Open PR and stop for review. Do not implement P0-B yet.
