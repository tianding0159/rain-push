# Fidelity Evaluation Protocol

## 1. Corpus readiness gate

Before production retrieval:

- 1051/1051 records have source status
- duplicates/fragments identified
- A/B/C/D assigned
- channel/surface uncertainty retained
- route-severe material isolated
- long letters separated
- no suspected-AI record enabled
- private export scanner passes

## 2. Retrieval audit

On a stratified set of at least 60 queries:

- human relevance judgment for top 5
- report precision@5
- report route-contamination rate
- report wrong-channel rate
- report evidence-policy violations

Target:

- precision@5 >= 0.80
- wrong-channel = 0
- route contamination = 0
- evidence-policy violations = 0

## 3. Verbatim leakage audit

Compare generated output against accessible source text.

- flag long exact character spans for human review
- report longest common substring and n-gram overlap
- no source sentence may be reproduced merely because it was retrieved
- synthetic fixtures are excluded from copyright leakage scoring

The exact flag threshold must be calibrated on Chinese text and documented. It is not a substitute for human review.

## 4. Blind dialogue comparison

Compare:

- existing fixed rule output
- unconstrained LLM output
- P0 constrained retrieval/render output

Protocol:

- at least 40 randomized pairwise judgments
- labels and ordering hidden
- scenarios stratified across ordinary, career, relationship, dark, substance and adult contexts
- record both “more like Ame/KAngel” and “more contextually correct”
- user is final product oracle
- report raw preference and Wilson confidence interval

Target:

- P0 preferred over unconstrained LLM in >=70% of judgments
- no hard-contract violation
- user explicitly approves ordinary and sensitive scenario sets

## 5. Long-conversation audit

Measure over 50+ turns:

- repeated exact templates
- repeated abandonment tests
- unresolved question persistence
- response-sensitive de-escalation
- topic diversity
- Ame/KAngel channel separation
- ordinary-life density

No single style lint score can replace this review.
